function [Ecorr,bvs,f]=Eco3(Va,n,r,h,Ra,V0,lambda0,Amat1,Amat2,phi)%co=correction

r=r';
votexm=min(r,[],1)-Ra;
votexM=max(r,[],1)+Ra;
ndiv=ceil((votexM-votexm)./h)+1;
ndiv=ndiv+(mod(ndiv,4)>0).*(4-mod(ndiv,4));
dis=r-votexm;
ns=floor(dis./h);
coors=dis-ns*h;
n1=floor((dis-Ra)/h);
M=size(r,1);
bb=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
Vc=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
bvs=zeros(1,2);
for k=1:M
    bmsig=bsig3D2(Va,n,h,Ra,coors(k,:),Amat1);
    bimsig=bisig3D(n,h,Ra,coors(k,:));
    b_bmsig=bimsig-bmsig;
    bbmsig=bimsig+bmsig;
    Vcsig=invIvecsig3(1/(4*pi),h,V0,lambda0,b_bmsig);
    Vsig=Vasig3D(Va,n,h,Ra,coors(k,:));
    
    szv=size(bbmsig);
    bb(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))=bb(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))+bbmsig;
    Vc(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))=Vc(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))+Vcsig;
    Visig=Vcsig+Vsig;
    bvs(1)=bvs(1)+bimsig(:)'*Visig(:);
    bvs(2)=bvs(2)+bmsig(:)'*Vsig(:);
end
Ecorr=1/2*(bb(:)'*Vc(:)-bvs(1)+bvs(2));
f1=zeros(3,M);
fcorr=zeros(3,M);
for k=1:M
    [bmsig,g]=bsig3D2(Va,n,h,Ra,coors(k,:),Amat1,Amat2);
    [bimsig,gi]=bisig3D(n,h,Ra,coors(k,:),Amat2);
    b_bmsig=bimsig-bmsig;
    Vcsig=invIvecsig3(1/(4*pi),h,V0,lambda0,b_bmsig);
    gVcsig=cell(3,1);
    for i=1:3
        gVcsig{i}=Tucker3matvec2(Amat2(i,:),extend(Vcsig,n));
    end
    gVcsig=cutedge(gVcsig,n);
    Vsig=Vasig3D2(Va,n,h,Ra,coors(k,:));
    gVsig=cell(3,1);
    for i=1:3
        gVsig{i}=Tucker3matvec2(Amat2(i,:),Vsig);
    end
    Vsig=cutedge(Vsig,n);
    gVsig=cutedge(gVsig,n);
    Visig=Vcsig+Vsig;
    gVisig=cell(3,1);
    for i=1:3
        gVisig{i}=gVcsig{i}+gVsig{i};
    end
         
    szv=size(bbmsig);
    t=Vc(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))-Visig;
    for i=1:3
        fcorr(i,k)=fcorr(i,k)+gi{i}(:)'*t(:);
    end
    t=Vc(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))+Vsig;
    for i=1:3
        fcorr(i,k)=fcorr(i,k)+g{i}(:)'*t(:);
    end
    t=bb(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3));
    for i=1:3
        fcorr(i,k)=fcorr(i,k)+gVcsig{i}(:)'*t(:);
    end
    for i=1:3
        fcorr(i,k)=fcorr(i,k)+bmsig(:)'*gVsig{i}(:);
    end
    for i=1:3
        fcorr(i,k)=fcorr(i,k)-bimsig(:)'*gVisig{i}(:);
    end
    t=phi(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))-Vsig;
    for i=1:3
        f1(i,k)=f1(i,k)+g{i}(:)'*t(:);
    end
end
f=f1+fcorr;
end