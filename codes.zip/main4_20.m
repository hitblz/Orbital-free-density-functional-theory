%from main4, higher-order finite difference method
clear
tic;
add=[pwd '\singleatom2\'];
fl='a6h5ep2n2ao2.mat';
%% V-multigrid
epsilon=1e-6;
t=load([add fl],'nele','br','h','Vsig','uL0','bm','N','Ra');
nele=t.nele;
br=t.br;
h=t.h;
Vsig=t.Vsig;
uL0sig=normalize(t.uL0,nele,h);
bmsig=t.bm;bmsig=bmsig{1};
Nsig=t.N;
Ra=t.Ra;
% F=[0,0.2,0;0,0,0;0,0,0];
a0=8;
ncell=[1 1 1]*10;
r0=r0cgen(ncell)*a0;
r0=r0';
% r0=[1/2,1/2,1/2;-1/2,1/2,1/2;-1/2,-1/2,1/2;1/2,-1/2,1/2;1/2,1/2,-1/2;-1/2,1/2,-1/2;-1/2,-1/2,-1/2;1/2,-1/2,-1/2;...
%     0,0,1/2;0,0,-1/2;1/2,0,0;-1/2,0,0;0,1/2,0;0,-1/2,0]'*a0;
% r0=[0,0,0;1/2,0,1/2;1/2,0,-1/2;-1/2,0,1/2;-1/2,0,-1/2;1/2,1/2,0;1/2,-1/2,0;-1/2,1/2,0;-1/2,-1/2,0;0,1/2,1/2;0,-1/2,1/2;0,1/2,-1/2;0,-1/2,-1/2]'*a0;
%r=(eye(3)+F)*r0;
r=r0;
rhosig=uL0sig.^2;
rhor=chebfun.spline(0:h:Ra,[rhosig((Nsig+1)/2:end,(Nsig+1)/2,(Nsig+1)/2);0]);
f0=chebfun(0,[Ra,2*Ra]);
rhorn=join(rhor,f0);
rhoi=assem4(1,1,rhorn,r,h,Ra);
uL0i=sqrt(rhoi);
uL0=uL0i;
bL0=assem4(0,2,br,r,h,Ra);

%%
Na=size(r0,2);%number of atoms
nele=Na*nele;

n=2;
wp=zeros(1,n+1);
for p=0:n
    if p==0
        wp(p+1)=2*sum((1:n).^(-2));
    else
        wp(p+1)=2*(-1)^p/p^2*factorial(n)^2/(factorial(n-p)*factorial(n+p));
    end
end
% wp=[34 -16 -1]./20;
% n=2;
xwp=[wp(n+1:-1:2) wp];
wp2=[2.17 1];
xwp2=[wp2(2) wp2];
xwp2=xwp2./sum(xwp2);
Amat=cell(1,4);
M=cell(1,4);
Vs=cell(1,3);
lambdas=cell(1,3);
for i=1:3%dimension
    N=size(uL0,i);
    As=zeros(N,N,2);
    for k=1:N
        a1=n+2-min(k,n+1);
        b1=max(1,k-n);
        lb=N-(b1-1);
        la=2*n+1-(a1-1);
        ly=min(la,lb);
        a2=a1-1+ly;
        b2=b1-1+ly;
        As(k,b1:b2,1)=xwp(a1:a2);
        
        c1=1+2-min(k,1+1);
        d1=max(1,k-1);
        ld=N-(d1-1);
        lc=2*1+1-(c1-1);
        lz=min(lc,ld);
        c2=c1-1+lz;
        d2=d1-1+lz;
        As(k,d1:d2,2)=xwp2(c1:c2);
    end
    Amat{i}=As;
    M{i}=As(:,:,2);
    [V,lambdaN]=eig(As(:,:,1),As(:,:,2));lambdaN=diag(lambdaN);
    Vs{i}=V;lambdas{i}=lambdaN;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat{4}=c.*h;
M{4}=h^3;
%[EuL0i,guL0i,phiL0i]=EcgEc(1,uL0i,nele,h,Amat,bL0,LmuN,imuN,M,0,0,0);%对后续计算没有实际用途，仅作为参照。

[uL0,EuL0,guL0,phiL0,flag,ad]=VM5_2(epsilon,uL0,nele,h,Amat,M,Vs,lambdas,bL0);
maxit=ad{1};
nit=ad{2};
Mu=Tucker3matvec2(M,uL0);
inprodu=uL0(:)'*Mu(:);
a=sqrt(nele/inprodu);
uL0=uL0.*a;
%%
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat,uL0);
E1=lam/2.*uL0(:)'*t(:);
%second part of kinematic energy + Exc
fu=kxc1(uL0);
u2=uL0.^2;
t=Tucker3matvec2(M,fu);
E2=u2(:)'*t(:);
%E-I interaction energy
t=Tucker3matvec2(M,phiL0);
E3=1/2*(u2(:)'*t(:)+bL0(:)'*phiL0(:));
E4=-1/2*Na*bmsig(:)'*Vsig(:);
E0=E1+E2+E3+E4;
E0ev=E0/Na*27.2114;

tim=toc;
add2=[pwd '\atomcluster2\'];
save([add2, 'c3a6h5ep2n2ao2sg.mat'],'-v7.3');