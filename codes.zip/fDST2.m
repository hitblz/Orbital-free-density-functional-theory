function out=fDST2(v,method)
sz=[size(v,1) size(v,2) size(v,3)];
out=reshape(fDST(reshape(v,sz(1),sz(2)*sz(3)),method),sz(1),sz(2),sz(3));
out=ipermute(reshape(fDST(reshape(permute(out,[2 3 1]),sz(2),sz(3)*sz(1)),method),sz(2),sz(3),sz(1)),[2 3 1]);
out=ipermute(reshape(fDST(reshape(permute(out,[3 1 2]),sz(3),sz(1)*sz(2)),method),sz(3),sz(1),sz(2)),[3 1 2]);
end