function out=metadensitysig2(Ra,n2,M,Z)
x=linspace(-Ra,Ra,n2+1)';
s=2;%>1
t1=[normpdf(x,0,1) normpdf(x,0,1/s)];
t1(1,:)=[];
t1(end,:)=[];
t=zeros(2,2,2);
t(1)=1;
t(8)=-(normpdf(0,0,1)/normpdf(0,0,1/s))^3*0.99;
out={t1;t1;t1;t};
out=tucker3product(out);
z=out;
z(:,:,:)=1e-6;
out=out+z;
t3=Tucker3matvec2(M,out);
inprodu=out(:)'*t3(:);
out=out.*sqrt(Z/inprodu);
end