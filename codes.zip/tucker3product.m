function out=tucker3product(varargin)
switch nargin
    case 4
        C=varargin{1};
        T1=varargin{2};
        T2=varargin{3};
        T3=varargin{4};
        out=tencontract(T1,2,2,C,3,1);
        out=ipermute(tencontract(T2,2,2,out,3,2),[2 1 3]);
        out=ipermute(tencontract(T3,2,2,out,3,3),[3 1 2]);
    case 1
        v=varargin{1};
        switch length(v)
            case 4
                out=tucker3product(v{4},v{1},v{2},v{3});
            case 2
                out=tucker3product(v{2},v{1},v{1},v{1});
        end
end
end