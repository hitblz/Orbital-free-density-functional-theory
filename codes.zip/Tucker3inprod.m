function out=Tucker3inprod(task,v1,v2,varargin)
% inner product of third-order tucker tensor
switch task
    case 1%for nodes
        sd=cell(1,3);
        for k=1:3
            sd{k}=v1{k}'*v2{k};
        end
        out=tucker3product(v2{4},sd{1},sd{2},sd{3});
        out=v1{4}(:)'*out(:);
        
    case 2%for fields
        Ns=[size(v1{1},1) size(v1{2},1) size(v1{3},1)];
        M=cell(4,1);
        for k=1:3
            M{k}=[2/3*ones(Ns(k),1);1/6*ones(Ns(k)-1,1);1/6*ones(Ns(k)-1,1)];
        end
        h=varargin{1};
        M{4}=prod(h);
        tol=varargin{2};
        v2=Tucker3matvec(M,v2,tol);
        out=Tucker3inprod(1,v1,v2);
end