function out=tensordecompose2(task,ten,tol,svdmode)
%task 1-6 are tensor train and 7 is three-way tucker decomposition
%tol stands for tol1 or tol2
switch task
    case 1% t(x1,/x2,/i1,i2), for Hadamard product
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4)];
        switch svdmode
            case 1
                [M1,S1,ten2]=svd(reshape(ten,[sz(1) sz(2)*sz(3)*sz(4)]),'econ');
                Sv1=diag(S1);
                lSv1=length(Sv1);
                ra1=sqrt(cumsum(Sv1.^2))/norm(Sv1);
                for k1=1:lSv1
                    if ra1(k1)>=1-tol
                        break
                    end
                end
                M1=M1(:,1:k1)*S1(1:k1,1:k1);
                [M2,S2,M3]=svd(reshape(ten2(:,1:k1)',[k1*sz(2),sz(3)*sz(4)]),'econ');
                Sv2=diag(S2);
                lSv2=length(Sv2);
                ra2=sqrt(cumsum(Sv2.^2))/norm(Sv2);
                for k2=1:lSv2
                    if ra2(k2)>=1-tol
                        break
                    end
                end
                M2=reshape(M2(:,1:k2)*S2(1:k2,1:k2),[k1,sz(2),k2]);
                M3=reshape(M3,[k2,sz(3),sz(4)]);
                out={M1,M2,M3};
            case 2
                [~,id]=max(abs(ten(:)));
                [id1,id2,id3,id4]=ind2sub(sz,id);
                idsets={id1,[id2 id3 id4];[id1 id2],[id3 id4]};
                scanlist=[1 2 2 1];
                lscanlist=length(scanlist);
                maxswps=500;
                errd=ones(2,1);
                flagd=zeros(2,1);
                for nswps=1:maxswps
                    for k=1:lscanlist
                        if errd(scanlist(k))<=tol || flagd(scanlist(k))==1
                            continue
                        else
                            outISE=ISEten(task,ten,idsets,scanlist,k,tol);
                            idsets=outISE{1};
                            errd(scanlist(k))=outISE{2};
                            flagd(scanlist(k))=outISE{3};
                        end
                    end
                    if max(errd)<=tol || min(flagd)==1 || nswps==maxswps
                        break
                    end
                end
                fprintf('sweeping completed \n');
                nI1=size(idsets{1,1},1);
                nI2=size(idsets{2,1},1);
                M1=cell2mat(arrayfun(@(c) ten(:,idsets{1,2}(c,1),idsets{1,2}(c,2),idsets{1,2}(c,3)),1:nI1,'UniformOutput',false));
                Amid1=M1(idsets{1,1},:);
                M1=M1/Amid1;
                M2=reshape(cell2mat(arrayfun(@(c) ten(idsets{1,1},:,idsets{2,2}(c,1),idsets{2,2}(c,2)),1:nI2,'UniformOutput',false)),[nI1,sz(2) nI2]);
                ss=[kron(ones(nI2,1),idsets{2,1}),kron(idsets{2,2},ones(nI2,1))];
                id=sub2ind(sz,ss(:,1),ss(:,2),ss(:,3),ss(:,4));
                Amid2=reshape(ten(id),[nI2,nI2]);
                M2=tencontract(M2,3,3,Amid2,2,1,'inv');
                M3=cell2mat(arrayfun(@(r) permute(ten(idsets{2,1}(r,1),idsets{2,1}(r,2),:,:),[1 3 4 2]),(1:nI2)','UniformOutput',false));
                if sum(flagd==0)==2
                    out={M1,M2,M3};
                else
                    out=0;
                end
        end
        
    case 2%ten is a FOURTH-order tensor: t(x1,x2,/i1,i2), for Hadamard product
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[sz(1)*sz(2),sz(3)*sz(4)]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz([1 2]) k]);
                M2=reshape(M2,[k,sz([3 4])]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3,id4]=ind2sub(sz,id);
                idsets={[id1 id2],[id3 id4]};
                maxrank=min(sz(1)*sz(2),sz(3)*sz(4));
                flag=0;
                for cardinterp=1:maxrank
                    Ik_=sub2indv2(sz(1:2),idsets{1,1});
                    Ik=sub2indv2(sz(3:4),idsets{1,2});
                    ten1=reshape(ten,[sz(1:2) sz(3)*sz(4)]);
                    M1=ten1(:,:,Ik);
                    clear ten1
                    ten2=reshape(ten,[sz(1)*sz(2) sz(3)*sz(4)]);
                    Amid=ten2(Ik_,Ik);
                    clear ten2
                    M1=tencontract(M1,3,3,Amid,2,1,'inv');
                    ten3=reshape(ten,[sz(1)*sz(2) sz(3:4)]);
                    M2=ten3(Ik_,:,:);
                    clear ten3
                    f2=tencontract(M1,3,3,M2,3,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3,id4]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},[id1,id2],'rows');
                    idsetsR=union(idsets{1,2},[id3,id4],'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};[id1,id2]];
                    idsets{1,2}=[idsets{1,2};[id3,id4]];
                end
                if errmax<=tol
                    fprintf('Dimension ((1,2),(3,4)) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 3%ten is a THIRD-order tensor: t(x1,/x2,/i), for summation
        sz=[size(ten,1),size(ten,2),size(ten,3)];
        switch svdmode
            case 1
                [M1,S1,ten2]=svd(reshape(ten,[sz(1) sz(2)*sz(3)]),'econ');
                Sv1=diag(S1);
                lSv1=length(Sv1);
                ra1=sqrt(cumsum(Sv1.^2))/norm(Sv1);
                for k1=1:lSv1
                    if ra1(k1)>=1-tol
                        break
                    end
                end
                M1=M1(:,1:k1)*S1(1:k1,1:k1);
                [M2,S2,M3]=svd(reshape(ten2(:,1:k1)',[k1*sz(2),sz(3)]),'econ');
                Sv2=diag(S2);
                lSv2=length(Sv2);
                ra2=sqrt(cumsum(Sv2.^2))/norm(Sv2);
                for k2=1:lSv2
                    if ra2(k2)>=1-tol
                        break
                    end
                end
                M2=reshape(M2(:,1:k2)*S2(1:k2,1:k2),[k1,sz(2),k2]);
                M3=reshape(M3,[k2,sz(3)]);
                out={M1,M2,M3};
            case 2
                [~,id]=max(abs(ten(:)));
                [id1,id2,id3]=ind2sub(sz,id);
                idsets={id1,[id2 id3];[id1 id2],id3};
                scanlist=[1 2 2 1];
                lscanlist=length(scanlist);
                maxswps=500;
                errd=ones(2,1);
                flagd=zeros(2,1);
                for nswps=1:maxswps
                    for k=1:lscanlist
                        if errd(scanlist(k))<=tol || flagd(scanlist(k))==1
                            continue
                        else
                            outISE=ISEten(task,ten,idsets,scanlist,k,tol);
                            idsets=outISE{1};
                            errd(scanlist(k))=outISE{2};
                            flagd(scanlist(k))=outISE{3};
                        end
                    end
                    if max(errd)<=tol || min(flagd)==1 || nswps==maxswps
                        break
                    end
                end
                fprintf('sweeping completed \n');
                nI1=size(idsets{1,1},1);
                nI2=size(idsets{2,1},1);
                M1=cell2mat(arrayfun(@(c) ten(:,idsets{1,2}(c,1),idsets{1,2}(c,2)),1:nI1,'UniformOutput',false));
                Amid1=M1(idsets{1,1},:);
                M1=M1/Amid1;
                M2=ten(idsets{1,1},:,idsets{2,2});
                M3=cell2mat(arrayfun(@(c) permute(ten(idsets{2,1}(c,1),idsets{2,1}(c,2),:),[1 3 2]),(1:nI2)','UniformOutput',false));
                Amid2=M3(:,idsets{2,2});
                M2=tencontract(M2,3,3,Amid2,2,1,'inv');
                if sum(flagd==0)==2
                    out={M1,M2,M3};
                else
                    out=0;
                end
        end
        
    case 4% t(x1,x2,/i), for summation
        sz=[size(ten,1),size(ten,2),size(ten,3)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[sz(1)*sz(2),sz(3)]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz([1 2]) k]);
                M2=reshape(M2,[k,sz(3)]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3]=ind2sub(sz,id);
                idsets={[id1 id2],id3};
                maxrank=min(sz(1)*sz(2),sz(3));
                flag=0;
                for cardinterp=1:maxrank
                    nI1=size(idsets{1,1},1);
                    M1=ten(:,:,idsets{1,2});
                    Amid=cell2mat(arrayfun(@(r) permute(M1(idsets{1,1}(r,1),idsets{1,1}(r,2),:),[1 3 2]),(1:nI1)','UniformOutput',false));
                    M2=cell2mat(arrayfun(@(r) permute(ten(idsets{1,1}(r,1),idsets{1,1}(r,2),:),[1 3 2]),(1:nI1)','UniformOutput',false));
                    M2=Amid\M2;%previous version: M1=tencontract(M1,3,3,Amid,2,1,'inv');
                    f2=tencontract(M1,3,3,M2,2,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},[id1,id2],'rows');
                    idsetsR=union(idsets{1,2},id3,'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};[id1,id2]];
                    idsets{1,2}=[idsets{1,2};id3];
                end
                if errmax<=tol
                    fprintf('Dimension ((1,2),3) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 5% t(x1,/i1,i2), for Hadamard product
        sz=[size(ten,1),size(ten,2),size(ten,3)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[sz(1),sz(2)*sz(3)]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz(1) k]);
                M2=reshape(M2,[k,sz([2 3])]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3]=ind2sub(sz,id);
                idsets={id1,[id2 id3]};
                maxrank=min(sz(1),sz(2)*sz(3));
                if maxrank>1
                    for cardinterp=1:maxrank
                        I1=setdiff(1:sz(1),idsets{1});
                        I2=setdiff(1:sz(2)*sz(3),sub2indv2(sz(2:3),idsets{2}));                        
                        Ik_=idsets{1};
                        Ik=sub2indv2(sz(2:3),idsets{2});
                        ten1=reshape(ten,[sz(1) prod(sz(2:3))]);
                        M1=ten1(:,Ik);
                        Amid=M1(Ik_,:);
                        M1=M1(I1,:)/Amid;
                        M2=ten1(Ik_,I2);
                        valdoetemp=ten1(I1,I2)-M1*M2;
                        [errmax,id]=max(abs(valdoetemp(:)));
                        errmax=errmax/val;
                        if isempty(errmax)                            
                            errmax=0;
                        end
                        if errmax<=tol
                            fprintf('Dimension (1,(2,3)) converged at rank %i.\n',size(idsets{1},1));
                            break
                        end
                        [id1,idII]=ind2sub([length(I1),length(I2)],id);
                        [id2,id3]=ind2sub(sz(2:3),I2(idII));
                        idsets{1}=[idsets{1};I1(id1)];
                        idsets{2}=[idsets{2};[id2,id3]];
                    end
                    out={ten1(:,Ik)/Amid,ten(Ik_,:,:)};
                elseif sz(1)==1
                    out={1,ten};
                else
                    out={ten./ten(id),ten(id)};
                end
        end
        
    case 6% t(x1,/i), for summation
        sz=[size(ten,1),size(ten,2)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,sz),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=M1(:,1:k)*S1(1:k,1:k);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2]=ind2sub(sz,id);
                idsets={id1,id2};
                maxrank=min(sz(1),sz(2));
                if maxrank>1
                    for cardinterp=1:maxrank
                        I1=setdiff(1:sz(1),idsets{1});
                        I2=setdiff(1:sz(2),idsets{2});
                        M1=ten(:,idsets{2});
                        Amid=M1(idsets{1},:);
                        M1=M1(I1,:)/Amid;
                        M2=ten(idsets{1,1},I2);
                        valdoetemp=ten(I1,I2)-M1*M2;
                        [errmax,id]=max(abs(valdoetemp(:)));
                        errmax=errmax/val;
                        if isempty(errmax)
                            errmax=0;
                        end
                        if errmax<=tol
                            fprintf('Dimension (1,2) converged at rank %i.\n',size(idsets{1},1));
                            break
                        end
                        [id1,id2]=ind2sub([length(I1),length(I2)],id);
                        idsets{1}=[idsets{1};I1(id1)];
                        idsets{2}=[idsets{2};I2(id2)];
                    end                    
                    out={ten(:,idsets{2})/Amid,ten(idsets{1},:),idsets};
                elseif sz(1)==1
                    out={1,ten,idsets};
                else
                    out={ten./ten(id),ten(id),idsets};
                end
        end
        
    case 7
        sz=[size(ten,1),size(ten,2),size(ten,3)];
        switch svdmode
            case 1
                [M1,S1,ten2]=svd(reshape(ten,[sz(1) sz(2)*sz(3)]),'econ');
                Sv1=diag(S1);
                lSv1=length(Sv1);
                ra1=sqrt(cumsum(Sv1.^2))/norm(Sv1);
                for k1=1:lSv1
                    if ra1(k1)>=1-tol
                        break
                    end
                end
                M1=M1(:,1:k1)*S1(1:k1,1:k1);
                [M2,S2,M3]=svd(reshape(ten2(:,1:k1)',[k1*sz(2),sz(3)]),'econ');
                Sv2=diag(S2);
                lSv2=length(Sv2);
                ra2=sqrt(cumsum(Sv2.^2))/norm(Sv2);
                for k3=1:lSv2
                    if ra2(k3)>=1-tol
                        break
                    end
                end
                M3=reshape(S2(1:k3,1:k3)*M3,[k3,sz(3)]);
                M2=reshape(M2(:,1:k3),[k1,sz(2),k3]);
                [M2,S3,C]=svd(reshape(permute(M2,[2 1 3]),[sz(2) k1*k3]),'econ');
                Sv3=diag(S3);
                lSv3=length(Sv3);
                ra3=sqrt(cumsum(Sv3.^2))/norm(Sv3);
                for k2=1:lSv3
                    if ra3(k2)>=1-tol
                        break
                    end
                end
                C=ipermute(reshape(C(1:k2)',[k2 k1 k3]),[2 1 3]);
                out={M1;M2;M3;C};
            case 2
                [~,id]=max(abs(ten(:)));
                [id1,id2,id3]=ind2sub(sz,id);
                idsets={id1,[id2,id3];id2,[id3 id1];id3,[id1 id2]};
                scanlist=1:3;
                maxswps=max(sz(:));
                errd=ones(3,1);
                for nswps=1:maxswps
                    for k=1:3
                        if errd(k)<=tol
                            continue
                        else
                            outISE=ISEten(7,ten,idsets,scanlist,k,tol);
                            idsets=outISE{1};
                            errd(k)=outISE{2};
                        end
                    end
                    if max(errd)<=tol || nswps==maxswps
                        fprintf('sweeping completed \n');
                        break
                    end
                end
                out=cell(5,1);
                for k=1:3
                    pm=[k:3 1:k-1];
                    t=permute(ten,pm);
                    sz=[size(t,1),size(t,2),size(t,3)];
                    ten1=reshape(t,[sz(1) prod(sz(2:3))]);
                    Ik=sub2indv2(sz(2:3),idsets{k,2});
                    M1=ten1(:,Ik);
                    Amid=M1(idsets{k,1},:);
                    out{k}=M1/Amid;
                end
                out{4}=ten(idsets{1,1},idsets{2,1},idsets{3,1});
                out{5}=idsets;
        end
        
    case 8% t(i1,j1,/i2,j2,k2)
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4),size(ten,5)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[sz(1)*sz(2),sz(3)*sz(4)*sz(5)]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz([1 2]) k]);
                M2=reshape(M2,[k,sz(3:5)]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3,id4,id5]=ind2sub(sz,id);
                idsets={[id1 id2],[id3 id4 id5]};
                maxrank=min(sz(1)*sz(2),prod(sz(3:5)));
                flag=0;
                for cardinterp=1:maxrank
                    Ik_=sub2indv2(sz(1:2),idsets{1,1});
                    Ik=sub2indv2(sz(3:5),idsets{1,2});
                    ten1=reshape(ten,[sz(1:2) prod(sz(3:5))]);
                    M1=ten1(:,:,Ik);
                    clear ten1
                    ten2=reshape(ten,[sz(1)*sz(2) prod(sz(3:5))]);
                    Amid=ten2(Ik_,Ik);
                    clear ten2
                    M1=tencontract(M1,3,3,Amid,2,1,'inv');
                    ten3=reshape(ten,[sz(1)*sz(2) sz(3:5)]);
                    M2=ten3(Ik_,:,:,:);
                    clear ten3
                    f2=tencontract(M1,3,3,M2,4,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3,id4,id5]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},[id1,id2],'rows');
                    idsetsR=union(idsets{1,2},[id3 id4 id5],'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};[id1,id2]];
                    idsets{1,2}=[idsets{1,2};[id3 id4 id5]];
                end
                if errmax<=tol
                    fprintf('Dimension ((1,2),(3,4,5)) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 9% t(i1,j1,/i2,j2,k2,k3)
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4),size(ten,5),size(ten,6)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[sz(1)*sz(2),prod(sz(3:6))]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz([1 2]) k]);
                M2=reshape(M2,[k,sz(3:6)]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3,id4,id5,id6]=ind2sub(sz,id);
                idsets={[id1 id2],[id3 id4 id5 id6]};
                maxrank=min(sz(1)*sz(2),prod(sz(3:6)));
                flag=0;
                for cardinterp=1:maxrank
                    Ik_=sub2indv2(sz(1:2),idsets{1,1});
                    Ik=sub2indv2(sz(3:6),idsets{1,2});
                    ten1=reshape(ten,[sz(1:2) prod(sz(3:6))]);
                    M1=ten1(:,:,Ik);
                    clear ten1
                    ten2=reshape(ten,[sz(1)*sz(2) prod(sz(3:6))]);
                    Amid=ten2(Ik_,Ik);
                    clear ten2
                    M1=tencontract(M1,3,3,Amid,2,1,'inv');
                    ten3=reshape(ten,[sz(1)*sz(2) sz(3:6)]);
                    M2=ten3(Ik_,:,:,:,:);
                    clear ten3
                    f2=tencontract(M1,3,3,M2,5,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3,id4,id5,id6]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},[id1,id2],'rows');
                    idsetsR=union(idsets{1,2},[id3 id4 id5 id6],'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};[id1,id2]];
                    idsets{1,2}=[idsets{1,2};[id3 id4 id5 id6]];
                end
                if errmax<=tol
                    fprintf('Dimension ((1,2),(3,4,5,6)) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 10% t(k1,i1,j1,/i2,j2,k2)
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4),size(ten,5),size(ten,6)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[prod(sz(1:3)),prod(sz(4:6))]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz(1:3) k]);
                M2=reshape(M2,[k,sz(4:6)]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3,id4,id5,id6]=ind2sub(sz,id);
                idsets={[id1 id2 id3],[id4 id5 id6]};
                maxrank=min(prod(sz(1:3)),prod(sz(4:6)));
                flag=0;
                for cardinterp=1:maxrank
                    Ik_=sub2indv2(sz(1:3),idsets{1,1});
                    Ik=sub2indv2(sz(4:6),idsets{1,2});
                    ten1=reshape(ten,[sz(1:3) prod(sz(4:6))]);
                    M1=ten1(:,:,:,Ik);
                    clear ten1
                    ten2=reshape(ten,[prod(sz(1:3)),prod(sz(4:6))]);
                    Amid=ten2(Ik_,Ik);
                    clear ten2
                    M1=tencontract(M1,4,4,Amid,2,1,'inv');
                    ten3=reshape(ten,[sz(1)*sz(2)*sz(3) sz(4:6)]);
                    M2=ten3(Ik_,:,:,:);
                    clear ten3
                    f2=tencontract(M1,4,4,M2,4,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3,id4,id5,id6]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},[id1,id2,id3],'rows');
                    idsetsR=union(idsets{1,2},[id4 id5 id6],'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};[id1,id2,id3]];
                    idsets{1,2}=[idsets{1,2};[id4 id5 id6]];
                end
                if errmax<=tol
                    fprintf('Dimension ((1,2,3),(4,5,6)) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 11% t(k1,i1,j1,/i2,j2,k2,k3)
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4),size(ten,5),size(ten,6),size(ten,7)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[prod(sz(1:3)),prod(sz(4:7))]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz(1:3) k]);
                M2=reshape(M2,[k,sz(4:7)]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3,id4,id5,id6,id7]=ind2sub(sz,id);
                idsets={[id1 id2 id3],[id4 id5 id6 id7]};
                maxrank=min(prod(sz(1:3)),prod(sz(4:7)));
                flag=0;
                for cardinterp=1:maxrank
                    Ik_=sub2indv2(sz(1:3),idsets{1,1});
                    Ik=sub2indv2(sz(4:7),idsets{1,2});
                    ten1=reshape(ten,[sz(1:3) prod(sz(4:7))]);
                    M1=ten1(:,:,:,Ik);
                    clear ten1
                    ten2=reshape(ten,[prod(sz(1:3)),prod(sz(4:7))]);
                    Amid=ten2(Ik_,Ik);
                    clear ten2
                    M1=tencontract(M1,4,4,Amid,2,1,'inv');
                    ten3=reshape(ten,[sz(1)*sz(2)*sz(3) sz(4:7)]);
                    M2=ten3(Ik_,:,:,:,:);
                    clear ten3
                    f2=tencontract(M1,4,4,M2,5,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3,id4,id5,id6,id7]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},[id1,id2,id3],'rows');
                    idsetsR=union(idsets{1,2},[id4 id5 id6 id7],'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};[id1,id2,id3]];
                    idsets{1,2}=[idsets{1,2};[id4 id5 id6 id7]];
                end
                if errmax<=tol
                    fprintf('Dimension ((1,2,3),(4,5,6,7)) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 12% t(k1,i1,j1,/i2,j2)
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4),size(ten,5)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[sz(1)*sz(2)*sz(3),sz(4)*sz(5)]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz(1:3) k]);
                M2=reshape(M2,[k,sz([4 5])]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3,id4,id5]=ind2sub(sz,id);
                idsets={[id1 id2 id3],[id4 id5]};
                maxrank=min(sz(1)*sz(2)*sz(3), sz(4)*sz(5));
                flag=0;
                for cardinterp=1:maxrank
                    Ik_=sub2indv2(sz(1:3),idsets{1,1});
                    Ik=sub2indv2(sz(4:5),idsets{1,2});
                    ten1=reshape(ten,[sz(1:3) sz(4)*sz(5)]);
                    M1=ten1(:,:,:,Ik);
                    clear ten1
                    ten2=reshape(ten,[sz(1)*sz(2)*sz(3) sz(4)*sz(5)]);
                    Amid=ten2(Ik_,Ik);
                    clear ten2
                    M1=tencontract(M1,4,4,Amid,2,1,'inv');
                    ten3=reshape(ten,[sz(1)*sz(2)*sz(3) sz(4:5)]);
                    M2=ten3(Ik_,:,:);
                    clear ten3
                    f2=tencontract(M1,4,4,M2,3,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3,id4,id5]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},[id1 id2 id3],'rows');
                    idsetsR=union(idsets{1,2},[id4 id5],'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};[id1 id2 id3]];
                    idsets{1,2}=[idsets{1,2};[id4 id5]];
                end
                if errmax<=tol
                    fprintf('Dimension ((1,2,3),(4,5)) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 13% t(k1,i,j,/k2)
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[prod(sz(1:3)),sz(4)]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz(1:3) k]);
                M2=reshape(M2,[k,sz(4)]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3,id4]=ind2sub(sz,id);
                idsets={[id1 id2 id3],id4};
                maxrank=min(prod(sz(1:3)),sz(4));
                flag=0;
                for cardinterp=1:maxrank
                    Ik_=sub2indv2(sz(1:3),idsets{1,1});
                    Ik=idsets{1,2};
                    ten1=reshape(ten,[sz(1:3) sz(4)]);
                    M1=ten1(:,:,:,Ik);
                    clear ten1
                    ten2=reshape(ten,[prod(sz(1:3)) sz(4)]);
                    Amid=ten2(Ik_,Ik);
                    clear ten2
                    ten3=reshape(ten,[prod(sz(1:3)) sz(4)]);
                    M2=ten3(Ik_,:);
                    clear ten3
                    M2=Amid\M2;%M1=tencontract(M1,4,4,Amid,2,1,'inv');
                    f2=tencontract(M1,4,4,M2,2,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3,id4]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},[id1,id2 id3],'rows');
                    idsetsR=union(idsets{1,2},id4,'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};[id1,id2 id3]];
                    idsets{1,2}=[idsets{1,2};id4];
                end
                if errmax<=tol
                    fprintf('Dimension ((1,2,3),4) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 14% t(k1,/i,j,k2), for Hadamard product
        sz=[size(ten,1),size(ten,2),size(ten,3),size(ten,4)];
        switch svdmode
            case 1
                [M1,S1,M2]=svd(reshape(ten,[sz(1),prod(sz(2:4))]),'econ');
                Sv=diag(S1);
                lSv=length(Sv);
                ra=sqrt(cumsum(Sv.^2))/norm(Sv);
                for k=1:lSv
                    if ra(k)>=1-tol
                        break
                    end
                end
                M1=reshape(M1(:,1:k)*S1(1:k,1:k),[sz(1) k]);
                M2=reshape(M2,[k,sz(2:4)]);
                out={M1,M2};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3,id4]=ind2sub(sz,id);
                idsets={id1,[id2 id3 id4]};
                maxrank=min(sz(1),prod(sz(2:4)));
                flag=0;
                for cardinterp=1:maxrank
                    Ik_=idsets{1,1};
                    Ik=sub2indv2(sz(2:4),idsets{1,2});
                    ten1=reshape(ten,[sz(1) prod(sz(2:4))]);
                    M1=ten1(:,Ik);
                    clear ten1
                    ten2=reshape(ten,[sz(1) prod(sz(2:4))]);
                    Amid=ten2(Ik_,Ik);
                    clear ten2
                    M1=tencontract(M1,2,2,Amid,2,1,'inv');
                    ten3=reshape(ten,[sz(1) sz(2:4)]);
                    M2=ten3(Ik_,:,:,:);
                    clear ten3
                    f2=tencontract(M1,2,2,M2,4,1);
                    valdoetemp=ten-f2;
                    [errmax,id]=max(abs(valdoetemp(:)));
                    errmax=errmax/val;
                    if errmax<=tol
                        break
                    end
                    [id1,id2,id3,id4]=ind2sub(sz,id);
                    idsetsL=union(idsets{1,1},id1,'rows');
                    idsetsR=union(idsets{1,2},[id2,id3,id4],'rows');
                    if size(idsetsL,1)~=size(idsetsR,1)
                        flag=1;
                        break
                    end
                    idsets{1,1}=[idsets{1,1};id1];
                    idsets{1,2}=[idsets{1,2};[id2,id3,id4]];
                end
                if errmax<=tol
                    fprintf('Dimension (1,(2,3,4)) converged at rank %i.\n',size(idsets{1,1},1));
                end
                fprintf('sweeping completed \n');
                if flag==0
                    out={M1,M2};
                else
                    out=0;
                end
        end
        
    case 15%for third-order symmetric tensor
        %symmetry is checked manually in advance
        sz=size(ten,1);
        switch svdmode
            case 1
                [M1,S1,ten2]=svd(reshape(ten,[sz sz*sz]),'econ');
                Sv1=diag(S1);
                lSv1=length(Sv1);
                ra1=sqrt(cumsum(Sv1.^2))/norm(Sv1);
                for k1=1:lSv1
                    if ra1(k1)>=1-tol
                        break
                    end
                end
                M1=M1(:,1:k1)*S1(1:k1,1:k1);
                [M2,S2,M3]=svd(reshape(ten2(:,1:k1)',[k1*sz,sz]),'econ');
                Sv2=diag(S2);
                lSv2=length(Sv2);
                ra2=sqrt(cumsum(Sv2.^2))/norm(Sv2);
                for k3=1:lSv2
                    if ra2(k3)>=1-tol
                        break
                    end
                end
                M3=reshape(S2(1:k3,1:k3)*M3,[k3,sz(3)]);
                M2=reshape(M2(:,1:k3),[k1,sz(2),k3]);
                [M2,S3,C]=svd(reshape(permute(M2,[2 1 3]),[sz(2) k1*k3]),'econ');
                Sv3=diag(S3);
                lSv3=length(Sv3);
                ra3=sqrt(cumsum(Sv3.^2))/norm(Sv3);
                for k2=1:lSv3
                    if ra3(k2)>=1-tol
                        break
                    end
                end
                C=ipermute(reshape(C(1:k2)',[k2 k1 k3]),[2 1 3]);
                out={M1;M2;M3;C};
            case 2
                [val,id]=max(abs(ten(:)));
                [id1,id2,id3]=ind2sub(sz*[1 1 1],id);
                idsets={id1,[id2,id3]};
                maxrank=sz;
                if maxrank>1
                    for nswps=1:maxrank
                        I1=setdiff(1:sz,idsets{1});
                        I2=setdiff(1:sz*sz,idsets{2});
                        Ik=sub2indv2(sz*[1 1],idsets{2});
                        ten1=reshape(ten,[sz sz*sz]);
                        M1=ten1(:,Ik);
                        Amid=M1(idsets{1},:);
                        M1=M1(I1,:)/Amid;
                        M2=ten1(idsets{1},I2);
                        valdoetemp=ten1(I1,I2)-M1*M2;
                        [errmax,id]=max(abs(valdoetemp(:)));
                        errmax=errmax/val;
                        if isempty(errmax)
                            errmax=0;
                        end
                        if errmax<=tol
                            fprintf('Dimension (1,(2,3)) converged at rank %i.\n',size(idsets{1},1));
                            break
                        end
                        [id1,idII]=ind2sub([length(I1),length(I2)],id);
                        [id2,id3]=ind2sub([sz sz],I2(idII));
                        idsets{1}=[idsets{1};I1(id1)];
                        idsets{2}=[idsets{2};[id2,id3]];
                    end
                    out={ten1(:,Ik)/Amid,ten(idsets{1},idsets{1},idsets{1})};
                else
                    out={1,ten};
                end
        end
                
end
end