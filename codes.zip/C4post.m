clear
add=[pwd '\atomcluster4\'];
%%
Eacs=zeros(5,5);
for k1=4:8
    for k2=1:5
        t=load([add,'n1a' num2str(k1) 'r6h' num2str(k2) 'ep2n3o.mat'],'Eac');
        Eacs(k1-3,k2)=t.Eac;
    end
end
hs=1./[10 8 6 4 2];
figure;
plot(hs,Eacs(1,:)-Eacs(1,1),'-o');hold on
plot(hs,Eacs(2,:)-Eacs(2,1),'-x');hold on
plot(hs,Eacs(3,:)-Eacs(3,1),'-*');hold on
plot(hs,Eacs(4,:)-Eacs(4,1),'-^');hold on
plot(hs,Eacs(5,:)-Eacs(5,1),'-v');hold on
xlabel('\it h /\rm Bohr');
ylabel('\it \Delta E_{\rm a}\rm/eV');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w','Units','centimeters','Position',[1.5 1.5 12 10],'PaperUnits','centimeters');
legend('\it a_{\rm0}\rm = 4 Bohr','\it a_{\rm0}\rm = 5 Bohr','\it a_{\rm0}\rm = 6 Bohr','\it a_{\rm0}\rm = 7 Bohr','\it a_{\rm0}\rm = 8 Bohr','Location','northwest');
saveas(gcf,'deltaEa_n1.fig');
export_fig(gcf, [pwd '\deltaEa_n1.pdf'], '-r2000', '-transparent');

Eacs=zeros(3,6);
for k=1:6
    if k==1
        t1=load([add,'n3a' num2str(k+3) 'r6h4ep2n3osgsim.mat'],'Eac');
        t2=load([add,'n3a' num2str(k+3) 'r6h4ep2n3osg.mat'],'Eac');
    else
        t1=load([add,'n3a' num2str(k+3) 'r6h5ep2n3osgsim.mat'],'Eac');
        t2=load([add,'n3a' num2str(k+3) 'r6h5ep2n3osg.mat'],'Eac');
    end
    Eacs(1,k)=t1.Eac;
    Eacs(2,k)=t2.Eac;
    Eacs(3,k)=Eacs(1,k)-Eacs(2,k);
end
Was=Eacs;
for k=1:6
    Was(1:2,k)=Was(1:2,k)-Eacs(1:2,5);
    Was(3,k)=(Was(1,k)-Was(2,k))/Was(2,k);
end
%%
Eacs=zeros(3,6);
for k=1:6
    if k==1
        t1=load([add,'n10a' num2str(k+3) 'r6h4ep2n3osgsim1.mat'],'Eac');
        t2=load([add,'n10a' num2str(k+3) 'r6h4ep2n3osgsim.mat'],'Eac');
        t3=load([add,'n10a' num2str(k+3) 'r6h4ep2n3osg.mat'],'Eac');
    else
        t1=load([add,'n10a' num2str(k+3) 'r6h5ep2n3osgsim1.mat'],'Eac');
        t2=load([add,'n10a' num2str(k+3) 'r6h5ep2n3osgsim.mat'],'Eac');
        t3=load([add,'n10a' num2str(k+3) 'r6h5ep2n3osg.mat'],'Eac');
    end
    Eacs(1,k)=t1.Eac;
    Eacs(2,k)=t2.Eac;
    Eacs(3,k)=t3.Eac;
end
Was=zeros(5,6);
for k=1:6
    Was(1:3,k)=Eacs(:,k)-Eacs(:,5);
    Was(4:5,k)=(Was([1 2],k)-Was(3,k))/Was(3,k);
end

%%
Eacs=zeros(5,5);
for k1=1:5
    for k2=1:5
        t=load([add,'n1a8r6y' num2str(k1) 'h' num2str(k2) 'ep2n3o.mat'],'Eac');
        Eacs(k1,k2)=t.Eac;
    end
end
hs=1./[10 8 6 4 2];
figure;
plot(hs,Eacs(1,:)-Eacs(1,1),'-o');hold on
plot(hs,Eacs(2,:)-Eacs(2,1),'-x');hold on
plot(hs,Eacs(3,:)-Eacs(3,1),'-*');hold on
plot(hs,Eacs(4,:)-Eacs(4,1),'-^');hold on
plot(hs,Eacs(5,:)-Eacs(5,1),'-v');hold on
xlabel('\it h /\rm Bohr');
ylabel('\it \Delta E_{\rm a}\rm/eV');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w','Units','centimeters','Position',[1.5 1.5 12 10],'PaperUnits','centimeters');
legend('\it \gamma\rm = 0','\it \gamma\rm = 0.3','\it \gamma\rm = 0.6','\it \gamma\rm = 0.9','\it \gamma\rm = 1.2','Location','southwest');
saveas(gcf,'deltaEa_n1_2.fig');
export_fig(gcf, [pwd '\deltaEa_n1_2.pdf'], '-r2000', '-transparent');
%%
Eacs=zeros(3,5);
for k=1:5
    t1=load([add,'n3a8r6y' num2str(k) 'h4ep2n3osgsim.mat'],'Eac');
    t2=load([add,'n3a8r6y' num2str(k) 'h4ep2n3o.mat'],'Eac');
    Eacs(1,k)=t1.Eac;
    Eacs(2,k)=t2.Eac;
    Eacs(3,k)=Eacs(1,k)-Eacs(2,k);
end
Was=Eacs;
for k=1:5
    Was(1:2,k)=Was(1:2,k)-Eacs(1:2,1);
    Was(3,k)=(Was(1,k)-Was(2,k))/Was(2,k);
end

%%
Eacs=zeros(3,5);
for k=1:5
    t1=load([add,'n10a8r6y' num2str(k) 'h4ep2n3osgsim1.mat'],'Eac');
    t2=load([add,'n10a8r6y' num2str(k) 'h4ep2n3osg.mat'],'Eac');
    Eacs(1,k)=t1.Eac;
    Eacs(2,k)=t2.Eac;
    Eacs(3,k)=Eacs(1,k)-Eacs(2,k);
end
Was=Eacs;
for k=1:5
    Was(1:2,k)=Was(1:2,k)-Eacs(1:2,1);
    Was(3,k)=(Was(1,k)-Was(2,k))/Was(2,k);
end