function t=extend(a,n)
t=zeros(size(a)+2*(n+1));
t((n+1)+1:end-(n+1),(n+1)+1:end-(n+1),(n+1)+1:end-(n+1))=a;
end