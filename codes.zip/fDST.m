function out=fDST(v,method)
%fast discrete sine transform using FFT
%The inverse transform coincides with itself.
switch method
    case 1
        N=size(v,1);
        m=size(v,2);
        f=fft([zeros(1,m);v;zeros(1,m);-v(end:-1:1,:)]);
        f=-imag(f)/2;
        out=sqrt(2/(N+1))*f(2:N+1,:);
    case 2
        N=size(v,1);
        m=size(v,2);
        f=fft([zeros(1,m);sin((1:N)'/(N+1)*pi).*(v+v(end:-1:1,:))+0.5*(v-v(end:-1:1,:))]);
        R=real(f);
        I=imag(f);
        out=zeros(N+1,m);
        id=1:N+1;
        id1=id(1:2:end);
        id2=setdiff(id,id1);
        n1=length(id1);
        n2=N+1-n1;
        out(id1,:)=-I(1:n1,:);
        R(1,:)=R(1,:)/2;
        R=cumsum(R(1:n2,:),1);
        out(id2,:)=R(1:n2,:);
        out=sqrt(2/(N+1))*out(2:N+1,:);
end
end