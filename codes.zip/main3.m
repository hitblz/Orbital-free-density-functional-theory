clear
a0=8;
ncell=[1 1 1];
t=load('Al_single4.mat','h');h=t.h;
t=load('Al_single4.mat','br');br=t.br;
t=load('Al_single4.mat','N');Nsig=t.N;
t=load('Al_single4.mat','bm');t=t.bm;bmsig=t{1};
t=load('Al_single4.mat','phi');phisig=t.phi;
t=load('Al_single4.mat','uL0');uL0sig=normalize(t.uL0,3,h);
rhosig=uL0sig.^2;
% t=load('Al_1near.mat','rhoext');rhosig=t.rhoext;
fa=2;
tol=1e-10;
rho=assem3(1,a0,ncell,rhosig,h);%rho obtained
u=funv4(1,@sqrt,rho,tol);%u obtained
Amat=cell(4,1);
M=cell(4,1);
for k=1:3
    N=size(u{k},1);
    s1=[2*ones(N,1);-1*ones(N-1,1);-1*ones(N-1,1)];
    s2=[2/3*ones(N,1);1/6*ones(N-1,1);1/6*ones(N-1,1)];
    Amat{k}=[s1,s2];
    M{k}=s2;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat{4}=c*h;
M{4}=h^3;
Au=Tucker3matvec(Amat,u,tol);
lam=0.2;
E1=lam/2*Tucker3inprod(1,u,Au);

frho=funv4(1,@kxcrho,rho,tol);
E2=tucker3product(frho{4},sum(frho{1}),sum(frho{2}),sum(frho{3})).*h^3;

rhom=Tucker3matvec(M,rho,tol);
bm=assem3(1,a0,ncell,bmsig,h);
rhobm=Tucker3vecplus(rhom,bm,tol);
phi=assem3(1,a0,ncell,phisig,h);
E3=1/2*Tucker3inprod(1,rhobm,phi);

% ra=8*fa;Va=pseudopotential(ra);
Va=pseudopotential(8);
% Visig=ppten(Va,Nsig+1,h,tol,fa);
Vsig=ppten(Va,Nsig+1,h,tol,1);
% Vcsig=tucker3product(Visig)-tucker3product(Vsig);

% bimsig=nucchasig(br,Nsig+1,h,tol,fa);
bimsig=bmsig;
bimsig(:,:,:)=0;
sz=size(bimsig);
bimsig((sz(1)+1)/2,(sz(2)+1)/2,(sz(3)+1)/2)=-3;

N0=Nsig+2;
As=zeros(N0,N0,2);
for k=1:N0
    if k==1 || k==N0
        As(k,k,1)=1;
        As(k,k,2)=1/3;
    else
        As(k,k,1)=2;
        As(k,k,2)=2/3;
    end
end
for k=1:N0-1
    As(k+1,k,1)=-1;
    As(k,k+1,1)=-1;
    As(k+1,k,2)=1/6;
    As(k,k+1,2)=1/6;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
A0={As;As;As;c.*h};
t=((-(Nsig+1)/2:(Nsig+1)/2)').^2+(-(Nsig+1)/2:(Nsig+1)/2).^2+((Nsig+1)/2).^2;
t=-3./(sqrt(t).*h);
w=zeros(N0,N0,N0);
w(1,:,:)=t;
w(end,:,:)=t;
w(:,1,:)=t;
w(:,end,:)=t;
w(:,:,1)=t;
w(:,:,end)=t;
Kw=1/(4*pi)*Tucker3matvec2(A0,w);
Kw=Kw(2:N0-1,2:N0-1,2:N0-1);

lambda=@(k) 2-2*cos(k*pi/(Nsig+1));%increasing
mu=@(k) 2/3+1/3*cos(k*pi/(Nsig+1));%decreasing
muN=mu((1:Nsig)');
LmuN=lambda((1:Nsig)')./muN;
imuN=muN.^(-1);
Visig=invIvecsig2(1/(4*pi),h,LmuN,imuN,bimsig-Kw);
Vcsig=Visig-tucker3product(Vsig);

% bbsig=tucker3product(bimsig)+bmsig;
bbsig=bimsig+bmsig;
Vc=assem3(1,a0,ncell,Vcsig,h);
bb=assem3(1,a0,ncell,bbsig,h);
Na=4*prod(ncell)+2*(ncell(1)*ncell(2)+ncell(1)*ncell(3)+ncell(2)*ncell(3))+sum(ncell)+1;
Ecr=1/2*(Tucker3inprod(1,bb,Vc)-Na*bimsig(:)'*Visig(:));

E=E1+E2+E3+Ecr;
Ea=E/Na*27.2114;

Vsig=tucker3product(Vsig);
Ecr2=-1/2*Na*bmsig(:)'*Vsig(:);
Eii=E1+E2+E3+Ecr2;
E2a=Eii/Na*27.2114;

E4=-1/2*Na*bmsig(:)'*Vsig(:);
Ecr3=1/2*(Tucker3inprod(1,bb,Vc)-Na*bimsig(:)'*Visig(:)+Na*bmsig(:)'*Vsig(:));
Et=E1+E2+E3+E4+Ecr3;
Eta=Et/Na*27.2114;
% Vc2=assem3(1,a0,ncell,Vcsig2,h);
% Ecr32=1/2*(Tucker3inprod(1,bb,Vc2)-Na*Tucker3inprod(1,bimsig,Visig)+Na*bmsig(:)'*Vsig(:));