add1='E:\my codes\Lattice-DFT\newdata\';
load('E:\my codes\Lattice-DFT\newdata\a1h1ep1.mat');
add='E:\my codes\Lattice-DFT\';
%%
figure;
plot(br);
xlabel('\it r/\rm Bohr');
ylabel('\it b_{\rm a}\rm(\it r\rm)');
legend();
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 12 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'brfig.fig');
export_fig(gcf, [add 'brfig.pdf'], '-r2000', '-transparent');
%%
E0evref=E0ev;
Eevm=zeros(5,4);
for nep=1:5
    for nh=1:4
        t=load(['E:\my codes\Lattice-DFT\newdata\a1h' num2str(nh) 'ep' num2str(nep) '.mat'],'E0ev');
        Eevm(nep,nh)=t.E0ev;
    end
end
figure;
plot(hf,(E0evref-Eevm(1,:))./E0evref,'-o');hold on
plot(hf,(E0evref-Eevm(2,:))./E0evref,'-+');hold on
plot(hf,(E0evref-Eevm(3,:))./E0evref,'-*');hold on
plot(hf,(E0evref-Eevm(4,:))./E0evref,'-x');hold on
plot(hf,(E0evref-Eevm(5,:))./E0evref,'-^');hold on
xlabel('\it h_{\rm [0]}/\rm Bohr');
ylabel('\it \epsilon_{\rm E,r}');
legend('\epsilon=1\times 10^{-8}','\epsilon=1\times 10^{-7}','\epsilon=1\times 10^{-6}','\epsilon=1\times 10^{-5}','\epsilon=1\times 10^{-4}',...
    'Location','southeast');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 12 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'2_ex1.fig');
export_fig(gcf, [add '2_ex1.pdf'], '-r2000', '-transparent');

%%
E0evref=E0ev;
Eevm=zeros(10,4);
hs=zeros(5,4);
for nRa=1:5
    for nh=1:4
        t=load(['E:\my codes\Lattice-DFT\newdata\a' num2str(nRa) 'h' num2str(nh) 'ep1.mat'],'E0ev');
        Eevm(2*nRa-1,nh)=t.E0ev;
        t=load(['E:\my codes\Lattice-DFT\newdata\a' num2str(nRa) 'h' num2str(nh) 'ep5.mat'],'E0ev');
        Eevm(2*nRa,nh)=t.E0ev;
        t=load(['E:\my codes\Lattice-DFT\newdata\a' num2str(nRa) 'h' num2str(nh) 'ep1.mat'],'h');
        hs(2*nRa-1,nh)=t.h;
        t=load(['E:\my codes\Lattice-DFT\newdata\a' num2str(nRa) 'h' num2str(nh) 'ep5.mat'],'h');
        hs(2*nRa,nh)=t.h;
    end
end
figure;
plot(hs(1,:),(E0evref-Eevm(1,:))./E0evref,'-o');hold on
plot(hs(2,:),(E0evref-Eevm(2,:))./E0evref,'--o');hold on
plot(hs(3,:),(E0evref-Eevm(3,:))./E0evref,'-+');hold on
plot(hs(4,:),(E0evref-Eevm(4,:))./E0evref,'--+');hold on
plot(hs(5,:),(E0evref-Eevm(5,:))./E0evref,'-*');hold on
plot(hs(6,:),(E0evref-Eevm(6,:))./E0evref,'--*');hold on
plot(hs(7,:),(E0evref-Eevm(7,:))./E0evref,'-x');hold on
plot(hs(8,:),(E0evref-Eevm(8,:))./E0evref,'--x');hold on
plot(hs(9,:),(E0evref-Eevm(9,:))./E0evref,'-^');hold on
plot(hs(10,:),(E0evref-Eevm(10,:))./E0evref,'--^');hold on
xlabel('\it h_{\rm [0]}/\rm Bohr');
ylabel('\it \epsilon_{\rm E,r}');
legend('\epsilon=1\times 10^{-8}, \it R_{\rm a}=\rm 8',...
    '\epsilon=1\times 10^{-4}, \it R_{\rm a}=\rm 8',...
    '\epsilon=1\times 10^{-8}, \it R_{\rm a}=\rm 7.2',...
    '\epsilon=1\times 10^{-4}, \it R_{\rm a}=\rm 7.2',...
    '\epsilon=1\times 10^{-8}, \it R_{\rm a}=\rm 6.4',...
    '\epsilon=1\times 10^{-4}, \it R_{\rm a}=\rm 6.4',...
    '\epsilon=1\times 10^{-8}, \it R_{\rm a}=\rm 5.6',...
    '\epsilon=1\times 10^{-4}, \it R_{\rm a}=\rm 5.6',...
    '\epsilon=1\times 10^{-8}, \it R_{\rm a}=\rm 4.8',...
    '\epsilon=1\times 10^{-4}, \it R_{\rm a}=\rm 4.8',...
    'Location','eastoutside');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 18 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'2_ex2.fig');
export_fig(gcf, [add '2_ex2.pdf'], '-r2000', '-transparent');

