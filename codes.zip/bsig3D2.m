function [bmsig,varargout]=bsig3D2(Va,n,h,Ra,coor,Amat1,varargin)
na=floor(Ra/h);
grid1=-coor(1)-(na+n)*h:h:h-coor(1)+(na+n)*h;%in the local coordinate system, the ion is located at the origin.
grid2=-coor(2)-(na+n)*h:h:h-coor(2)+(na+n)*h;
grid3=-coor(3)-(na+n)*h:h:h-coor(3)+(na+n)*h;
grid1=grid1';
grid3=permute(grid3,[1 3 2]);
Vsig=Va(sqrt(grid1.^2+grid2.^2+grid3.^2));
bmsig=1/(4*pi)*Tucker3matvec2(Amat1,Vsig);
bmsig=cutedge(bmsig,n);
if nargout>1
    g=cell(3,1);
    Amat2=varargin{1};
    for k=1:3
        g{k}=Tucker3matvec2(Amat2(k,:),extend(bmsig,n));
    end
    g=cutedge(g,n);
    varargout{1}=g;
end
end