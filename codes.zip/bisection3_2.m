function [vkadk,ukadk,Evkadk,gvkadk,phivkadk]=bisection3_2(r,Ra,vk,uk,dk,Evk,gvk,phik,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2)
%an analogue of bisection
% bisection line search algorithm with strong Wolfe condition
% flag=1;
gkTdk=gvk(:)'*dk(:);
%searching for a 'crossing interval'
alpha_=0;%fixed
alpha=1;
epsilon=1e-4;
fpa_=gkTdk;
if fpa_>0
    vkadk=vk;
    ukadk=uk;
    Evkadk=Evk;
    gvkadk=gvk;
    phivkadk=phik;
    return
end
[fpa,vkadk,ukadk,Evkadk,gvkadk,phivkadk]=fp(alpha,r,Ra,vk,dk,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2);
wcheckh=@(alpha,Evkadk,gvkadk) Wolfecheck(dk,alpha,Evkadk,gvkadk,Evk,gkTdk);
if wcheckh(alpha,Evkadk,gvkadk)
    return
end
jmax=30;
flag=0;
for j=1:jmax
    if fpa>0
        flag=1;
        break
    else
        alpha_=alpha;
        alpha=2*alpha;
        fpa_=fpa;
        [fpa,vkadk,ukadk,Evkadk,gvkadk,phivkadk]=fp(alpha,r,Ra,vk,dk,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2);
        if wcheckh(alpha,Evkadk,gvkadk)
%             flag=1;
            return
        end
    end
end
lref=alpha-alpha_;
a=alpha_;
b=alpha;
fa=fpa_;
fb=fpa;
%secant search begin
if flag==1
    itmax=30;
    for j=1:itmax
        if (b-a)/lref<epsilon
            break
        end
        x=(a+b)/2;
        [fx,vkadk,ukadk,Evkadk,gvkadk,phivkadk]=fp(x,r,Ra,vk,dk,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2);
        if wcheckh(x,Evkadk,gvkadk)
            return
        end
        if fx>0
            x0=a-(a-x)*fa/(fa-fx);
            [fx0,vkadk,ukadk,Evkadk,gvkadk,phivkadk]=fp(x0,r,Ra,vk,dk,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2);
            if wcheckh(x0,Evkadk,gvkadk)
                return
            end
            if fx0>0
                b=x0;
                fb=fx0;
            else
                a=x0;
                b=x;
                fa=fx0;
                fb=fx;
            end
        else
            x0=b-(b-x)*fb/(fb-fx);
            [fx0,vkadk,ukadk,Evkadk,gvkadk,phivkadk]=fp(x0,r,Ra,vk,dk,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2);
            if wcheckh(x0,Evkadk,gvkadk)
                return
            end
            if fx0>0
                a=x;
                b=x0;
                fa=fx;
                fb=fx0;
            else
                a=x0;
                fa=fx0;
            end
        end
    end
    x=(a+b)/2;
    [~,vkadk,ukadk,Evkadk,gvkadk,phivkadk]=fp(x,r,Ra,vk,dk,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2);
else
%     error('failed to find a crossing interval in %i iterations\n',jmax);
    fprintf('failed to find a crossing interval in %i iterations\n',jmax);
end
end
function [val,varargout]=fp(a,r,Ra,vk,dk,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2)
vkadk=vk+a*dk;
[Evkadk,ukadk,gvkadk,phivkadk]=EcgEc4_2(r,Ra,v,nele,h,Amat,bm,V,lambdaN,Va,n,V0,lambda0,Amat1,M,P1,v1,v2);
val=dk(:)'*gvkadk(:);
varargout{1}=vkadk;
varargout{2}=ukadk;
varargout{3}=Evkadk;
varargout{4}=gvkadk;
varargout{5}=phivkadk;
end
function out=Wolfecheck(dk,alpha,Evkadk,gvkadk,Evk,gkTdk)
sig1=0.01;
sig2=0.05;
gukadkTdk=gvkadk(:)'*dk(:);
out=(Evkadk<=Evk+sig1*alpha*gkTdk) && (abs(gukadkTdk)<=sig2*abs(gkTdk));
end