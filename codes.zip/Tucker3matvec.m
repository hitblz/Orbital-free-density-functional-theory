function out=Tucker3matvec(mat,vec,tol)
%matrix-vector product
if isequal(vec{4},0)
    out={0;0;0;0};
else
    out=cell(4,1);
    sd=cell(1,3);
    for k=1:3
        t=tensordecompose(5,trimatvec(mat{k},vec{k}),tol,2);
        out{k}=t{1};
        sd{k}=t{2};
    end
    for k=1:3
        if k==1
            t=tencontract(sd{k},3,3,vec{4},3,1);
        elseif k==2
            t=tencontract(sd{k},3,3,t,4,3);
        else
            t=tencontract(sd{k},3,3,t,5,5);
        end
    end
    t=tencontract(permute(t,[5 3 1 6 4 2]),6,[4 5 6],mat{4},3,[1 2 3]);
    C=tensordecompose(7,t,tol,2);
    out{4}=C{4};
    for j=1:3
        out{j}=out{j}*C{j};
    end
end
end