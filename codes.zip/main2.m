clear
add='E:\my codes\Lattice-DFT\singleatom\';
fl='a1h4ep3.mat';
%% V-multigrid
t=load([add fl],'nele');nele=t.nele;
t=load([add fl],'h');h=t.h;
t=load([add fl],'Vsig');Vsig=t.Vsig;
t=load([add fl],'uL0');uL0sig=normalize(t.uL0,nele,h);
t=load([add fl],'bm');bmsig=t.bm;bmsig=bmsig{1};
t=load([add fl],'N');Nsig=t.N;
% F=[0,0.2,0;0,0,0;0,0,0];
a0=8;
r0=[1/2,1/2,1/2;-1/2,1/2,1/2;-1/2,-1/2,1/2;1/2,-1/2,1/2;1/2,1/2,-1/2;-1/2,1/2,-1/2;-1/2,-1/2,-1/2;1/2,-1/2,-1/2;...
    0,0,1/2;0,0,-1/2;1/2,0,0;-1/2,0,0;0,1/2,0;0,-1/2,0]'*a0;
% r0=[0,0,0;1/2,0,1/2;1/2,0,-1/2;-1/2,0,1/2;-1/2,0,-1/2;1/2,1/2,0;1/2,-1/2,0;-1/2,1/2,0;-1/2,-1/2,0;0,1/2,1/2;0,-1/2,1/2;0,1/2,-1/2;0,-1/2,-1/2]'*a0;
%r=(eye(3)+F)*r0;
r=r0;
rhosig=uL0sig.^2;
rhoi=assem1(rhosig,r,h);
uL0i=sqrt(rhoi);
uL0=uL0i;
bL0=assem1(bmsig,r,h);

szu=size(uL0);
%pre-computing prolongation and restriction operator
P=cell(4,2);%prolongation
R=cell(4,2);%restriction
for i=1:2
    szut=(szu+1)/2^i-1;
    for k=1:3
        P{k,i}=zeros(2*szut(k)+1,szut(k));
        for k2=1:szut(k)
            P{k,i}(2*k2-1:2*k2+1,k2)=[0.5;1;0.5];
        end
        R{k,i}=P{k,i}'./2;
    end
    P{4,i}=1;
    R{4,i}=1;
end
%%
Na=size(r0,2);%number of atoms
nele=Na*nele;
% Amat=cell(1,4);
% M=cell(1,4);
% LmuN=cell(1,3);
% imuN=cell(1,3);
% for i=1:3
%     N=size(uL0,i);
%     As=zeros(N,N,2);
%     for k=1:N
%         As(k,k,1)=2;
%         As(k,k,2)=2/3;
%     end
%     for k=1:N-1
%         As(k+1,k,1)=-1;
%         As(k,k+1,1)=-1;
%         As(k+1,k,2)=1/6;
%         As(k,k+1,2)=1/6;
%     end
%     Amat{i}=As;
%     M{i}=As(:,:,2);
%     lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
%     mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
%     muN=mu((1:N)');
%     LmuN{i}=lambda((1:N)')./muN;
%     imuN{i}=muN.^(-1);
% end
% c=zeros(2,2,2);
% c(1,2,2)=1;
% c(2,1,2)=1;
% c(2,2,1)=1;
% Amat{4}=c.*h;
% M{4}=h^3;
%[EuL0i,guL0i,phiL0i]=EcgEc(1,uL0i,nele,h,Amat,bL0,LmuN,imuN,M,0,0,0);%对后续计算没有实际用途，仅作为参照。
flags=[0 0 0];
for it=1:30
    for level=0:2
        switch level
            case 0
                [uL0,EuL0,guL0,phiL0,flag,ad]=VM3(it,uL0,nele,h,bL0,P,R,0,0);
                flags(1)=flag;
                if flags(1)==1
                    break
                end
            case 1
                if flags(2)==0
                    uL1i=Tucker3matvec2(R(:,1)',uL0);
                    bL1=Tucker3matvec2({P{1,1}',P{2,1}',P{3,1}',1},bL0);
                    [uL1,EuL1,guL1,phiL1,flag,v1]=VM3(it,uL1i,nele,h,bL1,P,R,guL0,0);
                    flags(2)=flag;
                end
            case 2
                if flags(3)==0
                    uL2i=Tucker3matvec2(R(:,2)',uL1);
                    bL2=Tucker3matvec2({P{1,2}',P{2,2}',P{3,2}',1},bL1);
                    [uL2,EuL2,guL2,phiL2,flag]=VM3(it,uL2i,nele,h,bL2,P,R,guL0,guL1,v1);
                    flags(3)=flag;
                end
        end
    end
    if flags(1)==1
        break
    end
    if flags(3)==0
        e=Tucker3matvec2(P(:,2)',uL2-uL2i);
        Amat=cell(1,4);
        M=cell(1,4);
        muN=cell(1,3);
        LmuN=cell(1,3);
        imuN=cell(1,3);
        for i=1:3
            N=size(e,i);
            As=zeros(N,N,2);
            for k=1:N
                As(k,k,1)=2;
                As(k,k,2)=2/3;
            end
            for k=1:N-1
                As(k+1,k,1)=-1;
                As(k,k+1,1)=-1;
                As(k+1,k,2)=1/6;
                As(k,k+1,2)=1/6;
            end
            Amat{i}=As;
            M{i}=As(:,:,2);
            lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
            mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
            muN{i}=mu((1:N)');
            LmuN{i}=lambda((1:N)')./muN{i};
            imuN{i}=muN{i}.^(-1);
        end
        c=zeros(2,2,2);
        c(1,2,2)=1;
        c(2,1,2)=1;
        c(2,2,1)=1;
        Amat{4}=c.*(2*h);
        M{4}=(2*h)^3;
        [uL1,EuL1,guL1,phiL1,flag]=bisection(uL1,e,EuL1,guL1,phiL1,nele,h,Amat,bL1,LmuN,imuN,M,P,v1,0);
    end
    if flags(2)==0
        e=Tucker3matvec2(P(:,1)',uL1-uL1i);
        Amat=cell(1,4);
        M=cell(1,4);
        muN=cell(1,3);
        LmuN=cell(1,3);
        imuN=cell(1,3);
        for i=1:3
            N=size(e,i);
            As=zeros(N,N,2);
            for k=1:N
                As(k,k,1)=2;
                As(k,k,2)=2/3;
            end
            for k=1:N-1
                As(k+1,k,1)=-1;
                As(k,k+1,1)=-1;
                As(k+1,k,2)=1/6;
                As(k,k+1,2)=1/6;
            end
            Amat{i}=As;
            M{i}=As(:,:,2);
            lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
            mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
            muN{i}=mu((1:N)');
            LmuN{i}=lambda((1:N)')./muN{i};
            imuN{i}=muN{i}.^(-1);
        end
        c=zeros(2,2,2);
        c(1,2,2)=1;
        c(2,1,2)=1;
        c(2,2,1)=1;
        Amat{4}=c.*h;
        M{4}=h^3;
        [uL0,EuL0,guL0,phiL0,flag]=bisection(uL0,e,EuL0,guL0,phiL0,nele,h,Amat,bL0,LmuN,imuN,M,P,0,0);
    end
end

% uL0=normalize(uL0,nele,h);
% rho=uL0.^2;
% [rhoa,itv]=assem2(uL0sig.^2,r,h);
% wa=rhoa./rhoi;
% rhoext=wa.*rho;
% rhoext=rhoext(itv(1,1):itv(1,2),itv(2,1):itv(2,2),itv(3,1):itv(3,2));
% rhore=assem1(rhoext,r,h);
% uL0re=sqrt(rhore);
% uL0re=normalize(uL0re,nele,h);
% [EuL0re,guL0re,phiL0re]=EcgEc(1,uL0re,nele,h,Amat,bL0,LmuN,imuN,M,0,0,0);

Amat=cell(1,4);
M=cell(1,4);
LmuN=cell(1,3);
imuN=cell(1,3);
for i=1:3
    N=size(uL0,i);
    As=zeros(N,N,2);
    for k=1:N
        As(k,k,1)=2;
        As(k,k,2)=2/3;
    end
    for k=1:N-1
        As(k+1,k,1)=-1;
        As(k,k+1,1)=-1;
        As(k+1,k,2)=1/6;
        As(k,k+1,2)=1/6;
    end
    Amat{i}=As;
    M{i}=As(:,:,2);
    lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    muN=mu((1:N)');
    LmuN{i}=lambda((1:N)')./muN;
    imuN{i}=muN.^(-1);
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat{4}=c.*h;
M{4}=h^3;

Mu=Tucker3matvec2(M,uL0);
inprodu=uL0(:)'*Mu(:);
a=sqrt(nele/inprodu);
uL0=uL0.*a;
%%
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat,uL0);
E1=lam/2.*uL0(:)'*t(:);
%second part of kinematic energy + Exc
fu=kxc(uL0);
E2=sum(fu,'all')*h^3;
%E-I interaction energy
u2=uL0.^2;
t=Tucker3matvec2(M,phiL0);
E3=1/2*(u2(:)'*t(:)+bL0(:)'*phiL0(:));
E4=-1/2*Na*bmsig(:)'*Vsig(:);

bimsig=bmsig;
bimsig(:,:,:)=0;
sz=size(bimsig);
bimsig((sz(1)+1)/2,(sz(2)+1)/2,(sz(3)+1)/2)=-3;

N0=Nsig+2;
As=zeros(N0,N0,2);
for k=1:N0
    if k==1 || k==N0
        As(k,k,1)=1;
        As(k,k,2)=1/3;
    else
        As(k,k,1)=2;
        As(k,k,2)=2/3;
    end
end
for k=1:N0-1
    As(k+1,k,1)=-1;
    As(k,k+1,1)=-1;
    As(k+1,k,2)=1/6;
    As(k,k+1,2)=1/6;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
A0={As;As;As;c.*h};
t=((-(Nsig+1)/2:(Nsig+1)/2)').^2+(-(Nsig+1)/2:(Nsig+1)/2).^2+((Nsig+1)/2).^2;
t=-3./(sqrt(t).*h);
w=zeros(N0,N0,N0);
w(1,:,:)=t;
w(end,:,:)=t;
w(:,1,:)=t;
w(:,end,:)=t;
w(:,:,1)=t;
w(:,:,end)=t;
Kw=1/(4*pi)*Tucker3matvec2(A0,w);
Kw=Kw(2:N0-1,2:N0-1,2:N0-1);

lambda=@(k) 2-2*cos(k*pi/(Nsig+1));%increasing
mu=@(k) 2/3+1/3*cos(k*pi/(Nsig+1));%decreasing
muN=mu((1:Nsig)');
LmuN=lambda((1:Nsig)')./muN;
imuN=muN.^(-1);
Visig=invIvecsig2(1/(4*pi),h,LmuN,imuN,bimsig-Kw);
Vcsig=Visig-Vsig;

bbsig=bimsig+bmsig;
Vc=assem1(Vcsig,r,h);
bb=assem1(bbsig,r,h);
Ec=1/2*(bb(:)'*Vc(:)-Na*bimsig(:)'*Visig(:)+Na*bmsig(:)'*Vsig(:));

E0=E1+E2+E3+E4+Ec;
E0aev=E0/Na*27.2114;