function [out,bvs]=Eco(Va,n,r,h,Ra,V0,lambda0,Amat1)

r=r';
votexm=min(r,[],1)-Ra;
votexM=max(r,[],1)+Ra;
ndiv=ceil((votexM-votexm)./h)+1;
ndiv=ndiv+(mod(ndiv,4)>0).*(4-mod(ndiv,4));
dis=r-votexm;
ns=floor(dis./h);
coors=dis-ns*h;
n1=floor((dis-Ra)/h);
M=size(r,1);
bb=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
Vc=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
bvs=zeros(1,2);
for k=1:M
    bmsig=bsig3D(Va,n,h,Ra,coors(k,:),Amat1);
    bimsig=bsig3D1(n,h,Ra,coors(k,:));
%     bmsig=bmsig(1:end-1,1:end-1,1:end-1);
%     bimsig=bimsig(1:end-1,1:end-1,1:end-1);
    b_bmsig=bimsig-bmsig;
    bbmsig=bimsig+bmsig;
    szv=size(bbmsig);
    bb(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))=bb(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))+bbmsig;
    Vcsig=invIvecsig3(1/(4*pi),h,V0,lambda0,b_bmsig);       
    Vc(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))=Vc(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))+Vcsig;
    Vsig=Vasig3D(Va,n,h,Ra,coors(k,:));
    Visig=Vcsig+Vsig;
    bvs(1)=bvs(1)+bimsig(:)'*Visig(:);
    bvs(2)=bvs(2)+bmsig(:)'*Vsig(:);
end
out=1/2*(bb(:)'*Vc(:)-bvs(1)+bvs(2));
end