function [uk1,Ek1,gk1,phik1,varargout]=VM(it,uk,phii,nele,h,Amat,bm,LmuN,imuN,tol,P,R,guL0,guL1,normgk0,varargin)
%V-cycle multigrid
epsilon=1e-8;
if isequal(guL0,0)
    %optimization begin
    maxit=3;% for fast initialization
    [Ek,gk,phik]=EcgEcsig2(1,uk,nele,h,Amat,bm,LmuN,imuN,tol,0,0,0,phii);
    dk=gk;
    dk{4}=-dk{4};
    flag=0;
%     normgk0=sqrt(Tucker3inprod(1,gk,gk));
    for k=1:maxit
        [uk1,Ek1,gk1,phik1]=bisectionsig2(uk,dk,Ek,gk,nele,h,Amat,bm,LmuN,imuN,tol,0,0,0,phik);
        rnormgk1=sqrt(Tucker3inprod(1,gk1,gk1))/normgk0;
        
        if k==1
            figure;
            title(['cycle ' num2str(it) 'level 0']);
            xlabel('iteration number');
            ylabel('relative error of the gradient');
            fg=animatedline(k,rnormgk1);
        else
            addpoints(fg,k,rnormgk1);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnormgk1<epsilon
            varargout{1}=1;
            close(gcf);
            inprodu=Tucker3inprod(2,uk1,uk1,[h h h],tol);
            uk1{4}=uk1{4}*sqrt(nele/inprodu);
            fprintf('Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnormgk1);
            break
        end
        betak=(Tucker3inprod(1,gk1,gk1)-Tucker3inprod(1,gk,gk1))/Tucker3inprod(1,gk,gk);%PR
        %   betak=Tucker3inprod(1,gk1,gk1)/Tucker3inprod(1,gk,gk);
        betakdk=dk;
        betakdk{4}=betak*betakdk{4};
        gk1_=gk1;
        gk1_{4}=-gk1{4};
        dk1=Tucker3vecplus(gk1_,betakdk,tol);
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
        varargout{1}=flag;
    end
    %optimization end, get uk1 and gk1
elseif isequal(guL1,0)
    guL0_=guL0;
    for k=1:3
        guL0_{k}=R{k,1}*guL0_{k};
    end
    guL0_{4}=-guL0_{4};
    gk=gEcsig2(uk,nele,h,Amat,bm,LmuN,imuN,tol,P,0,phii);
    v1=Tucker3vecplus(gk,guL0_,tol);
    varargout{1}=v1;
    %optimization begin
    maxit=4;% for fast initialization
    [Ek,gk,phik]=EcgEcsig2(1,uk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,0,phii);
    dk=gk;
    dk{4}=-dk{4};
%     normgk0=sqrt(Tucker3inprod(1,gk,gk));
    for k=1:maxit
        [uk1,Ek1,gk1,phik1]=bisectionsig2(uk,dk,Ek,gk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,0,phik);
        rnormgk1=sqrt(Tucker3inprod(1,gk1,gk1))/normgk0;
        
        if k==1
            figure;
            title(['cycle ' num2str(it) 'level 1']);
            xlabel('iteration number');
            ylabel('relative error of the gradient');
            fg=animatedline(k,rnormgk1);
        else
            addpoints(fg,k,rnormgk1);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnormgk1<epsilon
            close(gcf);
            inprodu=Tucker3inprod(2,uk1,uk1,[h h h],tol);
            uk1{4}=uk1{4}*sqrt(nele/inprodu);
            fprintf('Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnormgk1);
            break
        end
        betak=(Tucker3inprod(1,gk1,gk1)-Tucker3inprod(1,gk,gk1))/Tucker3inprod(1,gk,gk);%PR
        %   betak=Tucker3inprod(1,gk1,gk1)/Tucker3inprod(1,gk,gk);
        betakdk=dk;
        betakdk{4}=betak*betakdk{4};
        gk1_=gk1;
        gk1_{4}=-gk1{4};
        dk1=Tucker3vecplus(gk1_,betakdk,tol);
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end
    
else
    v1=varargin{1};
    guL1_=guL1;
    for k=1:3
        guL1_{k}=R{k,2}*guL1_{k};
    end
    guL1_{4}=-guL1_{4};
    gk=gEcsig2(uk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,phii);
    v2=Tucker3vecplus(gk,guL1_,tol);
    %optimization begin
    maxit=5;% for fast initialization
    [Ek,gk,phik]=EcgEcsig2(1,uk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phii);
    dk=gk;
    dk{4}=-dk{4};
%     normgk0=sqrt(Tucker3inprod(1,gk,gk));
    for k=1:maxit
        [uk1,Ek1,gk1,phik1]=bisectionsig2(uk,dk,Ek,gk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phik);
        rnormgk1=sqrt(Tucker3inprod(1,gk1,gk1))/normgk0;
        
        if k==1
            figure;
            title(['cycle ' num2str(it) 'level 2']);
            xlabel('iteration number');
            ylabel('relative error of the gradient');
            fg=animatedline(k,rnormgk1);
        else
            addpoints(fg,k,rnormgk1);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnormgk1<epsilon
            close(gcf);
            inprodu=Tucker3inprod(2,uk1,uk1,[h h h],tol);
            uk1{4}=uk1{4}*sqrt(nele/inprodu);
            fprintf('Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnormgk1);
            break
        end
        betak=(Tucker3inprod(1,gk1,gk1)-Tucker3inprod(1,gk,gk1))/Tucker3inprod(1,gk,gk);%PR
        %   betak=Tucker3inprod(1,gk1,gk1)/Tucker3inprod(1,gk,gk);
        betakdk=dk;
        betakdk{4}=betak*betakdk{4};
        gk1_=gk1;
        gk1_{4}=-gk1{4};
        dk1=Tucker3vecplus(gk1_,betakdk,tol);
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end
    
end
end