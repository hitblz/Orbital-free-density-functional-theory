function [Ecu,gEcu,phi]=EcgEcsig5(u,nele,h,Amat,bm,V,lambdaN,M)
%an analogue of EcgEcsig3
% N=length(LmuN);
% Ms=zeros(N,N);
% for k=1:N
%     Ms(k,k)=2/3;
% end
% for k=1:N-1
%     Ms(k+1,k)=1/6;
% end
% M={Ms;Ms;Ms;h^3};
%step 1
Mu=Tucker3matvec2(M,u);
inprodu=u(:)'*Mu(:);
a=sqrt(nele/inprodu);
un=u.*a;
%step 2
un2bm=Tucker3matvec2(M,un.^2)+bm;
phi=invIvecsig3(1/(4*pi),h,V,lambdaN,un2bm);
Ecu=E(un,Amat,h,phi,M,bm);% a scalar
%step 3
gEun=gE(un,Amat,phi,M);
lambda=-un(:)'*gEun(:)./nele;
cMJun=lambda.*Mu.*a;
gEcu=(gEun+cMJun).*a;
end
function out=E(un,Amat,h,phi,M,bm)
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat,un);
out=lam/2.*un(:)'*t(:);
%second part of kinematic energy + Exc
fkxc=@(v) kxc(v);
fu=funv3(fkxc,un);
u2=un.^2;
% t=Tucker3matvec2(M,fu);
% out=out+u2(:)'*t(:);
out=out+sum(fu,'all')*h^3;
%E-I interaction energy
t=Tucker3matvec2(M,u2)+bm;
out=out+1/2*t(:)'*phi(:);
end
function out=gE(un,Amat,phi,M)
%gradient of total energy with fixed phik
%first update
lam=2/10;
out=Tucker3matvec2(Amat,un).*lam;
%second update
fgkxc=@(v) gkxc(v);
pfu=funv3(fgkxc,un,M);
out=out+pfu;
%third update
uphi=2*un.*phi;
out=out+Tucker3matvec2(M,uphi);
end