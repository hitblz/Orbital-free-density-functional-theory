function out=normalize(op,v,nele,h)
M=cell(1,4);
switch op
    case 1
        for k=1:3
            N=size(v,k);
            M{k}=zeros(N,N);
            for k2=1:N
                M{k}(k2,k2)=2/3;
            end
            for k2=1:N-1
                M{k}(k2+1,k2)=1/6;
                M{k}(k2,k2+1)=1/6;
            end
        end
        
    case 2
        for k=1:3
            N=size(v,k);
            M{k}=eye(N);
        end
end
M{4}=h^3;
t=Tucker3matvec2(M,v);
inprodv=v(:)'*t(:);
out=v.*sqrt(nele/inprodv);
end