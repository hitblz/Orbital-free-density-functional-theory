function [uk1,Ek1,gk1,phik1,flag,varargout]=VM2(it,uk,nele,h,bm,P,R,guL0,guL1,varargin)
%V-cycle multigrid
epsilon=1e-6;%***
maxit=[5 5 5];
if isequal(guL0,0)
    N=size(uk,1);
    As=zeros(N,N,2);
    for k=1:N
        As(k,k,1)=2;
        As(k,k,2)=2/3;
    end
    for k=1:N-1
        As(k+1,k,1)=-1;
        As(k,k+1,1)=-1;
        As(k+1,k,2)=1/6;
        As(k,k+1,2)=1/6;
    end
    c=zeros(2,2,2);
    c(1,2,2)=1;
    c(2,1,2)=1;
    c(2,2,1)=1;
    Amat={As;As;As;c.*h};
    M={As(:,:,2);As(:,:,2);As(:,:,2);h^3};
    lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    muN=mu((1:N)');
    LmuN=lambda((1:N)')./muN;
    imuN=muN.^(-1);
    
    %optimization begin
    [Ek,gk,phik]=EcgEcsig4_2(1,uk,nele,h,Amat,bm,LmuN,imuN,M,0,0,0);
    dk=-gk;
    flag=0;
    for k=1:maxit(1)
        [uk1,Ek1,gk1,phik1,flg]=bisectionsig4(uk,dk,Ek,gk,phik,nele,h,Amat,bm,LmuN,imuN,M,0,0,0);
        if flg==0
            flag=1;
            break
        end
        rnorme=norm(uk1(:)-uk(:))/norm(uk(:));
        
        if k==1
            figure;
            title(['cycle ' num2str(it) ' level 0']);
            xlabel('iteration number');
            ylabel('relative error');
            fg=animatedline(k,rnorme);
        else
            addpoints(fg,k,rnorme);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnorme<epsilon
            flag=1;
            close(gcf);
            %             t=Tucker3matvec2(M,uk1);
            %             inprodu=uk1(:)'*t(:);
            %             uk1=uk1.*sqrt(nele/inprodu);
            fprintf('level 0: Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnorme);
            break
        end
        betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
        %betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));
        dk1=-gk1+betak*dk;
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
%        varargout{1}=flag;
    end
    %optimization end, get uk1 and gk1
elseif isequal(guL1,0)
    N=size(uk,1);
    As=zeros(N,N,2);
    for k=1:N
        As(k,k,1)=2;
        As(k,k,2)=2/3;
    end
    for k=1:N-1
        As(k+1,k,1)=-1;
        As(k,k+1,1)=-1;
        As(k+1,k,2)=1/6;
        As(k,k+1,2)=1/6;
    end
    c=zeros(2,2,2);
    c(1,2,2)=1;
    c(2,1,2)=1;
    c(2,2,1)=1;
    Amat={As;As;As;c.*(2*h)};
    M={As(:,:,2);As(:,:,2);As(:,:,2);(2*h)^3};
    lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    muN=mu((1:N)');
    LmuN=lambda((1:N)')./muN;
    imuN=muN.^(-1);
    %     Amat=cell(1,4);
    %     M=cell(1,4);
    %     muN=cell(1,3);
    %     LmuN=cell(1,3);
    %     imuN=cell(1,3);
    %     for i=1:3
    %         N=size(uk,i);
    %         As=zeros(N,N,2);
    %         for k=1:N
    %             As(k,k,1)=2;
    %             As(k,k,2)=2/3;
    %         end
    %         for k=1:N-1
    %             As(k+1,k,1)=-1;
    %             As(k,k+1,1)=-1;
    %             As(k+1,k,2)=1/6;
    %             As(k,k+1,2)=1/6;
    %         end
    %         Amat{i}=As;
    %         M{i}=As(:,:,2);
    %         lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    %         mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    %         muN{i}=mu((1:N)');
    %         LmuN{i}=lambda((1:N)')./muN{i};
    %         imuN{i}=muN{i}.^(-1);
    %     end
    %     c=zeros(2,2,2);
    %     c(1,2,2)=1;
    %     c(2,1,2)=1;
    %     c(2,2,1)=1;
    %     Amat{4}=c.*(2*h);
    %     M{4}=(2*h)^3;
    
    gk=gEcsig3_2(uk,nele,2*h,Amat,bm,LmuN,imuN,M,P,0);
    v1=gk-Tucker3matvec2(R(:,1)',guL0);
    varargout{1}=v1;
    %optimization begin
    [Ek,gk,phik]=EcgEcsig4_2(1,uk,nele,2*h,Amat,bm,LmuN,imuN,M,P,v1,0);
    dk=-gk;
    flag=0;
    for k=1:maxit(2)
        [uk1,Ek1,gk1,phik1,flg]=bisectionsig4(uk,dk,Ek,gk,phik,nele,2*h,Amat,bm,LmuN,imuN,M,P,v1,0);
        if flg==0
            flag=1;
            break
        end
        rnorme=norm(uk1(:)-uk(:))/norm(uk(:));
        
        if k==1
            figure;
            title(['cycle ' num2str(it) ' level 1']);
            xlabel('iteration number');
            ylabel('relative error');
            fg=animatedline(k,rnorme);
        else
            addpoints(fg,k,rnorme);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnorme<epsilon
            close(gcf);
            flag=1;
            %             puk1=Tucker3matvec2(P(:,1)',uk1);
            %             t=Tucker3matvec2(M,puk1);
            %             inprodu=puk1(:)'*t(:);
            %             uk1=uk1.*sqrt(nele/inprodu);
            fprintf('level 1: Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnorme);
            break
        end
        betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
        %   betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));
        dk1=-gk1+betak*dk;
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end
    
else
    N=size(uk,1);
    As=zeros(N,N,2);
    for k=1:N
        As(k,k,1)=2;
        As(k,k,2)=2/3;
    end
    for k=1:N-1
        As(k+1,k,1)=-1;
        As(k,k+1,1)=-1;
        As(k+1,k,2)=1/6;
        As(k,k+1,2)=1/6;
    end
    c=zeros(2,2,2);
    c(1,2,2)=1;
    c(2,1,2)=1;
    c(2,2,1)=1;
    Amat={As;As;As;c.*(4*h)};
    M={As(:,:,2);As(:,:,2);As(:,:,2);(4*h)^3};
    lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    muN=mu((1:N)');
    LmuN=lambda((1:N)')./muN;
    imuN=muN.^(-1);
    %     Amat=cell(1,4);
    %     M=cell(1,4);
    %     muN=cell(1,3);
    %     LmuN=cell(1,3);
    %     imuN=cell(1,3);
    %     for i=1:3
    %         N=size(uk,i);
    %         As=zeros(N,N,2);
    %         for k=1:N
    %             As(k,k,1)=2;
    %             As(k,k,2)=2/3;
    %         end
    %         for k=1:N-1
    %             As(k+1,k,1)=-1;
    %             As(k,k+1,1)=-1;
    %             As(k+1,k,2)=1/6;
    %             As(k,k+1,2)=1/6;
    %         end
    %         Amat{i}=As;
    %         M{i}=As(:,:,2);
    %         lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    %         mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    %         muN{i}=mu((1:N)');
    %         LmuN{i}=lambda((1:N)')./muN{i};
    %         imuN{i}=muN{i}.^(-1);
    %     end
    %     c=zeros(2,2,2);
    %     c(1,2,2)=1;
    %     c(2,1,2)=1;
    %     c(2,2,1)=1;
    %     Amat{4}=c.*(4*h);
    %     M{4}=(4*h)^3;
    
    v1=varargin{1};
    gk=gEcsig3_2(uk,nele,4*h,Amat,bm,LmuN,imuN,M,P,v1);
    v2=gk-Tucker3matvec2(R(:,2)',guL1);
    %optimization begin
    [Ek,gk,phik]=EcgEcsig4_2(1,uk,nele,4*h,Amat,bm,LmuN,imuN,M,P,v1,v2);
    dk=-gk;
    flag=0;
    for k=1:maxit(3)
        [uk1,Ek1,gk1,phik1,flg]=bisectionsig4(uk,dk,Ek,gk,phik,nele,4*h,Amat,bm,LmuN,imuN,M,P,v1,v2);
        if flg==0
            flag=1;
            break
        end
        rnorme=norm(uk1(:)-uk(:))/norm(uk(:));
        
        if k==1
            figure;
            title(['cycle ' num2str(it) ' level 2']);
            xlabel('iteration number');
            ylabel('relative error');
            fg=animatedline(k,rnorme);
        else
            addpoints(fg,k,rnorme);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnorme<epsilon
            close(gcf);
            flag=1;
            %             puk1=Tucker3matvec2(P(:,2)',uk1);
            %             puk1=Tucker3matvec2(P(:,1)',puk1);
            %             t=Tucker3matvec2(M,puk1);
            %             inprodu=puk1(:)'*t(:);
            %             uk1=uk1.*sqrt(nele/inprodu);
            fprintf('level 2: Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnorme);
            break
        end
        betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
        %   betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));
        dk1=-gk1+betak*dk;
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end
    
end
end