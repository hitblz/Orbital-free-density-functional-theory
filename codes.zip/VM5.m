function [uk1,Ek1,gk1,phik1,flag,flg,varargout]=VM5(it,epsilon,uk,nele,h,Amat,M,Vs,lambdas,bm,P,R,guL0,guL1,varargin)
%from VM3
%V-cycle multigrid
Na=nele/3;
maxit=[5 5 5];
if isequal(guL0,0)   
    %optimization begin
    [Ek,gk,phik]=EcgEc2(uk,nele,h,Amat,bm,Vs,lambdas,M,0,0,0);
    dk=-gk;
    flag=0;
    for k=1:maxit(1)
        [uk1,Ek1,gk1,phik1,flg]=bisection2(uk,dk,Ek,gk,phik,nele,h,Amat,bm,Vs,lambdas,M,0,0,0);
%         rnorme=norm(uk1(:)-uk(:))/norm(uk(:));
        rnorme=abs(Ek1-Ek)/Na*27.2114;
        if k==1
            figure;
            title(['cycle ' num2str(it) ' level 0']);
            xlabel('iteration number');
            ylabel('relative error');
            fg=animatedline(k,rnorme);
        else
            addpoints(fg,k,rnorme);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnorme<epsilon
            flag=1;
            close(gcf);
            fprintf('level 0: Conjugate gradient iteration converged at iteration (%i, %i) with relative residual %10.4e.\n',it,k,rnorme);
            varargout{1}=maxit(1)*(it-1)+k;
            varargout{2}=rnorme;
            break
        end
        varargout{1}=maxit(1)*(it-1)+k;
        varargout{2}=rnorme;
        betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
      %  betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));%FR
        dk1=-gk1+betak*dk;
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end
    %optimization end, get uk1 and gk1
elseif isequal(guL1,0)
    gk=gEc2(uk,nele,2*h,Amat,bm,Vs,lambdas,M,P,0);
    v1=gk-Tucker3matvec2(R(:,1)',guL0);
    varargout{1}=v1;
    %optimization begin
    [Ek,gk,phik]=EcgEc2(uk,nele,2*h,Amat,bm,Vs,lambdas,M,P,v1,0);
    dk=-gk;
    flag=0;
    for k=1:maxit(2)
        [uk1,Ek1,gk1,phik1,flg]=bisection2(uk,dk,Ek,gk,phik,nele,2*h,Amat,bm,Vs,lambdas,M,P,v1,0);
%         rnorme=norm(uk1(:)-uk(:))/norm(uk(:));
        rnorme=abs(Ek1-Ek)/Na*27.2114;
        if k==1
            figure;
            title(['cycle ' num2str(it) ' level 1']);
            xlabel('iteration number');
            ylabel('relative error');
            fg=animatedline(k,rnorme);
        else
            addpoints(fg,k,rnorme);
        end
        drawnow;
        set(gca,'YScale','log');
        
%         if rnorme<0
%             flag=1;
%             close(gcf);
%             fprintf('level 1: Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnorme);
%             break
%         end
        betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
%        betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));%FR
        dk1=-gk1+betak*dk;
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end
    
else
    v1=varargin{1};
    gk=gEc2(uk,nele,4*h,Amat,bm,Vs,lambdas,M,P,v1);
    v2=gk-Tucker3matvec2(R(:,2)',guL1);
    %optimization begin
    [Ek,gk,phik]=EcgEc2(uk,nele,4*h,Amat,bm,Vs,lambdas,M,P,v1,v2);
    dk=-gk;
    flag=0;
    for k=1:maxit(3)
        [uk1,Ek1,gk1,phik1,flg]=bisection2(uk,dk,Ek,gk,phik,nele,4*h,Amat,bm,Vs,lambdas,M,P,v1,v2);
%         rnorme=norm(uk1(:)-uk(:))/norm(uk(:));
        rnorme=abs(Ek1-Ek)/Na*27.2114;
        if k==1
            figure;
            title(['cycle ' num2str(it) ' level 2']);
            xlabel('iteration number');
            ylabel('relative error');
            fg=animatedline(k,rnorme);
        else
            addpoints(fg,k,rnorme);
        end
        drawnow;
        set(gca,'YScale','log');
        
%         if rnorme<0
%             flag=1;
%             close(gcf);
%             fprintf('level 2: Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnorme);
%             break
%         end
        betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
%        betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));%FR
        dk1=-gk1+betak*dk;
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end    
end
end