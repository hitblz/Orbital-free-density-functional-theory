function phi=invIvec(alpha,h,LmuN,imuN,f)
%direct solution
%linear equation corresponding to 1/2*alpha*\int \nabla v .*\nabla v dx
methodDST=1;
%discrete sine transform
phi=fDST2(f,methodDST);
phi=phi.*(imuN{1}.*imuN{2}'.*permute(imuN{3},[2 3 1]));
phi=phi./(alpha*h);
%step2
I2=LmuN{2};
I2(:)=1;
I3=LmuN{3};
I3(:)=1;
t=LmuN{1}.*I2'.*permute(I3,[2 3 1]);
I1=LmuN{1};
I1(:)=1;
t=t+I1.*LmuN{2}'.*permute(I3,[2 3 1])+I1.*I2'.*permute(LmuN{3},[2 3 1]);
phi=t.^(-1).*phi;
%discrete inverse sine transform
phi=fDST2(phi,methodDST);
end