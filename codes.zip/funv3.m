function out=funv3(f,v,varargin)

% general nonlinear function of a vector in (3,0) format
% f is a function handle or a subroutine
%To serve for OFDFT, for simplicity, it is assumed that the length of
%size(v{1},1)=size(v{2},1)=size(v{3},1);
if nargin<3% for integration of energy function
    out=f(v);
    
else% for the gradient of energy function
    out=funv3(f,v);
    M=varargin{1};
    out=Tucker3matvec2(M,out);
    
end
end