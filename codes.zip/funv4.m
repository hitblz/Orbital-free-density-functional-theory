function out=funv4(opt,f,v,tol)
% an updated version of funv2.m
switch opt
    case 1
        Is=cell(3,1);
        for k=1:3
            t=tensordecompose(6,v{k},tol,2);
            Is{k}=sort(t{3}{1});
        end
        t=tucker3product(v{4},v{1}(Is{1},:),v{2}(Is{2},:),v{3}(Is{3},:));
        [ma,id]=max(abs(f(t(:))));
        [id1,id2,id3]=ind2sub([length(Is{1}),length(Is{2}),length(Is{3})],id);
        idsets={Is{1}(id1),[Is{2}(id2),Is{3}(id3)];Is{2}(id2),[Is{3}(id3) Is{1}(id1)];Is{3}(id3),[Is{1}(id1) Is{2}(id2)]};
        for k=1:3
            pm=[k:3 1:k-1];
            c=permute(v{4},pm);
            sz=[size(v{pm(1)},1) size(v{pm(2)},1) size(v{pm(3)},1)];
            maxrank=max(sz);
%             t=tensordecompose(6,v{pm(2)},tol,2);
%             J2=sort(t{3}{1});
%             t=tensordecompose(6,v{pm(3)},tol,2);
%             J3=sort(t{3}{1});
            J2=randperm(size(v{pm(2)},1),size(v{pm(2)},2));
            J3=randperm(size(v{pm(3)},1),size(v{pm(3)},2));
            for kk=1:maxrank
                I1=setdiff(1:sz(1),idsets{pm(1),1});
                I23_=sub2ind(sz(2:3),idsets{pm(1),2}(:,1),idsets{pm(1),2}(:,2));
                %find an initial pivot
%                 t=tensordecompose(6,v{pm(1)}(I1,:),tol,2);
%                 J1=I1(sort(t{3}{1}));
                J1=randperm(size(v{pm(1)},1),size(v{pm(1)},2));
                t=tucker3product(c,v{pm(1)}(J1,:),v{pm(2)}(J2,:),v{pm(3)}(J3,:));
                t=reshape(t,size(t,1),size(t,2)*size(t,3));
                J=J2.*J3';
                [I23,ia]=setdiff(J(:),I23_);
                f1=f(t(:,ia));
                
                s1=size(c,1);
                s2=length(I23_);
                sm=zeros(s1,s2);
                for k2=1:s2
                    t1=tencontract(v{pm(2)}(idsets{pm(1),2}(k2,1),:),2,2,c,3,2);
                    t1=tencontract(v{pm(3)}(idsets{pm(1),2}(k2,2),:),2,2,t1,3,3);
                    sm(:,k2)=t1(:);
                end
                t1=f(v{pm(1)}(J1,:)*sm);
                Amid=f(v{pm(1)}(idsets{pm(1),1},:)*sm);
                t1=t1/Amid;
                t=tucker3product(c,v{pm(1)}(idsets{pm(1),1},:),v{pm(2)}(J2,:),v{pm(3)}(J3,:));
                t=reshape(t,size(t,1),size(t,2)*size(t,3));
                t2=f(t(:,ia));
                
                vals=f1-t1*t2;
                [errmax,id]=max(abs(vals(:)));
                if isempty(errmax)
                    errmax=0;
                else
                    [~,iII]=ind2sub([length(J1),length(ia)],id);
                    [i2,i3]=ind2sub(sz(2:3),I23(iII));%initial pivot found
                    val=errmax;
                    maxn=20;
                    it=0;
                    while it<maxn
                        it=it+1;
                        t1=tencontract(v{pm(2)}(i2,:),2,2,c,3,2);
                        t1=tencontract(v{pm(3)}(i3,:),2,2,t1,3,3);
                        f1=f(v{pm(1)}(I1,:)*t1(:));
                        f2=f(v{pm(1)}(I1,:)*sm)*(Amid\f(v{pm(1)}(idsets{pm(1),1},:)*t1(:)));
                        [val2,i1]=max(abs(f1-f2));
                        i1=I1(i1);
                        if abs(val2-val)<1e-10
                            fprintf('maximum found at iteration %i\n',it);
                            break
                        end
                        val=val2;
                        
                        it=it+1;
                        t1=tencontract(v{pm(1)}(i1,:),2,2,c,3,1);
                        t1=tencontract(v{pm(3)}(i3,:),2,2,t1,3,3);
                        f1=f(v{pm(2)}*t1(:));
                        t1=v{pm(1)}(idsets{pm(1),1},:)*ipermute(tencontract(v{pm(3)}(i3,:),2,2,c,3,3),[3 1 2]);
                        t2=f(v{pm(1)}(i1,:)*sm)/Amid;
                        f2=(t2*f(t1*v{pm(2)}'))';
                        dt=abs(f1-f2);
                        h1=((i3-1)*size(v{pm(2)},1)+1:i3*size(v{pm(2)},1))';
                        [~,ia]=setdiff(h1,I23_);
                        ia=setdiff((1:size(v{pm(2)},1))',ia);
                        dt(ia)=0;
                        [val2,i2]=max(dt);
                        if abs(val2-val)<1e-10
                            fprintf('maximum found at iteration %i\n',it);
                            break
                        end
                        val=val2;
                        
                        it=it+1;
                        t1=tencontract(v{pm(1)}(i1,:),2,2,c,3,1);
                        t1=tencontract(v{pm(2)}(i2,:),2,2,t1,3,2);
                        f1=f(v{pm(3)}*t1(:));
                        t1=ipermute(tencontract(v{pm(2)}(i2,:),2,2,c,3,2),[2 1 3]);
                        t1=permute(tencontract(v{pm(1)}(idsets{pm(1),1},:),2,2,t1,3,1),[1 3 2]);
                        f2=(t2*f(t1*v{pm(3)}'))';
                        dt=abs(f1-f2);
                        h1=(0:size(v{pm(3)},1)-1)'*size(v{pm(2)},1)+i2;
                        [~,ia]=setdiff(h1,I23_);
                        ia=setdiff((1:size(v{pm(3)},1))',ia);
                        dt(ia)=0;
                        [val2,i3]=max(dt);
                        if abs(val2-val)<1e-10
                            fprintf('maximum found at iteration %i\n',it);
                            break
                        end
                        val=val2;
                    end
                    errmax=val2;
                end
                errmax=errmax/ma;
                if errmax<=tol
                    fprintf('Dimension (%i, (%i,%i)) converged at rank %i.\n',pm(1),pm(2),pm(3),size(idsets{pm(1),1},1));
                    break
                end
                idsets{pm(1),1}=[idsets{pm(1),1};i1];
                idsets{pm(1),2}=[idsets{pm(1),2};[i2,i3]];
            end
        end
        
        out=cell(4,1);
        for k=1:3
            pm=[k:3 1:k-1];
            c=permute(v{4},pm);
            sz=[size(c,1),size(c,2),size(c,3)];
            s2=size(idsets{pm(1),2},1);
            sm=zeros(sz(1),s2);
            for k2=1:s2
                t2=tencontract(v{pm(2)}(idsets{pm(1),2}(k2,1),:),2,2,c,3,2);
                t2=tencontract(v{pm(3)}(idsets{pm(1),2}(k2,2),:),2,2,t2,3,3);
                sm(:,k2)=t2(:);
            end
            t21=f(v{pm(1)}*sm);
            out{k}=t21/t21(idsets{pm(1),1},:);
        end
        out{4}=f(tucker3product(v{4},v{1}(idsets{1,1},:),v{2}(idsets{2,1},:),v{3}(idsets{3,1},:)));
        
    case 2%from Dolgov
        Is=cell(3,1);
        for k=1:3
            t=tensordecompose(6,v{k},tol,2);
            Is{k}=sort(t{3}{1});
        end
        t=f(tucker3product(v{4},v{1}(Is{1},:),v{2}(Is{2},:),v{3}(Is{3},:)));
        t=tensordecompose(7,t,tol,2);
        I=cell(1,3);
        I{2}=Is{2}(sort(t{5}{2,1}));
        I{3}=Is{3}(sort(t{5}{3,1}));
        maxit=5;
        out=cell(4,1);
        for it=1:maxit
            for k=1:3
                pm=[k:3 1:k-1];
                c=permute(v{4},pm);
                t=tencontract(v{pm(2)}(I{pm(2)},:),2,2,c,3,2);
                t=tencontract(v{pm(3)}(I{pm(3)},:),2,2,t,3,3);
                t=ipermute(t,[3 2 1]);
                t=f(tencontract(v{pm(1)},2,2,t,3,1));
                t=reshape(t,size(t,1),size(t,2)*size(t,3));
                t=tensordecompose(6,t,tol,2);
                out{pm(1)}=t{1};
                I{pm(1)}=t{3}{1};
            end
            
        end
        out{4}=f(tucker3product(v{4},v{1}(I{1},:),v{2}(I{2},:),v{3}(I{3},:)));
end