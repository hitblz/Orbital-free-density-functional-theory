fnames=cell(5,5);
as=4:8;
hs=1:5;
for k1=1:5
    for k2=1:5
        fnames{k1,k2}=['n1a' num2str(as(k1)) 'r6h' num2str(hs(k2)) 'ep2n3o.mat'];
    end
end
add=[pwd '\atomcluster4\'];
flgs=zeros(25,3);
k=0;
for k1=1:5
    for k2=1:5
        t=load([add,fnames{k1,k2}],'flg');
        k=k+1;
        flgs(k,:)=t.flg;
    end
end