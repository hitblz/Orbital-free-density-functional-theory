function out=sig3D(task,f,Ra,h,coor)
n=floor(Ra/h);
switch task
    case 1
        grid1=-coor(1)-n*h+h:h:h-coor(1)+(n-1)*h-h;
        grid2=-coor(2)-n*h+h:h:h-coor(2)+(n-1)*h-h;
        grid3=-coor(3)-n*h+h:h:h-coor(3)+(n-1)*h-h;
        grid1=grid1';
        grid3=permute(grid3,[1 3 2]);
        out=f(sqrt(grid1.^2+grid2.^2+grid3.^2));
    case 2
        grid1=-coor(1)-n*h+0.5*h:h:h-coor(1)+(n-1)*h-0.5*h;
        grid2=-coor(2)-n*h+0.5*h:h:h-coor(2)+(n-1)*h-0.5*h;
        grid3=-coor(3)-n*h+0.5*h:h:h-coor(3)+(n-1)*h-0.5*h;
        grid1=grid1';
        grid3=permute(grid3,[1 3 2]);
        out=f(sqrt(grid1.^2+grid2.^2+grid3.^2));
        ls=[length(grid1) length(grid2) length(grid3)];
        out=out(1:ls(1)-1,:,:)+out(2:ls(1),:,:);
        out=out(:,1:ls(2)-1,:)+out(:,2:ls(2),:);
        out=out(:,:,1:ls(3)-1)+out(:,:,2:ls(3));
        out=out.*(h/2)^3;
end
end