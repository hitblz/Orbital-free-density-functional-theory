function phi=invIvec2(alpha,h,V,lambdaN,f)
%direct solution
%linear equation corresponding to 1/2*alpha*\int \nabla v .*\nabla v dx

%discrete sine transform
phi=tucker3product(f,V{1}',V{2}',V{3}');
phi=phi./(alpha*h);
%step2
I2=lambdaN{2};
I2(:)=1;
I3=lambdaN{3};
I3(:)=1;
t=lambdaN{1}.*I2'.*permute(I3,[2 3 1]);
I1=lambdaN{1};
I1(:)=1;
t=t+I1.*lambdaN{2}'.*permute(I3,[2 3 1])+I1.*I2'.*permute(lambdaN{3},[2 3 1]);
phi=t.^(-1).*phi;
%discrete inverse sine transform
phi=tucker3product(phi,V{1},V{2},V{3});
end