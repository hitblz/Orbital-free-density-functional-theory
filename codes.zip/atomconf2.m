%DFTpy
a0=8;
n=10;
ncell=[1 1 1]*n;
r0list=r0cgen(ncell);
na=size(r0list,1);
fid=fopen('mytest.vasp','w');
lan=a0*0.52917721067;
r0list=r0list*lan+3.1751;
L=lan*n+3.1751*2;
fprintf(fid,'Al supercell\n');
fprintf(fid,'1.0\n');
fprintf(fid,'%4.2f 0 0\n',L);
fprintf(fid,'0 %4.2f 0\n',L);
fprintf(fid,'0 0 %4.2f\n',L);
fprintf(fid,'Al\n');
fprintf(fid,'%i\n',na);
fprintf(fid,'Cartesian\n');
for k=1:na
    fprintf(fid,'%4.2f %4.2f %4.2f\n',r0list(k,1),r0list(k,2),r0list(k,3));
end
fclose(fid);