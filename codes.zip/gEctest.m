function [out,gEcu] =gEctest(u,nele,h,phi)

N=size(u,1);
As=zeros(N,N,2);
for k=1:N
    As(k,k,1)=2;
    As(k,k,2)=2/3;
end
for k=1:N-1
    As(k+1,k,1)=-1;
    As(k,k+1,1)=-1;
    As(k+1,k,2)=1/6;
    As(k,k+1,2)=1/6;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat={As;As;As;c.*h};
M={As(:,:,2);As(:,:,2);As(:,:,2);h^3};

%step 1
Mu=Tucker3matvec2(M,u);
inprodu=u(:)'*Mu(:);
un=u;
a=sqrt(nele/inprodu);
un=un.*a;
%step 2
%     un2bm=Tucker3matvec2(M,un.^2)+bm;
%     phi=invIvecsig2(1/(4*pi),h,LmuN,imuN,un2bm);
%step 3
gEun=gE(un,Amat,phi,M);
lambda=-un(:)'*gEun(:)/nele;
cMJun=lambda.*Mu.*a;
gEcu=(gEun+cMJun).*a;% a vector
out=norm(gEcu(:));
end
function out=gE(u,Amat,phi,M)
%gradient of total energy with fixed phik
%first update
lam=2/10;
out=Tucker3matvec2(Amat,u).*lam;
%second update
fgkxc=@(v) gkxc(v);
pfu=funv3(fgkxc,u,M);
out=out+pfu;
%third update
uphi=2*u.*phi;
out=out+Tucker3matvec2(M,uphi);
end