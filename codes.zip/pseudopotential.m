function Va=pseudopotential(ra)
Va=chebfun(@(r) -GNH(r),[0,ra*sqrt(3)],'splitting','on');
end
function out=GNH(r)
A=0.1107;
R=1.150;
Rc=3.5;
Z=3;    
if r>0
    out=2/pi*sum(chebfun(@(t) (sin(r.*t)./(r.*t)).*((Z-A*R)*cos(R.*t)+A*sin(R*t)./t).*exp(-(t./Rc).^6),[0,20],'splitting','on'));
else
    out=2/pi*sum(chebfun(@(t) ((Z-A*R)*cos(R.*t)+A*sin(R*t)./t).*exp(-(t./Rc).^6),[0,20],'splitting','on'));
end
end