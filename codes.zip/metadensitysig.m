function out=metadensitysig(D,n2,M,Z,tol)
x=linspace(-D/2,D/2,n2+1)';
s=2;%>1
t1=[normpdf(x,0,1) normpdf(x,0,1/s)];
t1(1,:)=[];
t1(end,:)=[];
t=zeros(2,2,2);
t(1)=1;
t(8)=-(normpdf(0,0,1)/normpdf(0,0,1/s))^3*0.99;
out={t1;t1;t1;t};
t3=Tucker3matvec(M,out,tol);
inprodu=Tucker3inprod(1,out,t3);%positive
out{4}=out{4}*sqrt(Z/inprodu);
end