function [t,t2]=assem2(v,r,h)
%
cen=350;
szv=size(v,1);%size(v,1)==size(v,2)==size(v,3)
itv=-(szv-1)/2:(szv-1)/2;
t=1e-8*ones(2*cen,2*cen,2*cen);
bounds=zeros(3,2);
for k=1:size(r,2)
    if k==1
        t(cen+round(r(1,k)/h)+itv,cen+round(r(2,k)/h)+itv,cen+round(r(3,k)/h)+itv)=t(cen+round(r(1,k)/h)+itv,cen+round(r(2,k)/h)+itv,cen+round(r(3,k)/h)+itv)+v;        
    end
    x1=cen+round(r(1,k)/h)+itv(1);
    y1=cen+round(r(2,k)/h)+itv(1);
    z1=cen+round(r(3,k)/h)+itv(1);
    x2=cen+round(r(1,k)/h)+itv(end);
    y2=cen+round(r(2,k)/h)+itv(end);
    z2=cen+round(r(3,k)/h)+itv(end);
    if k==1
        bounds(1,1)=x1;
        bounds(2,1)=y1;
        bounds(3,1)=z1;
        bounds(1,2)=x2;
        bounds(2,2)=y2;
        bounds(3,2)=z2;
    else
        if x1<bounds(1,1)
            bounds(1,1)=x1;
        end
        if y1<bounds(2,1)
            bounds(2,1)=y1;
        end
        if z1<bounds(3,1)
            bounds(3,1)=z1;
        end
        if x2>bounds(1,2)
            bounds(1,2)=x2;
        end
        if y2>bounds(2,2)
            bounds(2,2)=y2;
        end
        if z2>bounds(3,2)
            bounds(3,2)=z2;
        end
    end
end
for k=1:3
    if mod(bounds(k,2)-bounds(k,1)+1,4)==1
        bounds(k,1)=bounds(k,1)-1;
        bounds(k,2)=bounds(k,2)+1;
    elseif mod(bounds(k,2)-bounds(k,1)+1,4)==2
        bounds(k,2)=bounds(k,2)+1;
    end
end
t=t(bounds(1,1):bounds(1,2),bounds(2,1):bounds(2,2),bounds(3,1):bounds(3,2));
t2=[cen-(bounds(1,1)-1)+round(r(1,1)/h)+itv(1),cen-(bounds(1,1)-1)+round(r(1,1)/h)+itv(end);cen-(bounds(2,1)-1)+round(r(2,1)/h)+itv(1),cen-(bounds(2,1)-1)+round(r(2,1)/h)+itv(end);cen-(bounds(3,1)-1)+round(r(3,1)/h)+itv(1),cen-(bounds(3,1)-1)+round(r(3,1)/h)+itv(end)];
end