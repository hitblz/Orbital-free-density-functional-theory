function out=Tucker3vecplus(v1,v2,tol)
%summation of two third-order Tucker vectors
if isequal(v1{4},0)
    out=v2;
elseif isequal(v2{4},0)
    out=v1;
else
    out=cell(4,1);
    sd=cell(3,2);
    for k=1:3
        sz=[size(v1{4},k),size(v2{4},k)];
        t=tensordecompose(6,[v1{k},v2{k}],tol,2);
        out{k}=t{1};
        sd(k,:)=mat2cell(t{2},size(t{2},1),sz);
    end
    t=tucker3product(v1{4},sd{1,1},sd{2,1},sd{3,1})+tucker3product(v2{4},sd{1,2},sd{2,2},sd{3,2});
    C=tensordecompose(7,t,tol,2);
    out{4}=C{4};
    for j=1:3
        out{j}=out{j}*C{j};
    end
end
end