function out=locat(v1,v2)
%v1 and v2 are one-dimensional vectors which has been sorted in ascending
%order
%v2 is a subset if v1
L1=length(v1);
L2=length(v2);
out=zeros(L2,1);
k=1;
for j=1:L1
    if v1(j)==v2(k)
        out(k)=j;
        if k<L2
            k=k+1;
        else
            break
        end
    end
end
end