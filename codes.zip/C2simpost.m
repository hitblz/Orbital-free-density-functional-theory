clear
add=[pwd '\atomcluster3\'];
fnames={'n1a8r6h5ep2n3osg.mat','n1r6h5ep2n3osgsim.mat';
    'n3a8r6h5ep2n3osg.mat','n3r6h5ep2n3osgsim.mat';
    'n5a8r6h5ep2n3osg.mat','n5r6h5ep2n3osgsim.mat';
    'n10a8r6h5ep2n3osg.mat','n10r6h5ep2n3osgsim.mat'};
nf=size(fnames);
data1=zeros(7,nf(1));
for k=1:nf(1)
    t=load([add fnames{k,1}]);
    data1(1,k)=t.N;
    data1(2,k)=t.Eac;
    data1(4,k)=t.nit;
    data1(6,k)=t.tim;
    t=load([add fnames{k,2}]);
    data1(3,k)=t.Eac;
    data1(5,k)=t.nit;
    data1(7,k)=t.tim;
end
Eref=data1(2,nf(1));
fnames2={'n10r6h5ep2n3osgsim1.mat';
    'n10r6h5ep2n3osgsim2.mat';
    'n10r6h5ep2n3osgsim3.mat';
    'n10r6h5ep2n3osgsim.mat'};
fnames3={'n1r6h5ep2n3osgsim.mat','n3r6h5ep2n3osgsim.mat','n5r6h5ep2n3osgsim.mat','n10r6h5ep2n3osgsim.mat'};
nf=length(fnames2);
data2=zeros(5,nf);
for k=1:nf(1)
    t=load([add fnames2{k}]);
    data2(1,k)=t.Eac;
    data2(2,k)=(Eref-data2(1,k))/Eref;
    t=load([add fnames3{k}]);
    data2(3,k)=t.tim1;    
    if k<nf(1)
        t=load([add fnames2{k}]);
        data2(4,k)=t.tim;
        data2(5,k)=data2(4,k)+data2(3,k);
    else
        data2(5,k)=data2(3,k);
    end
end