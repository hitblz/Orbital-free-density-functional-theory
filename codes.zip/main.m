%using pseudopotential
clear
%% single atom
% Pseudopotential
br=pseudobx(10);%a chebfun








%% basic information
a0=4;% lattice constant
%
%              7------------------8
%             / |                        /|
%           /   |                      /  |
%          5-----------------6    |
%          |    3--------------|---4
%          |   /                    |    /
%          | /                      | /
%          1-----------------2

%% nuclei charge distribution
ncell=1;
n2=18;
tol1=1e-10;
tol2=1e-10;
% bx=nuccha3(br,a0,n1,n2,tol1,tol2);%node values
[bx,N]=nuccha3_2(br,a0,n2,tol1,tol2);

n1=ncell+1;
h=1/(N+1);
nele=3*((2*ncell+1)^2*ncell+(ncell+1)^2+ncell^2);

% MJ=Mmat1(detJcell,N);
s1=[2*ones(N,1);-1*ones(N-1,1);-1*ones(N-1,1)];
s2=[2/3*ones(N,1);1/6*ones(N-1,1);1/6*ones(N-1,1)];
c1=a0*n1;
uni=chebfun(1,[0 1]);
detJc=c1^3;
detJ0={uni;uni;uni;detJc};
MJ0={s2;s2;s2;h^3*detJc};

bJm=Tucker3matvec(MJ0,bx,tol1,tol2);
% usig=load('singleAl.mat','uk1');
% usig=usig.uk1;
%uk=metadensity5(a0,n1,n2,nele,MJ0,tol1,tol2);
% uk=metadensity3(br,a0,n1,n2,nele,MJ0,tol1,tol2);
% uk=metadensity(1,n1,n2,nele,MJ0,tol1,tol2);
uk=metadensity6(N,a0,n2,nele,MJ0,tol1,tol2);

c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
A0mat={[s1,s2];[s1,s2];[s1,s2];c.*(h*c1)};

%% Solution of Reference configuration
%Alternating iteration of electrastatic potential and electron density
lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
muN=mu((1:N)');
LmuN=lambda((1:N)')./muN;
imuN=muN.^(-1);
eADI=1e-8;
epsilon=1e-8;
maxit=100;
%%
normu0=sqrt(nele);
[Ek,gk,phik]=EcgEc_2(1,uk,nele,ncell,n2,A0mat,bJm,LmuN,imuN,MJ0,detJ0,tol1,tol2,eADI);
dk=gk;
dk{4}=-dk{4};
normgk0=sqrt(Tucker3inprod(1,gk,gk));
%%
for k=1:maxit
    [uk1,Ek1,gk1,phik1]=bisection5(uk,dk,Ek,gk,nele,ncell,n2,A0mat,bJm,LmuN,imuN,MJ0,detJ0,tol1,tol2,eADI,phik);
    rnormgk1=sqrt(Tucker3inprod(1,gk1,gk1))/normgk0;
    
    if k==1
        figure;
        xlabel('iteration number');
        ylabel('relative error of the gradient');
        fg=animatedline(k,rnormgk1);
    else
        addpoints(fg,k,rnormgk1);
    end
    drawnow;
    set(gca,'YScale','log');
    
    if rnormgk1<epsilon
        close(gcf);
        inprodu=Tucker3inprod(2,uk1,uk1,MJ0,tol1,tol2);
        uk1{4}=uk1{4}*sqrt(nele/inprodu);
        fprintf('Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnormgk1);
        break
    end
    betak=(Tucker3inprod(1,gk1,gk1)-Tucker3inprod(1,gk,gk1))/Tucker3inprod(1,gk,gk);%PR
    %   betak=Tucker3inprod(1,gk1,gk1)/Tucker3inprod(1,gk,gk);
    betakdk=dk;
    betakdk{4}=betak*betakdk{4};
    gk1_=gk1;
    gk1_{4}=-gk1{4};
    dk1=Tucker3vecplus(gk1_,betakdk,tol1,tol2);
    uk=uk1;
    Ek=Ek1;
    gk=gk1;
    dk=dk1;
    phik=phik1;
end
