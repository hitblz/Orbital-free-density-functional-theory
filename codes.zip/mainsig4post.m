t=load([pwd '\singleatom3\r1h0ep0n1.mat'],'Ea1ev','Va');
Ea1evref=t.Ea1ev;
Va=t.Va;
%%
figure;
plot(Va);hold on
t=Va.domain;
t=[1.5 t(end)];
fplot(@(x) -3./x,t,'--');
xlabel('\it r/\rm Bohr');
ylabel('\it V');
legend('\it V_{\rm a}','\it V_{\rm ref}','Location','Northeast');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 12 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'Vrfig.fig');
export_fig(gcf, [pwd '\Vrfig.pdf'], '-r2000', '-transparent');
%%
hs=zeros(1,4);
Eevm=zeros(2,4);
for nep=1:2
    for nh=1:4
        t=load([pwd '\singleatom3\a1h' num2str(nh) 'ep' num2str(nep) 'n1.mat'],'Ea1ev','h');
        Eevm(nep,nh)=t.Ea1ev;
        hs(nh)=t.h;
    end
end
figure;
plot(hs,(Ea1evref-Eevm(1,:))./Ea1evref,'-o','LineWidth',1);hold on
plot(hs,(Ea1evref-Eevm(2,:))./Ea1evref,'-+','LineWidth',1);hold on
xlabel('\it h_{\rm [0]}/\rm Bohr');
ylabel('\it \epsilon_{\rm E,r}');
legend('\epsilon=1\times 10^{-6}','\epsilon=1\times 10^{-4}','Location','Northwest');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 12 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'2_ex1.fig');
export_fig(gcf, [pwd '\2_ex1.pdf'], '-r2000', '-transparent');
re1=(Ea1evref-Eevm(2,:)')./Ea1evref';
%%
Eevm=zeros(5,1);
Ras=zeros(5,1);
for nRa=1:5
    t=load([pwd '\singleatom3\a' num2str(nRa) 'h1ep2n1.mat'],'Ea1ev','Ra');
    Eevm(nRa)=t.Ea1ev;
    Ras(nRa)=t.Ra;
end
figure;
plot(Ras,(Ea1evref-Eevm(:,1))./Ea1evref,'-o');hold on
xlabel('\it R_{\rm a}/\rm Bohr');
ylabel('\it \epsilon_{\rm E,r}');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 12 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'2_ex2.fig');
export_fig(gcf, [pwd '\2_ex2.pdf'], '-r2000', '-transparent');

%%
Eevm=zeros(5,6);
Ras=zeros(5,1);
for nh=1:5
    t=load([pwd '\singleatom3\a6h' num2str(nh) 'ep2n1.mat'],'Ea1ev','h');
    Eevm(nh,1)=t.Ea1ev;
    Ras(nh)=t.h;
    t=load([pwd '\singleatom3\a6h' num2str(nh) 'ep2n2.mat'],'Ea1ev');
    Eevm(nh,2)=t.Ea1ev;
    t=load([pwd '\singleatom3\a6h' num2str(nh) 'ep2n3.mat'],'Ea1ev');
    Eevm(nh,3)=t.Ea1ev;    
    t=load([pwd '\singleatom3\a6h' num2str(nh) 'ep2n1o.mat'],'Ea1ev');
    Eevm(nh,4)=t.Ea1ev;
    t=load([pwd '\singleatom3\a6h' num2str(nh) 'ep2n2o.mat'],'Ea1ev');
    Eevm(nh,5)=t.Ea1ev;
    t=load([pwd '\singleatom3\a6h' num2str(nh) 'ep2n3o.mat'],'Ea1ev');
    Eevm(nh,6)=t.Ea1ev; 
end
figure;
plot(Ras,(Ea1evref-Eevm(:,1))./Ea1evref,'-o');hold on
plot(Ras,(Ea1evref-Eevm(:,2))./Ea1evref,'-x');hold on
plot(Ras,(Ea1evref-Eevm(:,3))./Ea1evref,'-*');hold on
plot(Ras,(Ea1evref-Eevm(:,4))./Ea1evref,'-^');hold on
plot(Ras,(Ea1evref-Eevm(:,5))./Ea1evref,'-v');hold on
plot(Ras,(Ea1evref-Eevm(:,6))./Ea1evref,'-+');hold on
xlabel('\it h_{\rm [0]}/\rm Bohr');
ylabel('\it \epsilon_{\rm E,r}');
legend('\it n\rm =1','\it n\rm =2','\it n\rm =3','\it n\rm=1*','\it n\rm=2*','\it n\rm=3*','Location','Northwest');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 12 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'2_ex3.fig');
export_fig(gcf, [pwd '\2_ex3.pdf'], '-r2000', '-transparent');

%%
Eevm=zeros(5,3);
Ras=zeros(5,1);
for nh=1:5
    t=load([pwd '\singleatom2\a6h' num2str(nh) 'ep2n1.mat'],'Ea1ev');
    Eevm(nh,1)=t.Ea1ev;
    t=load([pwd '\singleatom2\a6h' num2str(nh) 'ep2n2.mat'],'Ea1ev');
    Eevm(nh,2)=t.Ea1ev;
    t=load([pwd '\singleatom2\a6h' num2str(nh) 'ep2n2ao.mat'],'Ea1ev');
    Eevm(nh,3)=t.Ea1ev;
    t=load([pwd '\singleatom2\a6h' num2str(nh) 'ep2n1.mat'],'h');
    Ras(nh)=t.h;
end
figure;
plot(Ras,(Ea1evref-Eevm(:,1))./Ea1evref,'-o');hold on
plot(Ras,(Ea1evref-Eevm(:,2))./Ea1evref,'-+');hold on
plot(Ras,(Ea1evref-Eevm(:,3))./Ea1evref,'-x');hold on
xlabel('\it h_{\rm [0]}/\rm Bohr');
ylabel('\it \epsilon_{\rm E,r}');
legend('\it n\rm =1, \it q\rm=4','\it n\rm =2, \it q\rm=4','\it n\rm =2, \it q\rm=2.16','Location','southwest');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 12 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'2_ex4.fig');
export_fig(gcf, [pwd '\2_ex4.pdf'], '-r2000', '-transparent');