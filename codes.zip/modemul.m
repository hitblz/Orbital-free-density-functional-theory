function out=modemul(ten,mat,k)
% szten=size(ten);
% n=length(szten);
% if n<k
%     szten=[szten,ones(1,n-k)];
% end
% nk=szten(k);
% cnk=numel(ten)/nk;
% nk2=size(mat,1);
% szten2=szten;
% szten2(k)=[];
% szten2=[nk2,szten2];
% out=ipermute(reshape(mat*reshape(permute(ten,[k,1:k-1,k+1:n]),nk,cnk),szten2),[k,1:k-1,k+1:n]);

szten=size(ten);
n=length(szten);
out=ipermute(tencontract(mat,2,2,ten,n,k),[k,1:k-1,k+1:n]);
end