function [out,bvs]=Eco2(r,h,Ra,V0,lambda0,bmsig,bimsig,Vsig,Visig)

r=r';
votexm=min(r,[],1)-Ra;
votexM=max(r,[],1)+Ra;
ndiv=ceil((votexM-votexm)./h)+1;
ndiv=ndiv+(mod(ndiv,4)>0).*(4-mod(ndiv,4));
dis=r-votexm;
ns=floor(dis./h);
coors=dis-ns*h;
n1=floor((dis-Ra)/h);
M=size(r,1);
bb=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
Vc=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
bvs=zeros(1,2);

szv=size(bmsig);
b=zeros(szv+2);
b(2:end-1,2:end-1,2:end-1)=bmsig;
bi=zeros(szv+2);
bi(2:end-1,2:end-1,2:end-1)=bimsig;
v=zeros(szv+2);
v(2:end-1,2:end-1,2:end-1)=Vsig;
vi=zeros(szv+2);
vi(2:end-1,2:end-1,2:end-1)=Visig;
x=0:h:(szv(1)+1)*h;
for k=1:M
%     bmsig=bsig3D(Va,n,h,Ra,coors(k,:),Amat1);
%     bimsig=bsig3D1(n,h,Ra,coors(k,:));
    xp={(1:szv(1)+1)'*h-coors(k,1);(1:szv(2)+1)*h-coors(k,2);(1:szv(3)+1)'*h-coors(k,3)};
    bmsigk=interp3(x,x,x,b,xp{1},xp{2},xp{3},'cubic');
    bimsigk=interp3(x,x,x,bi,xp{1},xp{2},xp{3},'cubic');
    Vsigk=interp3(x,x,x,v,xp{1},xp{2},xp{3},'cubic');
    Visigk=interp3(x,x,x,vi,xp{1},xp{2},xp{3},'cubic');
%     bmsig=bmsig(1:end-1,1:end-1,1:end-1);
%     bimsig=bimsig(1:end-1,1:end-1,1:end-1);
    b_bmsigk=bimsigk-bmsigk;
    bbmsigk=bimsigk+bmsigk;
    bb(n1(k,1)+1:n1(k,1)+szv(1)+1,n1(k,2)+1:n1(k,2)+szv(2)+1,n1(k,3)+1:n1(k,3)+szv(3)+1)=bb(n1(k,1)+1:n1(k,1)+szv(1)+1,n1(k,2)+1:n1(k,2)+szv(2)+1,n1(k,3)+1:n1(k,3)+szv(3)+1)+bbmsigk;
    Vcsigk=invIvecsig3(1/(4*pi),h,V0,lambda0,b_bmsigk);   
    Vc(n1(k,1)+1:n1(k,1)+szv(1)+1,n1(k,2)+1:n1(k,2)+szv(2)+1,n1(k,3)+1:n1(k,3)+szv(3)+1)=Vc(n1(k,1)+1:n1(k,1)+szv(1)+1,n1(k,2)+1:n1(k,2)+szv(2)+1,n1(k,3)+1:n1(k,3)+szv(3)+1)+Vcsigk;
    bvs(1)=bvs(1)+bimsigk(:)'*Visigk(:);
    bvs(2)=bvs(2)+bmsigk(:)'*Vsigk(:);
end
out=1/2*(bb(:)'*Vc(:)-bvs(1)+bvs(2));
end