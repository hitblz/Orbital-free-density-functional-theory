function out=Tucker3matvec2(mat,vec)
%matrix-vector product
sz=[size(mat{4},1),size(mat{4},2),size(mat{4},3)];
out=0;
for k1=1:sz(1)
    for k2=1:sz(2)
        for k3=1:sz(3)
            if mat{4}(k1,k2,k3)~=0
                out=out+tucker3product(vec,mat{1}(:,:,k1),mat{2}(:,:,k2),mat{3}(:,:,k3)).*mat{4}(k1,k2,k3);
            end
        end
    end
end
end