function [out, varargout]=assemb1(n,r,h,Ra)

r=r';
votexm=min(r,[],1)-Ra;
votexM=max(r,[],1)+Ra;
ndiv=ceil((votexM-votexm)./h)+1;
ndiv=ndiv+(mod(ndiv,4)>0).*(4-mod(ndiv,4));
dis=r-votexm;
ns=floor(dis./h);
coors=dis-ns*h;
n1=floor((dis-Ra)/h);
M=size(r,1);
out=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
for k=1:M
    t=bsig3D1(n,h,Ra,coors(k,:));
    szv=size(t);
    out(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))=out(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))+t;
end
if nargout>1
    varargout{1}=n1+1;%(0,0,0) grid
    varargout{2}=coors;
end
end