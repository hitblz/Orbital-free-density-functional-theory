function [Ecu,gEcu,phi]=EcgEcsig(task,u,nele,h,Amat,bm,LmuN,imuN,tol,varargin)
N=length(LmuN);
s2=[2/3*ones(N,1);1/6*ones(N-1,1);1/6*ones(N-1,1)];
M={s2;s2;s2;h^3};
%step 1
Mu=Tucker3matvec(M,u,tol);
inprodu=Tucker3inprod(1,u,Mu);
un=u;
a=sqrt(nele/inprodu);
un{4}=un{4}*a;
%step 2
% un2=Tucker3vecHadamard(un,un,tol);
t=tucker3product(un{4},un{1},un{2},un{3});
un2=tensordecompose(7,t.*t,tol,2);
un2m=Tucker3matvec(M,un2,tol);
un2bm=Tucker3vecplus(un2m,bm,tol);
if isempty(varargin)
    phi=invIvecsig(1/(4*pi),h,LmuN,imuN,un2bm,tol);
else
    phi0=varargin{1};
    phi=invIvecsig(1/(4*pi),h,LmuN,imuN,un2bm,tol,phi0);
end
switch task
    case 1%incomplete energy
        Ecu=E(un,h,Amat,phi,tol);% a scalar
    case 2%complete energy
        Ecu=E(un,h,Amat,phi,tol,bm);% a scalar
end
%step 3
gEun=gE(un,h,Amat,phi,M,tol);
lambda=-Tucker3inprod(1,un,gEun)/nele;
cMJun=Mu;
cMJun{4}=lambda*(Mu{4}*a);
gEcu=Tucker3vecplus(gEun,cMJun,tol);
gEcu{4}=gEcu{4}*a;% a vector
end
function out=E(u,h,Amat,phi,tol,varargin)
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec(Amat,u,tol);
out=lam/2*Tucker3inprod(1,u,t);
%second part of kinematic energy + Exc
fkxc=@(v) kxc(v);
fu=funv1(fkxc,u,tol);
out=out+tucker3product(fu{4},sum(fu{1}),sum(fu{2}),sum(fu{3}))*h^3;
%E-I interaction energy
% u2=Tucker3vecHadamard(u,u,tol);
t=tucker3product(u{4},u{1},u{2},u{3});
u2=tensordecompose(7,t.*t,tol,2);
out=out+1/2*Tucker3inprod(2,u2,phi,[h h h],tol);
if ~isempty(varargin)
    bm=varargin{1};
    out=out+1/2*Tucker3inprod(1,bm,phi);
end
end
function out=gE(u,h,Amat,phi,M,tol)
%gradient of total energy with fixed phik
%first update
lam=2/10;
out=Tucker3matvec(Amat,u,tol);
out{4}=out{4}*lam;
%second update
fgkxc=@(v) gkxc(v);
pfu=funv1(fgkxc,u,tol,[h h h]);
out=Tucker3vecplus(out,pfu,tol);
%third update
% uphi=Tucker3vecHadamard(u,phi,tol);
t=tucker3product(u{4},u{1},u{2},u{3});
t2=tucker3product(phi{4},phi{1},phi{2},phi{3});
uphi=tensordecompose(7,t.*t2,tol,2);
uphi{4}=2*uphi{4};
uphi=Tucker3matvec(M,uphi,tol);
out=Tucker3vecplus(out,uphi,tol);
end