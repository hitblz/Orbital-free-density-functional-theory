function phi=invIvecsig3(alpha,h,V,lambdaN,f)
%from invIvecsig2.m, higher-order finite difference
%direct solution
%linear equation corresponding to 1/2*alpha*\int \nabla v .*\nabla v dx

%step 1
phi=tucker3product(f,V',V',V');
phi=phi./(alpha*h);
%step 2
I=lambdaN;
I(:)=1;
t=lambdaN.*I'.*permute(I,[2 3 1]);
phi=((t+permute(t,[2 1 3])+permute(t,[3 2 1])).^(-1)).*phi;
%discrete inverse sine transform
phi=tucker3product(phi,V,V,V);
end