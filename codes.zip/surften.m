function out=surften(ten,k)
ten2=tucker3product(ten{4},ten{1},ten{2},ten{3});
out=figure;
surf(ten2(:,:,k)');
end