%using pseudopotential
%quasi-multigrid
clear
for k0=0:2%level of grid
    %% basic information
    h=0.15*2^(2-k0);
    n2=2*2^(6-2+k0);%number of elements for each atom, EVEN
    D=h*n2;%diameter of an atom
    
    %
    %              7------------------8
    %             / |                        /|
    %           /   |                      /  |
    %          5-----------------6    |
    %          |    3--------------|---4
    %          |   /                    |    /
    %          | /                      | /
    %          1-----------------2
    %% Pseudopotential
    if k0==0
        br=pseudobx(D);%a chebfun
    end
    %% for single atom
    tol=1e-10;
    N=n2-1;
    s1=[2*ones(N,1);-1*ones(N-1,1);-1*ones(N-1,1)];
    s2=[2/3*ones(N,1);1/6*ones(N-1,1);1/6*ones(N-1,1)];
    c=zeros(2,2,2);
    c(1,2,2)=1;
    c(2,1,2)=1;
    c(2,2,1)=1;
    A0mat={[s1,s2];[s1,s2];[s1,s2];c.*h};
    M0={s2;s2;s2;h^3};
    bm=nucchasig(br,n2,h,tol);
    nele=3;
    if k0==0
        uk=metadensitysig(D,n2,M0,nele,tol);
    else
        uk=uk1;
        for k=1:3
            s=size(uk{k},2);
            uk{k}=interp1(0:2:n2,[zeros(1,s);uk{k};zeros(1,s)],1:n2-1);
        end
    end
    u2=Tucker3vecHadamard(uk,uk,tol);
    u2m=Tucker3matvec(M0,u2,tol);
    u2mbm=Tucker3vecplus(u2m,bm,tol);
    
    lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    muN=mu((1:N)');
    LmuN=lambda((1:N)')./muN;
    imuN=muN.^(-1);
    
    maxit=100;
    normu0=sqrt(nele);
    epsilon=[1e-8 1e-8 1e-8];
    
    [Ek,gk,phik]=EcgEcsig(1,uk,nele,h,A0mat,bm,LmuN,imuN,tol);
    dk=gk;
    dk{4}=-dk{4};
    if k0==0
        normgk0=sqrt(Tucker3inprod(1,gk,gk));
    end
    for k=1:maxit
        [uk1,Ek1,gk1,phik1]=bisectionsig(uk,dk,Ek,gk,nele,h,A0mat,bm,LmuN,imuN,tol,phik);
        rnormgk1=sqrt(Tucker3inprod(1,gk1,gk1))/normgk0;
        
        if k==1
            figure;
            title(['level ' num2str(k0)]);
            xlabel('iteration number');
            ylabel('relative error of the gradient');
            fg=animatedline(k,rnormgk1);
        else
            addpoints(fg,k,rnormgk1);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnormgk1<epsilon(k0+1)
            close(gcf);
            inprodu=Tucker3inprod(2,uk1,uk1,[h h h],tol);
            uk1{4}=uk1{4}*sqrt(nele/inprodu);
            fprintf('Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnormgk1);
            break
        end
        betak=(Tucker3inprod(1,gk1,gk1)-Tucker3inprod(1,gk,gk1))/Tucker3inprod(1,gk,gk);%PR
        %   betak=Tucker3inprod(1,gk1,gk1)/Tucker3inprod(1,gk,gk);
        betakdk=dk;
        betakdk{4}=betak*betakdk{4};
        gk1_=gk1;
        gk1_{4}=-gk1{4};
        dk1=Tucker3vecplus(gk1_,betakdk,tol);
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end
end