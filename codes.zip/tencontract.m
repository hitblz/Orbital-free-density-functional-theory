function out=tencontract(ten1,e1,mode1,ten2,e2,mode2,varargin)
%e1 and e2: expected orders of ten1 and ten2
l=length(mode1);
if l~=length(mode2)
    error('incompatible lengths of mode1 and mode2/n');
end
dim1=size(ten1);
o1=length(dim1);
if o1<e1
    dim1=[dim1 ones(1,e1-o1)];
end
if isempty(varargin)==1
    od1=[setdiff(1:e1,mode1) mode1];
    dimre1=dim1(od1);
    dim2=size(ten2);
    o2=length(dim2);
    if o2<e2
        dim2=[dim2 ones(1,e2-o2)];
    end
    od2=[mode2 setdiff(1:e2,mode2)];
    dimre2=dim2(od2);
    out=reshape(reshape(permute(ten1,od1),[prod(dimre1(1:e1-l)) prod(dimre1(e1-l+1:e1))])...
        *reshape(permute(ten2,od2),[prod(dimre2(1:l)) prod(dimre2(l+1:e2))]),[dimre1(1:e1-l) dimre2(l+1:e2)]);
elseif isequal(varargin{1},'inv')%mode1 is the last mode of ten1
    out=reshape(reshape(ten1,[prod(dim1(1:e1-1)) dim1(e1)])/ten2,dim1);
end
end