function out=tucker2ten(v)
out=tucker3product(v{4},v{1},v{2},v{3});
end