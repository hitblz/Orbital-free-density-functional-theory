function out=assem3(task,varargin)
%
tol=1e-10;
switch task
    case 1
        a0=varargin{1};
        ncell=varargin{2};
        v=varargin{3};%v is b or rho
        h=varargin{4};
        if isnumeric(v)
            t=tensordecompose(7,v,tol,2);
        else
            t=v;
        end
        out=cell(4,1);
        t2=cell(1,3);
        for k=1:3
            L=round(a0/h);
            t1=zeros(size(t{k},1)+L*ncell(k),2*size(t{k},2));
            mid=(size(t{k},1)+1)/2;hf=(size(t{k},1)-1)/2;
            t1(mid-hf:mid+hf,1:size(t{k},2))=t{k};
            for k2=1:ncell(k)
                t1(k2*L+mid-hf:k2*L+mid+hf,1:size(t{k},2))=t1(k2*L+mid-hf:k2*L+mid+hf,1:size(t{k},2))+t{k};
                t1((k2-1/2)*L+mid-hf:(k2-1/2)*L+mid+hf,size(t{k},2)+1:2*size(t{k},2))=t1((k2-1/2)*L+mid-hf:(k2-1/2)*L+mid+hf,size(t{k},2)+1:2*size(t{k},2))+t{k};
            end
            t1=tensordecompose(6,t1,tol,2);
            out{k}=t1{1};
            t2{k}=t1{2};
        end
        c0=t{4};
        c0(:,:,:)=0;
        c=cell(2,2,2);
        c{1,1,1}=t{4};
        c{1,2,2}=t{4};
        c{2,1,2}=t{4};
        c{2,2,1}=t{4};
        c{1,1,2}=c0;
        c{1,2,1}=c0;
        c{2,1,1}=c0;
        c{2,2,2}=c0;
        out{4}=tucker3product(cell2mat(c),t2{1},t2{2},t2{3});
        
    case 2
        
        
    case 3
        
        
        
end


end