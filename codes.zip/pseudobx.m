function out=pseudobx(Ra)
Va=chebfun(@(r) -GNH(r),[0,Ra*sqrt(3)],'splitting','on');
r2=chebfun(@(r) r.^2,[0,Ra*sqrt(3)]);
t=-1/(4*pi)*diff(r2.*diff(Va))./r2;
n=2000;
x=linspace(0,Ra*sqrt(3),n+2);
t=t(x);
t(1)=t(2);
out=chebfun.spline(x,t);
end
function out=GNH(r)
A=0.1107;
R=1.150;
Rc=3.5;
Z=3;    
if r>0
    out=2/pi*sum(chebfun(@(t) (sin(r.*t)./(r.*t)).*((Z-A*R)*cos(R.*t)+A*sin(R*t)./t).*exp(-(t./Rc).^6),[0,20],'splitting','on'));
else
    out=2/pi*sum(chebfun(@(t) ((Z-A*R)*cos(R.*t)+A*sin(R*t)./t).*exp(-(t./Rc).^6),[0,20],'splitting','on'));
end
end