function [uk1,Ek1,gk1,phik1,flag,varargout]=VM5_2(epsilon,uk,nele,h,Amat,M,Vs,lambdas,bm)
%from VM3
%V-cycle multigrid
Na=nele/3;
maxit=500;
%optimization begin
[Ek,gk,phik]=EcgEc2(uk,nele,h,Amat,bm,Vs,lambdas,M,0,0,0);
dk=-gk;
flag=0;
for k=1:maxit
    [uk1,Ek1,gk1,phik1]=bisection2(uk,dk,Ek,gk,phik,nele,h,Amat,bm,Vs,lambdas,M,0,0,0);
%     rnorme=norm(uk1(:)-uk(:))/norm(uk(:));
    rnorme=abs(Ek1-Ek)/Na*27.2114;
    if k==1
        figure;
        title('level 0');
        xlabel('iteration number');
        ylabel('relative error');
        fg=animatedline(k,rnorme);
    else
        addpoints(fg,k,rnorme);
    end
    drawnow;
    set(gca,'YScale','log');
    
    if rnorme<epsilon
        flag=1;
        close(gcf);
        fprintf('level 0: Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnorme);
        varargout{1}=k;
        varargout{2}=rnorme;
        break
    end
    varargout{1}=k;
    varargout{2}=rnorme;
    betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
    %  betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));%FR
    dk1=-gk1+betak*dk;
    uk=uk1;
    Ek=Ek1;
    gk=gk1;
    dk=dk1;
    phik=phik1;
%     varargout{1}=flag;
end
%optimization end, get uk1 and gk1
end