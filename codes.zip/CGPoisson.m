function phi=CGPoisson(alpha,Amat,f,phi0)
%from invIvec2
%direct solution
%linear equation corresponding to 1/2*alpha*\int \nabla v .*\nabla v dx
f=f./alpha;
phik=phi0;
rk=Tucker3matvec2(Amat,phik)-f;
pk=-rk;
epsilon=1e-6;
ra=1;
while ra>epsilon
    rkTrk=rk(:)'*rk(:);
    Apk=Tucker3matvec2(Amat,pk);
    ak=rkTrk/(pk(:)'*Apk(:));
    phik1=phik+ak*pk;
    rk1=rk+ak*Apk;
    bk1=(rk1(:)'*rk1(:))/rkTrk;
    pk1=-rk1+bk1*pk;
    ra=norm(rk1(:))/norm(phik1(:));
    rk=rk1;
    phik=phik1;
    pk=pk1;
end
phi=phik;
end