function out=funv2(f,v,tol)

Is=cell(3,1);
for k=1:3
    t=tensordecompose(6,v{k},tol,2);
    Is{k}=sort(t{3}{1});
end
ten2=tucker3product(v{4},v{1}(Is{1},:),v{2}(Is{2},:),v{3}(Is{3},:));
[ma,id]=max(abs(f(ten2(:))));
[id1,id2,id3]=ind2sub([length(Is{1}),length(Is{2}),length(Is{3})],id);
idsets={Is{1}(id1),[Is{2}(id2),Is{3}(id3)];Is{2}(id2),[Is{3}(id3) Is{1}(id1)];Is{3}(id3),[Is{1}(id1) Is{2}(id2)]};
for k=1:3
    pm=[k:3 1:k-1];
    c=permute(v{4},pm);
    sz=[size(v{pm(1)},1) size(v{pm(2)},1) size(v{pm(3)},1)];
    maxrank=max(sz);
    for kk=1:maxrank
        I1=setdiff(1:sz(1),idsets{pm(1),1});
        I2=setdiff(1:sz(2)*sz(3),sub2ind(sz(2:3),idsets{pm(1),2}(1),idsets{pm(1),2}(2)));
        L1=length(I1);
        L2=length(I2);
        j1=sort(randperm(L1,min(L1,5)));
        j2=sort(randperm(L2,min(L2,20)));
        j1=I1(j1);
        j2=I2(j2);
        [j21,j22]=ind2sub(sz(2:3),j2);
        s1=size(c,1);
        s2=length(j2);
        sm=zeros(s1,s2);
        for k2=1:s2
            t1=tencontract(v{pm(2)}(j21(k2),:),2,2,c,3,2);
            t1=tencontract(v{pm(3)}(j22(k2),:),2,2,t1,3,3);
            sm(:,k2)=t1(:);
        end
        t1=f(v{pm(1)}(j1,:)*sm);
        t22=f(v{pm(1)}(idsets{pm(1),1},:)*sm);
        s2=size(idsets{pm(1),2},1);
        sm=zeros(s1,s2);
        for k2=1:s2
            t2=tencontract(v{pm(2)}(idsets{pm(1),2}(k2,1),:),2,2,c,3,2);
            t2=tencontract(v{pm(3)}(idsets{pm(1),2}(k2,2),:),2,2,t2,3,3);
            sm(:,k2)=t2(:);
        end
        t21=f(v{pm(1)}(j1,:)*sm);
        Amid=f(v{pm(1)}(idsets{pm(1),1},:)*sm);
        t21=t21/Amid;
        vals=t1-t21*t22;
        [errmax,id]=max(abs(vals(:)));
        if isempty(errmax)
            errmax=0;
        else
            [~,iII]=ind2sub([length(j1),length(j2)],id);
            [i2,i3]=ind2sub(sz(2:3),j2(iII));
            val=errmax;
            maxn=20;
            it=0;
            while it<maxn
                it=it+1;
                t1=f(tucker3product(c,v{pm(1)}(I1,:),v{pm(2)}(i2,:),v{pm(3)}(i3,:)));
                t21=f(v{pm(1)}(I1,:)*sm);
                t21=t21/Amid;
                t22=f(tucker3product(c,v{pm(1)}(idsets{pm(1),1},:),v{pm(2)}(i2,:),v{pm(3)}(i3,:)));
                [val2,i1]=max(abs(t1-t21*t22));
                i1=I1(i1);
                if abs(val2-val)<1e-10
                    fprintf('maximum found at iteration %i\n',it);
                    break
                end
                val=val2;
                it=it+1;
                t1=f(tucker3product(c,v{pm(1)}(i1,:),v{pm(2)},v{pm(3)}));
                t1=t1(:)';
                t21=f(v{pm(1)}(i1,:)*sm);
                t21=t21/Amid;
                t2=0;
                for k2=1:s2
                    t2=t2+t21(k2)*f(tucker3product(c,v{pm(1)}(idsets{pm(1),1}(k2,:),:),v{pm(2)},v{pm(3)}));
                end
                t2=t2(:)';
                [val2,iII]=max(abs(t1(I2)-t2(I2)));
                [i2,i3]=ind2sub(sz(2:3),I2(iII));
                if abs(val2-val)<1e-8
                    fprintf('maximum found at iteration %i\n',it);
                    break
                end
                val=val2;
            end
            errmax=val2;
        end
        errmax=errmax/ma;
        if errmax<=tol
            fprintf('Dimension (%i, (%i,%i)) converged at rank %i.\n',pm(1),pm(2),pm(3),size(idsets{pm(1),1},1));
            break
        end
        idsets{pm(1),1}=[idsets{pm(1),1};i1];
        idsets{pm(1),2}=[idsets{pm(1),2};[i2,i3]];
    end
end

% scanlist=1:3;
% maxswps=max(sz(:));
% errd=ones(3,1);
% for nswps=1:maxswps
%     for k=1:3
%         if errd(k)<=tol
%             continue
%         else
%             outISE=ISEtenf(f,v,idsets,scanlist,k,tol,ma);
%             idsets=outISE{1};
%             errd(k)=outISE{2};
%         end
%     end
%     if max(errd)<=tol || nswps==maxswps
%         fprintf('sweeping completed \n');
%         break
%     end
% end
out=cell(4,1);
for k=1:3
    pm=[k:3 1:k-1];
    c=permute(v{4},pm);
    sz=[size(c,1),size(c,2),size(c,3)];
    s2=size(idsets{pm(1),2},1);
    sm=zeros(sz(1),s2);
    for k2=1:s2
        t2=tencontract(v{pm(2)}(idsets{pm(1),2}(k2,1),:),2,2,c,3,2);
        t2=tencontract(v{pm(3)}(idsets{pm(1),2}(k2,2),:),2,2,t2,3,3);
        sm(:,k2)=t2(:);
    end
    t21=f(v{pm(1)}*sm);
    out{k}=t21/t21(idsets{pm(1),1},:);
end
out{4}=f(tucker3product(v{4},v{1}(idsets{1,1},:),v{2}(idsets{2,1},:),v{3}(idsets{3,1},:)));
end