function [out, varargout]=assem5(protect,v,r,h,Ra)

r=r';
votexm=min(r,[],1)-Ra;
votexM=max(r,[],1)+Ra;
ndiv=ceil((votexM-votexm)./h)+1;
ndiv=ndiv+(mod(ndiv,4)>0).*(4-mod(ndiv,4));
dis=r-votexm;
ns=floor(dis./h);
coors=dis-ns*h;
coors(coors<0)=0;
n1=floor((dis-Ra)./h);
M=size(r,1);
switch protect
    case 0
        out=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
    case 1
        out=ones(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1)*1e-8;
end
szv=size(v);
vx=zeros(szv+2);
vx(2:end-1,2:end-1,2:end-1)=v;
x=0:h:(szv(1)+1)*h;
for k=1:M
    xp={(1:szv(1)+1)'*h-coors(k,1);(1:szv(2)+1)*h-coors(k,2);(1:szv(3)+1)'*h-coors(k,3)};
    t=interp3(x,x,x,vx,xp{1},xp{2},xp{3});
    out(n1(k,1)+1:n1(k,1)+szv(1)+1,n1(k,2)+1:n1(k,2)+szv(2)+1,n1(k,3)+1:n1(k,3)+szv(3)+1)=out(n1(k,1)+1:n1(k,1)+szv(1)+1,n1(k,2)+1:n1(k,2)+szv(2)+1,n1(k,3)+1:n1(k,3)+szv(3)+1)+t;
end
if nargout>1
    varargout{1}=n1+1;%(0,0,0) grid
    varargout{2}=coors;
end
end