uL0=uk1;
P=cell(1,4);%prolongation
szu=[size(uL0,1) size(uL0,2) size(uL0,3)];% uk is at level 1
for k=1:3
    t=zeros(2*szu(k)+1,szu(k));
    for k2=1:szu(k)
        t(2*k2-1:2*k2+1,k2)=[0.5;1;0.5];
    end
    P{k}=t;
end
P{4}=1;
uL0=Tucker3matvec2(P,uL0);

%pre-computing prolongation and restriction operator
P=cell(4,2);%prolongation
R=cell(4,2);%restriction
for i=1:2
    szu=(n2h(op)*2^(3-i)-1)*[1 1 1];% uk is at level 1
    for k=1:3
        P{k,i}=zeros(2*szu(k)+1,szu(k));
        for k2=1:szu(k)
            P{k,i}(2*k2-1:2*k2+1,k2)=[0.5;1;0.5];
        end
        R{k,i}=P{k,i}'./2;
    end
    P{4,i}=1;
    R{4,i}=1;
end
%%
flags=[0 0 0];
for it=1:30
    for level=0:2
        switch level
            case 0
                [uL0,EuL0,guL0,phi,flag,nit]=VM4(it,epsilons,uL0,nele,h,Amats(1,:),Ms(1,:),Vs{1},lambdas{1},bm{1},P,R,0,0);
                flags(1)=flag;
                if flags(1)==1
                    break
                end
            case 1
                if flags(2)==0
                    uL1i=Tucker3matvec2(R(:,1)',uL0);
                    [uL1,EuL1,guL1,phi,flag,v1]=VM4(it,epsilons,uL1i,nele,h,Amats(2,:),Ms(2,:),Vs{2},lambdas{2},bm{2},P,R,guL0,0);
                    flags(2)=flag;
                end
            case 2
                if flags(3)==0
                    uL2i=Tucker3matvec2(R(:,2)',uL1);
                    [uL2,EuL2,guL2,phi,flag]=VM4(it,epsilons,uL2i,nele,h,Amats(3,:),Ms(3,:),Vs{3},lambdas{3},bm{3},P,R,guL0,guL1,v1);
                    flags(3)=flag;
                end
        end
    end
    if flags(1)==1
        break
    end
    if flags(3)==0
        e=Tucker3matvec2(P(:,2)',uL2-uL2i);
        [uL1,EuL1,guL1,phi]=bisectionsig6(uL1,e,EuL1,guL1,phi,nele,h,Amats(2,:),bm{2},Vs{2},lambdas{2},Ms(2,:),P,v1,0);
    end%Amats,Ms,Vs,lambdas
    if flags(2)==0
        e=Tucker3matvec2(P(:,1)',uL1-uL1i);
        [uL0,EuL0,guL0,phi]=bisectionsig6(uL0,e,EuL0,guL0,phi,nele,h,Amats(1,:),bm{1},Vs{1},lambdas{1},Ms(1,:),P,0,0);
    end
end
close all
%%
N=n2-1;

Mu=Tucker3matvec2(Ms(1,:),uL0);
inprodu=uL0(:)'*Mu(:);
a=sqrt(nele/inprodu);
uL0=uL0.*a;
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amats(1,:),uL0);
E1=lam/2.*uL0(:)'*t(:);
%second part of kinematic energy + Exc
u2=uL0.^2;
fu=kxc1(uL0);
t=Tucker3matvec2(M,fu);
E2=u2(:)'*t(:);
%E-I interaction energy
t=Tucker3matvec2(Ms(1,:),phi);
E3=1/2*(u2(:)'*t(:)+bm{1}(:)'*phi(:));

E4=-1/2*bm{1}(:)'*Vsig{1}(:);
Et1=E1+E2+E3+E4;
Ea1ev=Et1*27.2114;
tim=toc;
add=[pwd '\singleatom3\'];
save([add, 'a1h1ep1n1.mat'],'-v7.3');
close all