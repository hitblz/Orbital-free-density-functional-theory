%formal version
%main program of the single-grid solver
%from main4sg_24_5, higher-order finite difference method
clear
tic;%time begin
add=[pwd '\singleatom3\'];%path of the single-atom data
fl='r6h5ep2n3o.mat';%name of the single-atom data
%% V-multigrid
epsilon=1e-4;%tolerance of the relative error
y=0;
t=load([add fl],'Ra','nele','h','Vsig','uL0','bm','N','Va');%loading variables from the single-atom data 
nele=t.nele;%number of valence electrons
h=t.h;%grid size
Vsig=t.Vsig;%pseudopotential function of a single atom
Va=t.Va;%pseudopotential function of a single atom in chebfun format
uL0sig=normalize(1,t.uL0,nele,h);%normalization of u of a single atom
bmsig=t.bm;bmsig=bmsig{1};%the inner product of b and shape functions
Nsig=t.N;%number of grid points
Ra=t.Ra;%radius of a single atom
% F=[0,0.2,0;0,0,0;0,0,0];
a0=8;%lattice constant
ncell=[1 1 1]*5;%number of cells in each direction
r0list=r0cgen(ncell)*a0;%list of ion positions in reference configuration
r0=r0list';
F=[0,y,0;0,0,0;0,0,0];%defornation gradient tensor
r=(eye(3)+F)*r0;%list of ion positions in deformed configuration

%%
Na=size(r0list,1);%number of atoms
nele=Na*nele;%number of valent electrons

n=3;%order of finite difference
wp=zeros(1,n+1);%weights
for p=0:n
    if p==0
        wp(p+1)=2*sum((1:n).^(-2));
    else
        wp(p+1)=2*(-1)^p/p^2*factorial(n)^2/(factorial(n-p)*factorial(n+p));
    end
end
% wp=[34 -16 -1]./20;
% n=2;
xwp=[wp(n+1:-1:2) wp];
wp2=[1 0];
xwp2=[wp2(2) wp2];
xwp2=xwp2./sum(xwp2);

As1=zeros(Nsig+3+2*n,Nsig+3+2*n,2);%for computing bL0
for k=1:Nsig+3+2*n
    a1=n+2-min(k,n+1);
    b1=max(1,k-n);
    lb=Nsig+3+2*n-(b1-1);
    la=2*n+1-(a1-1);
    ly=min(la,lb);
    a2=a1-1+ly;
    b2=b1-1+ly;
    As1(k,b1:b2,1)=xwp(a1:a2);
    
    c1=1+2-min(k,1+1);
    d1=max(1,k-1);
    ld=Nsig+3+2*n-(d1-1);
    lc=2*1+1-(c1-1);
    lz=min(lc,ld);
    c2=c1-1+lz;
    d2=d1-1+lz;
    As1(k,d1:d2,2)=xwp2(c1:c2);
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat1={As1;As1;As1;c.*h};

rhoi=assem5(1,uL0sig.^2,r,h,Ra);%assembling the initial electron density
uL0i=sqrt(rhoi);
uL0=uL0i;
% bL0=assem5(0,bmsig,r,h,Ra);
bL0=assemb(Va,n,r,h,Ra,Amat1);%assembling the nuclei charge density

Amat=cell(1,4);%coefficient matrix of the Poission equation
M=cell(1,4);
Vs=cell(1,3);
lambdas=cell(1,3);
for i=1:3%dimension
    N=size(uL0,i);
    As=zeros(N,N,2);
    for k=1:N
        a1=n+2-min(k,n+1);
        b1=max(1,k-n);
        lb=N-(b1-1);
        la=2*n+1-(a1-1);
        ly=min(la,lb);
        a2=a1-1+ly;
        b2=b1-1+ly;
        As(k,b1:b2,1)=xwp(a1:a2);
        
        c1=1+2-min(k,1+1);
        d1=max(1,k-1);
        ld=N-(d1-1);
        lc=2*1+1-(c1-1);
        lz=min(lc,ld);
        c2=c1-1+lz;
        d2=d1-1+lz;
        As(k,d1:d2,2)=xwp2(c1:c2);
    end
    Amat{i}=As;
    M{i}=As(:,:,2);
    [V,lambdaN]=eig(As(:,:,1),As(:,:,2));lambdaN=diag(lambdaN);
    Vs{i}=V;lambdas{i}=lambdaN;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat{4}=c.*h;
M{4}=h^3;
%[EuL0i,guL0i,phiL0i]=EcgEc(1,uL0i,nele,h,Amat,bL0,LmuN,imuN,M,0,0,0);
%initialization end
%solution begin
[uL0,EuL0,guL0,phiL0,flag,nit,epsa]=VM5_2(epsilon,uL0,nele,h,Amat,M,Vs,lambdas,bL0);%single-grid solver
%solution is done
%uL0: the square root of the electron density
%EuL0: total energy
%gradient of the total energy
%phiL0: total electrostatic potential
%flag: convergence mark
%nit: number of iterations
%epsa: actural value of the relative error
Mu=Tucker3matvec2(M,uL0);% the inner product of uL0 and shape functions
inprodu=uL0(:)'*Mu(:);
a=sqrt(nele/inprodu);
uL0=uL0.*a;%normalization
%%
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat,uL0);
E1=lam/2.*(uL0(:)'*t(:));
%second part of kinematic energy + Exc
fu=kxc(uL0);
u2=uL0.^2;
E2=sum(fu,'all')*h^3;
%E-I interaction energy
t=Tucker3matvec2(M(1,:),u2)+bL0;
E3=1/2*(t(:)'*phiL0(:));
% E4=-1/2*Na*(bmsig(:)'*Vsig{1}(:));
% E0=E1+E2+E3+E4;
% E0ev=E0/Na*27.2114;

Ass=zeros(Nsig+1,Nsig+1,2);%for computing the nuclei charge density
for k=1:Nsig+1
    a1=n+2-min(k,n+1);
    b1=max(1,k-n);
    lb=Nsig+1-(b1-1);
    la=2*n+1-(a1-1);
    ly=min(la,lb);
    a2=a1-1+ly;
    b2=b1-1+ly;
    Ass(k,b1:b2,1)=xwp(a1:a2);
end
for k=1:Nsig+1
    Ass(k,k,2)=1;
end
% c=zeros(2,2,2);
% c(1,2,2)=1;
% c(2,1,2)=1;
% c(2,2,1)=1;
% Asig={As;As;As;c.*h};
[V0,lambda0]=eig(Ass(:,:,1),Ass(:,:,2),'vector');
[Ecn,bvs]=Eco(Va,n,r,h,Ra,V0,lambda0,Amat1);%computing the correction term in the total energy
Eac=(E1+E2+E3-1/2*bvs(2)+Ecn)/Na*27.2114;%computing the total energy

tim=toc;%time end
add2=[pwd '\atomcluster\'];
save([add2, 'n5a8r6h5ep2n3osgT.mat'],'-v7.3');