function [vk1,uk1,Ek1,gk1,phik1,flag,k]=VM6_3(epsilon,r,Ra,vk,nele,h,Amat,M,Vs,lambdas,bm,Va,n,V0,lambda0,Amat1)
%from VM6
%V-cycle multigrid
Na=nele/3;
maxit=500;
%optimization begin
[Ek,uk,gk,phik]=EcgEc4_2(r,Ra,vk,nele,h,Amat,bm,Vs,lambdas,Va,n,V0,lambda0,Amat1,M,0,0,0);
dk=-gk;
flag=0;
for k=1:maxit(1)
    [vk1,uk1,Ek1,gk1,phik1]=bisection3_2(r,Ra,vk,uk,dk,Ek,gk,phik,nele,h,Amat,bm,Vs,lambdas,Va,n,V0,lambda0,Amat1,M,0,0,0);
    rnorme=abs(Ek1-Ek)/Na*27.2114;
    
    if k==1
        figure;
        title(' level 0');
        xlabel('iteration number');
        ylabel('relative error');
        fg=animatedline(k,rnorme);
    else
        addpoints(fg,k,rnorme);
    end
    drawnow;
    set(gca,'YScale','log');
    
    if rnorme<epsilon
        flag=1;
        close(gcf);
        fprintf('level 0: Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnorme);
        break
    end
    betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
    %  betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));%FR
    dk1=-gk1+betak*dk;
    vk=vk1;
    uk=uk1;
    Ek=Ek1;
    gk=gk1;
    dk=dk1;
    phik=phik1;
end
%optimization end, get uk1 and gk1
end