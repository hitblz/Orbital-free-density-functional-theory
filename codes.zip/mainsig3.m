%using pseudopotential
%quasi-multigrid
clear
op=1;
Ra=4.8;
n2v=48;
n2h=n2v./4;
hf=Ra./n2v;
%group 1 
% Ra=8;
% n2v=[80 40 20 16];
% n2h=n2v./4;
% hf=Ra./n2v;
%group 2 
% Ra=7.2;
% n2v=[40 20 16 12];
% n2h=n2v./4;
% hf=Ra./n2v;
%group 3
% Ra=6.4;
% n2v=[20 16 12 8];
% n2h=n2v./4;
% hf=Ra./n2v;
%group 4
% Ra=5.6;
% n2v=[20 16 12 8];
% n2h=n2v./4;
% hf=Ra./n2v;
% %group 5
% Ra=4.8;
% n2v=[40 16 12 8];
% n2h=n2v./4;
% hf=Ra./n2v;

levels=[2 1];
epsilon=[1 1]*1e-6;
maxit=[15 15];% for fast initialization
for k0=1:2%level of grid
    %% basic information
    h=hf(op)*2^(levels(k0));
    n2=n2h(op)*2^(3-levels(k0));%number of elements for each atom, EVEN
%     Ra=h*n2/2;%diameter of an atom
    
    %
    %              7------------------8
    %             / |                        /|
    %           /   |                      /  |
    %          5-----------------6    |
    %          |    3--------------|---4
    %          |   /                    |    /
    %          | /                      | /
    %          1-----------------2
    %% Pseudopotential
    if k0==1
        br=pseudobx(Ra);%a chebfun
    end
    %% for single atom
    tol=1e-10;
    N=n2-1;
    As=zeros(N,N,2);
    for k=1:N
        As(k,k,1)=2;
        As(k,k,2)=2/3;
    end
    for k=1:N-1
        As(k+1,k,1)=-1;
        As(k,k+1,1)=-1;
        As(k+1,k,2)=1/6;
        As(k,k+1,2)=1/6;
    end
    c=zeros(2,2,2);
    c(1,2,2)=1;
    c(2,1,2)=1;
    c(2,2,1)=1;
    Amat={As;As;As;c.*h};
    M={As(:,:,2);As(:,:,2);As(:,:,2);h^3};
    bm=nucchasig(br,n2,h,tol,1);
    bm=tucker3product(bm);
    nele=3;
    if k0==1
        uk=metadensitysig2(Ra,n2,M,nele);
    else
        uk=uk1;
        P=cell(1,4);%prolongation
        szu=[size(uk,1) size(uk,2) size(uk,3)];% uk is at level 1
        for k=1:3
            t=zeros(2*szu(k)+1,szu(k));
            for k2=1:szu(k)
                t(2*k2-1:2*k2+1,k2)=[0.5;1;0.5];
            end
            P{k}=t;
        end
        P{4}=1;
        uk=Tucker3matvec2(P,uk);
    end
    
    lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    muN=mu((1:N)');
    LmuN=lambda((1:N)')./muN;
    imuN=muN.^(-1);
    
    normu0=sqrt(nele);
    
    [Ek,gk,phi]=EcgEcsig3(1,uk,nele,h,Amat,bm,LmuN,imuN,M);
    dk=-gk;
    
    for k=1:maxit(k0)
        [uk1,Ek1,gk1,phi]=bisectionsig3(uk,dk,Ek,gk,nele,h,Amat,bm,LmuN,imuN,M);
        rnorme=norm(uk1(:)-uk(:))/norm(uk(:));
        
        if k==1
            figure;
            title(['level ' num2str(levels(k0))]);
            xlabel('iteration number');
            ylabel('relative error of the gradient');
            fg=animatedline(k,rnorme);
        else
            addpoints(fg,k,rnorme);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnorme<epsilon(k0)
            close(gcf);
            t=Tucker3matvec2(M,uk1);
            inprodu=uk1(:)'*t(:);
            uk1=uk1.*sqrt(nele/inprodu);
            fprintf('level %i Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k0,k,rnorme);
            break
        end
        betak=(gk1(:)'*gk1(:)-gk(:)'*gk1(:))/(gk(:)'*gk(:));%PR
        %betak=(gk1(:)'*gk1(:))/(gk(:)'*gk(:));
        dk1=-gk1+betak*dk;
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
    end
end
%%%%Initialization end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% V-multigrid
h=hf(op);
n2=n2h(op)*2^3;%number of elements for each atom, EVEN
%Ra=h*n2/2;%diameter of an atom

bm=cell(3,1);
for k=1:3
    bm{k}=nucchasig(br,n2/2^(k-1),h*2^(k-1),tol,1);
    bm{k}=tucker3product(bm{k});
end
uL0=uk1;
P=cell(1,4);%prolongation
szu=[size(uL0,1) size(uL0,2) size(uL0,3)];% uk is at level 1
for k=1:3
    t=zeros(2*szu(k)+1,szu(k));
    for k2=1:szu(k)
        t(2*k2-1:2*k2+1,k2)=[0.5;1;0.5];
    end
    P{k}=t;
end
P{4}=1;
uL0=Tucker3matvec2(P,uL0);

%pre-computing prolongation and restriction operator
P=cell(4,2);%prolongation
R=cell(4,2);%restriction
for i=1:2
    szu=(n2h(op)*2^(3-i)-1)*[1 1 1];% uk is at level 1
    for k=1:3
        P{k,i}=zeros(2*szu(k)+1,szu(k));
        for k2=1:szu(k)
            P{k,i}(2*k2-1:2*k2+1,k2)=[0.5;1;0.5];
        end
        R{k,i}=P{k,i}'./2;
    end
    P{4,i}=1;
    R{4,i}=1;
end
%%
flags=[0 0 0];
for it=1:20
    for level=0:2
        switch level
            case 0
                [uL0,EuL0,guL0,phi,flag]=VM2(it,uL0,nele,h,bm{1},P,R,0,0);
                flags(1)=flag;
                if flags(1)==1
                    break
                end
            case 1
                if flags(2)==0
                    uL1i=Tucker3matvec2(R(:,1)',uL0);
                    [uL1,EuL1,guL1,phi,flag,v1]=VM2(it,uL1i,nele,h,bm{2},P,R,guL0,0);
                    flags(2)=flag;
                end
            case 2
                if flags(3)==0
                    uL2i=Tucker3matvec2(R(:,2)',uL1);
                    [uL2,EuL2,guL2,phi,flag]=VM2(it,uL2i,nele,h,bm{3},P,R,guL0,guL1,v1);
                    flags(3)=flag;
                end
        end
    end
    if flags(1)==1
        break
    end
    if flags(3)==0
        e=Tucker3matvec2(P(:,2)',uL2-uL2i);
        N=size(e,1);
        As=zeros(N,N,2);
        for k=1:N
            As(k,k,1)=2;
            As(k,k,2)=2/3;
        end
        for k=1:N-1
            As(k+1,k,1)=-1;
            As(k,k+1,1)=-1;
            As(k+1,k,2)=1/6;
            As(k,k+1,2)=1/6;
        end
        c=zeros(2,2,2);
        c(1,2,2)=1;
        c(2,1,2)=1;
        c(2,2,1)=1;
        Amat={As;As;As;c.*(2*h)};
        M={As(:,:,2);As(:,:,2);As(:,:,2);(2*h)^3};
        lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
        mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
        muN=mu((1:N)');
        LmuN=lambda((1:N)')./muN;
        imuN=muN.^(-1);
        [uL1,EuL1,guL1,phi,flag]=bisectionsig4(uL1,e,EuL1,guL1,phi,nele,h,Amat,bm{2},LmuN,imuN,M,P,v1,0);
    end
    if flags(2)==0
        e=Tucker3matvec2(P(:,1)',uL1-uL1i);
        N=size(e,1);
        As=zeros(N,N,2);
        for k=1:N
            As(k,k,1)=2;
            As(k,k,2)=2/3;
        end
        for k=1:N-1
            As(k+1,k,1)=-1;
            As(k,k+1,1)=-1;
            As(k+1,k,2)=1/6;
            As(k,k+1,2)=1/6;
        end
        c=zeros(2,2,2);
        c(1,2,2)=1;
        c(2,1,2)=1;
        c(2,2,1)=1;
        Amat={As;As;As;c.*h};
        M={As(:,:,2);As(:,:,2);As(:,:,2);h^3};
        lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
        mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
        muN=mu((1:N)');
        LmuN=lambda((1:N)')./muN;
        imuN=muN.^(-1);
        [uL0,EuL0,guL0,phi,flag]=bisectionsig4(uL0,e,EuL0,guL0,phi,nele,h,Amat,bm{1},LmuN,imuN,M,P,0,0);
    end
end
%%
N=n2-1;
As=zeros(N,N,2);
for k=1:N
    As(k,k,1)=2;
    As(k,k,2)=2/3;
end
for k=1:N-1
    As(k+1,k,1)=-1;
    As(k,k+1,1)=-1;
    As(k+1,k,2)=1/6;
    As(k,k+1,2)=1/6;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat={As;As;As;c.*h};
M={As(:,:,2);As(:,:,2);As(:,:,2);h^3};
lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
muN=mu((1:N)');
LmuN=lambda((1:N)')./muN;
imuN=muN.^(-1);

Mu=Tucker3matvec2(M,uL0);
inprodu=uL0(:)'*Mu(:);
a=sqrt(nele/inprodu);
uL0=uL0.*a;
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat,uL0);
E0=lam/2.*uL0(:)'*t(:);
%second part of kinematic energy + Exc
fu=kxc(uL0);
E0=E0+sum(fu,'all')*h^3;
%E-I interaction energy
u2=uL0.^2;
t=Tucker3matvec2(M,phi);
E0=E0+1/2*(u2(:)'*t(:)+bm{1}(:)'*phi(:));

Va=pseudopotential(Ra);
Vsig=ppten(Va,N+1,h,tol,1);
Vsig=tucker3product(Vsig);
E0=E0-1/2*bm{1}(:)'*Vsig(:);
E0ev=E0*27.2114;