function phi=invIvecsig(alpha,h,LmuN,imuN,f,tol,varargin)
%direct solution
%linear equation corresponding to 1/2*alpha*\int \nabla v .*\nabla v dx
methodDST=1;
%discrete sine transform
phi=f;
for k=1:3
    phi{k}=fDST(phi{k},methodDST);
    phi{k}=imuN.*phi{k};
end
phi{4}=phi{4}./(alpha*h);
eADI=1e-8;
if isempty(varargin)
    phi=ADI(LmuN,phi,tol,eADI);
else
    Sphi=varargin{1};
    for k=1:3
        Sphi{k}=fDST(Sphi{k},methodDST);
    end
    phi=ADI(LmuN,phi,tol,eADI,Sphi);
end
%discrete inverse sine transform
for k=1:3
    phi{k}=fDST(phi{k},methodDST);
end
end