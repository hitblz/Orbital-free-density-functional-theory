%using pseudopotential
%quasi-multigrid
clear
levels=[2 1];
epsilon=[1e-8 1e-8];
maxit=[10 5];% for fast initialization
for k0=1:2%level of grid
    %% basic information
    h=0.1*2^(levels(k0));
    n2=20*2^(3-levels(k0));%number of elements for each atom, EVEN
    D=h*n2;%diameter of an atom
    
    %
    %              7------------------8
    %             / |                        /|
    %           /   |                      /  |
    %          5-----------------6    |
    %          |    3--------------|---4
    %          |   /                    |    /
    %          | /                      | /
    %          1-----------------2
    %% Pseudopotential
    if k0==1
        br=pseudobx(D);%a chebfun
    end
    %% for single atom
    tol=1e-10;
    N=n2-1;
    s1=[2*ones(N,1);-1*ones(N-1,1);-1*ones(N-1,1)];
    s2=[2/3*ones(N,1);1/6*ones(N-1,1);1/6*ones(N-1,1)];
    c=zeros(2,2,2);
    c(1,2,2)=1;
    c(2,1,2)=1;
    c(2,2,1)=1;
    Amat={[s1,s2];[s1,s2];[s1,s2];c.*h};
    M0={s2;s2;s2;h^3};
    bm=nucchasig(br,n2,h,tol);
    nele=3;
    if k0==1
        uk=metadensitysig(D,n2,M0,nele,tol);
    else
        uk=uk1;
        for k=1:3
            s=size(uk{k},2);
            uk{k}=interp1(0:2:n2,[zeros(1,s);uk{k};zeros(1,s)],1:n2-1);
        end
    end
    %     u2=Tucker3vecHadamard(uk,uk,tol);
    %     u2m=Tucker3matvec(M0,u2,tol);
    %     u2mbm=Tucker3vecplus(u2m,bm,tol);
    
    lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
    mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
    muN=mu((1:N)');
    LmuN=lambda((1:N)')./muN;
    imuN=muN.^(-1);        
    normu0=sqrt(nele);    
    
    [Ek,gk,phik]=EcgEcsig(1,uk,nele,h,Amat,bm,LmuN,imuN,tol);
    dk=gk;
    dk{4}=-dk{4};
    if k0==1
        normgk0=sqrt(Tucker3inprod(1,gk,gk));
    end
    for k=1:maxit(k0)
        [uk1,Ek1,gk1,phik1]=bisectionsig(uk,dk,Ek,gk,nele,h,Amat,bm,LmuN,imuN,tol,phik);
        rnormgk1=sqrt(Tucker3inprod(1,gk1,gk1))/normgk0;
        
        if k==1
            figure;
            title(['level ' num2str(levels(k0))]);
            xlabel('iteration number');
            ylabel('relative error of the gradient');
            fg=animatedline(k,rnormgk1);
        else
            addpoints(fg,k,rnormgk1);
        end
        drawnow;
        set(gca,'YScale','log');
        
        if rnormgk1<epsilon(k0)
            close(gcf);
            inprodu=Tucker3inprod(2,uk1,uk1,[h h h],tol);
            uk1{4}=uk1{4}*sqrt(nele/inprodu);
            fprintf('Conjugate gradient iteration converged at iteration %i with relative residual %10.4e.\n',k,rnormgk1);
            break
        end
        betak=(Tucker3inprod(1,gk1,gk1)-Tucker3inprod(1,gk,gk1))/Tucker3inprod(1,gk,gk);%PR
        %   betak=Tucker3inprod(1,gk1,gk1)/Tucker3inprod(1,gk,gk);
        betakdk=dk;
        betakdk{4}=betak*betakdk{4};
        gk1_=gk1;
        gk1_{4}=-gk1{4};
        dk1=Tucker3vecplus(gk1_,betakdk,tol);
        uk=uk1;
        Ek=Ek1;
        gk=gk1;
        dk=dk1;
        phik=phik1;
    end
end
%%%%Initialization end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% V-multigrid
h=0.1;
n2=20*2^3;%number of elements for each atom, EVEN
D=h*n2;%diameter of an atom
N=n2-1;
s1=[2*ones(N,1);-1*ones(N-1,1);-1*ones(N-1,1)];
s2=[2/3*ones(N,1);1/6*ones(N-1,1);1/6*ones(N-1,1)];
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat={[s1,s2];[s1,s2];[s1,s2];c.*h};
M0={s2;s2;s2;h^3};
bm=nucchasig(br,n2,h,tol);
uL0=uk1;
for k=1:3
    s=size(uL0{k},2);
    uL0{k}=interp1(0:2:n2,[zeros(1,s);uL0{k};zeros(1,s)],1:n2-1);
end

lambda=@(k) 2-2*cos(k*pi/(N+1));%increasing
mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
muN=mu((1:N)');
LmuN=lambda((1:N)')./muN;
imuN=muN.^(-1);

%pre-computing prolongation and restriction operator
P=cell(3,2);%prolongation
R=cell(3,2);%restriction
for i=1:2
    szu=(2^(7-i)-1)*[1 1 1];% uk is at level 1
    for k=1:3
        P{k,i}=zeros(2*szu(k)+1,szu(k));
        for k2=1:szu(k)
            P{k,i}(2*k2-1:2*k2+1,k2)=[0.5;1;0.5];
        end
        R{k,i}=P{k,i}'./2;
    end
end
%%
phiuL0=phik1;
for k=1:3
    phiuL0{k}=P{k,1}*phiuL0{k};
end
for it=1:5
    for level=0:2
        switch level
            case 0
                [uL0,EuL0,guL0,phiuL0,flag]=VM(it,uL0,phiuL0,nele,h,Amat,bm,LmuN,imuN,tol,P,R,0,0,normgk0);
                if flag==1
                    break
                end
            case 1
                uL1i=uL0;
                for k=1:3
                    uL1i{k}=R{k,1}*uL1i{k};
                end
                [uL1,EuL1,guL1,phiuL1,v1]=VM(it,uL1i,phiuL0,nele,h,Amat,bm,LmuN,imuN,tol,P,R,guL0,0,normgk0);
            case 2
                uL2i=uL1;
                for k=1:3
                    uL2i{k}=R{k,2}*uL2i{k};
                end
                [uL2,EuL2,guL2,phiuL2]=VM(it,uL2i,phiuL1,nele,h,Amat,bm,LmuN,imuN,tol,P,R,guL0,guL1,normgk0,v1);
        end
    end
    
    uL2i_=uL2i;
    uL2i_{4}=-uL2i{4};
    e=Tucker3vecplus(uL2,uL2i_,tol);
    for k=1:3
        e{k}=P{k,2}*e{k};
    end
    [uL1,EuL1,guL1,phiuL1]=bisectionsig2(uL1,e,EuL1,guL1,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,0,phiuL1);
    
    uL1i_=uL1i;
    uL1i_{4}=-uL1i{4};
    e=Tucker3vecplus(uL1,uL1i_,tol);
    for k=1:3
        e{k}=P{k,1}*e{k};
    end
    [uL0,EuL0,guL0,phiuL0]=bisectionsig2(uL0,e,EuL0,guL0,nele,h,Amat,bm,LmuN,imuN,tol,P,0,0,phiuL0);
end