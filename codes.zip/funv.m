function out=funv(f,v,tol,varargin)
%the fast mimic algorithm in Oseledets (2010)
% general nonlinear function of a vector in (3,0) format
% f is a function handle or a subroutine
%To serve for OFDFT, for simplicity, it is assumed that the length of
%size(v{1},1)=size(v{2},1)=size(v{3},1);
if nargin<4% for integration of energy function
    sk=cell(3,1);
    for k=1:3
        t=tensordecompose(6,v{k},tol,2);
        sk{k}=sort(t{3}{1});
    end
    t=tucker3product(v{4},v{1}(sk{1},:),v{2}(sk{2},:),v{3}(sk{3},:));   
    t=tensordecompose(7,t,tol,2);
    out=cell(4,1);
    out{4}=f(t{4});
    sk2=cell(3,1);
    for k=1:3
        pk=[k:3 1:k-1];
        sk2{k}=[sk{pk(2)}(t{5}{k,2}(:,1)) sk{pk(3)}(t{5}{k,2}(:,2))];
        s=size(v{4},k);
        sm=zeros(s,s);
        c=permute(t{4},pk);
        for k2=1:s
            tm=tencontract(v{pk(2)}(sk2{k}(k2,1),:),2,2,c,3,2);
            tm=tencontract(v{pk(3)}(sk2{k}(k2,2),:),2,2,tm,3,3);
            sm(:,k2)=tm(:);
        end
        out{k}=f(v{k}*sm);
        out{k}=out{k}/out{k}(sk{k},:);
    end
    
else% for the gradient of energy function
    out=funv(f,v,tol);
    Ns=[size(out{1},1) size(out{2},1) size(out{3},1)];
    M=cell(4,1);
    for k=1:3
        M{k}=[2/3*ones(Ns(k),1);1/6*ones(Ns(k)-1,1);1/6*ones(Ns(k)-1,1)];
    end
    h=varargin{1};
    M{4}=prod(h);
    out=Tucker3matvec(M,out,tol);
    
end
end