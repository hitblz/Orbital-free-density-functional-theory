function Ecu=Ectest(u,nele,h,phi)

N=size(u,1);
As=zeros(N,N,2);
for k=1:N
    As(k,k,1)=2;
    As(k,k,2)=2/3;
end
for k=1:N-1
    As(k+1,k,1)=-1;
    As(k,k+1,1)=-1;
    As(k+1,k,2)=1/6;
    As(k,k+1,2)=1/6;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat={As;As;As;c.*h};
M={As(:,:,2);As(:,:,2);As(:,:,2);h^3};

%step 1
Mu=Tucker3matvec2(M,u);
inprodu=u(:)'*Mu(:);
un=u;
a=sqrt(nele/inprodu);
un=un.*a;
Ecu=E(un,h,Amat,phi,M);
end
function out=E(u,h,Amat,phi,M,varargin)
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat,u);
out=lam/2.*u(:)'*t(:);
%second part of kinematic energy + Exc
fkxc=@(v) kxc(v);
fu=funv3(fkxc,u);
out=out+sum(fu,'all')*h^3;
%E-I interaction energy
u2=u.^2;
t=Tucker3matvec2(M,phi);
out=out+1/2*u2(:)'*t(:);
if ~isempty(varargin)
    bm=varargin{1};
    out=out+1/2*bm(:)'*phi(:);
end
end