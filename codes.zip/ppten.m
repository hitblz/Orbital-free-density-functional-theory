function out=ppten(Va,n2,n,h,tol,a)

f=@(x) a.*Va(a*x);
% I1=(((0:n2/2-1)).*h).^2;
I1=(((0:n2/2-1+n)).*h).^2;
t=f(sqrt(I1'+I1+permute(I1,[1 3 2])));
t=tensordecompose(15,t,tol,2);
t1=[t{1}(end:-1:2,:);t{1}];
out={t1;t1;t1;t{2}};
end