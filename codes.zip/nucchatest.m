function out=nucchatest(br,n2,h,tol)

I1=(((0:n2/2-1)+0.5).*h).^2;
t=br(sqrt(I1'+I1+permute(I1,[1 3 2])));
t=tensordecompose(15,t,tol,2);
t1=[t{1}(end:-1:1,:);t{1}];
out=tucker3product({sum(t1);t{2}.*h^3});
end