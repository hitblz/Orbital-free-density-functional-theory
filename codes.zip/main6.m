clear
add=[pwd '\atomcluster3\'];
t=load([add,'n5r6h4ep2n3osgsim.mat'],'Ra','vL0','h','n');
Ra=t.Ra;
vL0=t.vL0;
h=t.h;
n=t.n;

add2=[pwd '\atomcluster4\'];
fnames={'n10a9r6h4ep2n3osg.mat';
    'n10a8_5r6h4ep2n3osg.mat';
    'n10a8r6h4ep2n3osg.mat';
    'n10a7_5r6h4ep2n3osg.mat';
    'n10a7r6h4ep2n3osg.mat'};
nf=length(fnames);
Eacs=zeros(1,nf);
Eacrefs=zeros(1,nf);
tims=zeros(1,nf);
for k=1:nf
    tic;
    t=load([add2,fnames{k}],'r','nele','Amat','bL0','Vs','lambdas','M','Va','V0','lambda0','Amat1','Na','Eac');
    r=t.r;
    nele=t.nele;
    Amat=t.Amat;
    bL0=t.bL0;
    Vs=t.Vs;
    lambdas=t.lambdas;
    M=t.M;
    Va=t.Va;
    V0=t.V0;
    lambda0=t.lambda0;
    Amat1=t.Amat1;
    Na=t.Na;
    
    [E123,uL0,phiL0]=Ec3(r,Ra,vL0,nele,h,Amat,bL0,Vs,lambdas,M);
    [Ecn,bvs]=Eco(Va,n,r,h,Ra,V0,lambda0,Amat1);
    Eacs(k)=(E123-1/2*bvs(2)+Ecn)/Na*27.2114;
    Eacrefs(k)=t.Eac;
    tims(k)=toc;
end

function [Ecv,un,phi]=Ec3(r,Ra,v,nele,h,Amat,bm,V,lambdas,M)
u=assem6(1,v.^2,r,h,Ra);
u=sqrt(u);
%step 1
Mu=Tucker3matvec2(M,u);
inprodu=u(:)'*Mu(:);
a=sqrt(nele/inprodu);
un=u.*a;
%step 2
un2bm=Tucker3matvec2(M,un.^2)+bm;
phi=invIvec2(1/(4*pi),h,V,lambdas,un2bm);
Ecu=E(un,Amat,h,phi,M,bm);% a scalar
Ecv=Ecu;
end
function out=E(u,Amat,h,phi,M,bm)
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat,u);
out=lam/2.*u(:)'*t(:);
%second part of kinematic energy + Exc
fkxc=@(v) kxc(v);
fu=funv3(fkxc,u);
u2=u.^2;
out=out+sum(fu,'all')*h^3;
%E-I interaction energy
t=Tucker3matvec2(M,u2)+bm;
out=out+1/2*t(:)'*phi(:);
end