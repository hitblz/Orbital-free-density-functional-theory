function [ukadk,Eukadk,gukadk,phiukadk]=bisectionsig2(uk,dk,Euk,guk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,varargin)
% bisection line search algorithm with strong Wolfe condition

gkTdk=Tucker3inprod(1,guk,dk);
%searching for a 'crossing interval'
alpha_=0;%fixed
alpha=1;
epsilon=1e-4;
fpa_=gkTdk;
if fpa_>0
    pause
end
if isempty(varargin)
    [fpa,ukadk,Eukadk,gukadk,phiukadk]=fp(alpha,uk,dk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2);
else
    phi0=varargin{1};
    [fpa,ukadk,Eukadk,gukadk,phiukadk]=fp(alpha,uk,dk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phi0);
end
wcheckh=@(alpha,Eukadk,gukadk) Wolfecheck(dk,alpha,Eukadk,gukadk,Euk,gkTdk);
if wcheckh(alpha,Eukadk,gukadk)
    return
end
jmax=30;
flag=0;
for j=1:jmax
    if fpa>0
        flag=1;
        break
    else
        alpha_=alpha;
        alpha=2*alpha;
        fpa_=fpa;
        [fpa,ukadk,Eukadk,gukadk,phiukadk]=fp(alpha,uk,dk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phiukadk);
        if wcheckh(alpha,Eukadk,gukadk)
            return
        end
    end
end
lref=alpha-alpha_;
a=alpha_;
b=alpha;
fa=fpa_;
fb=fpa;
%secant search begin
if flag==1
    itmax=30;
    for j=1:itmax
        if (b-a)/lref<epsilon
            break
        end
        x=(a+b)/2;
        [fx,ukadk,Eukadk,gukadk,phiukadk]=fp(x,uk,dk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phiukadk);
        if wcheckh(x,Eukadk,gukadk)
            return
        end
        if fx>0
            x0=a-(a-x)*fa/(fa-fx);
            [fx0,ukadk,Eukadk,gukadk,phiukadk]=fp(x0,uk,dk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phiukadk);
            if wcheckh(x0,Eukadk,gukadk)
                return
            end
            if fx0>0
                b=x0;
                fb=fx0;
            else
                a=x0;
                b=x;
                fa=fx0;
                fb=fx;
            end
        else
            x0=b-(b-x)*fb/(fb-fx);
            [fx0,ukadk,Eukadk,gukadk,phiukadk]=fp(x0,uk,dk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phiukadk);
            if wcheckh(x0,Eukadk,gukadk)
                return
            end
            if fx0>0
                a=x;
                b=x0;
                fa=fx;
                fb=fx0;
            else
                a=x0;
                fa=fx0;
            end
        end
    end
    x=(a+b)/2;
    [~,ukadk,Eukadk,gukadk,phiukadk]=fp(x,uk,dk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phiukadk);
else
    error('failed to find a crossing interval in %i iterations\n',jmax);
end
end
function [val,varargout]=fp(a,uk,dk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,varargin)
adk=dk;
adk{4}=a*dk{4};
ukadk=Tucker3vecplus(uk,adk,tol);
if isempty(varargin)
    [Eukadk,gukadk,phiukadk]=EcgEcsig2(1,ukadk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2);
else
    phi0=varargin{1};
    [Eukadk,gukadk,phiukadk]=EcgEcsig2(1,ukadk,nele,h,Amat,bm,LmuN,imuN,tol,P,v1,v2,phi0);
end
val=Tucker3inprod(1,dk,gukadk);
varargout{1}=ukadk;
varargout{2}=Eukadk;
varargout{3}=gukadk;
varargout{4}=phiukadk;
end
function out=Wolfecheck(dk,alpha,Eukadk,gukadk,Euk,gkTdk)
sig1=0.2;
sig2=0.3;
gukadkTdk=Tucker3inprod(1,gukadk,dk);
out=(Eukadk<=Euk+sig1*alpha*gkTdk) && (abs(gukadkTdk)<=sig2*abs(gkTdk));
end