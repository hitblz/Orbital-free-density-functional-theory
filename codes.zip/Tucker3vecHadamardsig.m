function out=Tucker3vecHadamardsig(task,v1,v2,D,n2,tol)
%An ad-hoc program for Hadamard product of u and phi
%for Gaussian quadrature points
switch task
    case 1% for integration of energy function        
        h=D/n2;
        t=h/2*(1+[-1;1]*sqrt(1/3))+h*(0:n2-1);
        xall=t(:);
        vxallc=cell(3,2);
        for k=1:3
            sz=size(v1{4},k);
            vxallc{k,1}=interp1(0:h:D,[zeros(1,sz);v1{k};zeros(1,sz)],xall);
            sz=size(v2{4},k);
            vxallc{k,2}=interp1(0:h:D,[zeros(1,sz);v2{k};zeros(1,sz)],xall);
        end
        
        t=tucker3product(v1{4},vxallc{1,1},vxallc{2,1},vxallc{3,1});
        t2=tucker3product(v2{4},vxallc{1,2},vxallc{2,2},vxallc{3,2});
        t=t.*t.*t2;
        ns=length(xall);% a even number
        t=t(1:2:ns,:,:)+t(2:2:ns,:,:);
        t=t(:,1:2:ns,:)+t(:,2:2:ns,:);
        t=t(:,:,1:2:ns)+t(:,:,2:2:ns);
        outt=tensordecompose(7,t,tol,2);
        if ~isequal(outt,0)
            idsets=outt{5};
            out=cell(4,1);
            nxall=length(xall);
            for k=1:3
                dk=[k:3 1:k-1];
                s2=size(idsets{k,2},1);
                m=cell(1,s2);
                for k2=1:s2
                    tI=[2*idsets{k,2}(k2,1)-1 2*idsets{k,2}(k2,1)];
                    c=tencontract(vxallc{dk(2),1}(tI,:),2,2,permute(v1{4},dk),3,2);
                    tII=[2*idsets{k,2}(k2,2)-1 2*idsets{k,2}(k2,2)];
                    m{k2}=ipermute(tencontract(vxallc{dk(3),1}(tII,:),2,2,c,3,3),[3 2 1]);
                end
                t=tencontract(vxallc{dk(1),1},2,2,cell2mat(m),3,1);
                
                m=cell(1,s2);
                for k2=1:s2
                    tI=[2*idsets{k,2}(k2,1)-1 2*idsets{k,2}(k2,1)];
                    c=tencontract(vxallc{dk(2),2}(tI,:),2,2,permute(v2{4},dk),3,2);
                    tII=[2*idsets{k,2}(k2,2)-1 2*idsets{k,2}(k2,2)];
                    m{k2}=ipermute(tencontract(vxallc{dk(3),2}(tII,:),2,2,c,3,3),[3 2 1]);
                end
                t2=tencontract(vxallc{dk(1),2},2,2,cell2mat(m),3,1);
                t=t.*t.*t2;
                t=t(1:2:nxall,:,:)+t(2:2:nxall,:,:);
                t=t(:,1:2:2*s2,:)+t(:,2:2:2*s2,:);
                t=t(:,:,1)+t(:,:,2);
                out{k}=t/t(idsets{k,1},:);
            end
            out{4}=outt{4}.*(h/2)^3;
        end
        
    case 2% for the gradient of energy function
        h=D/n2;
        t=h/2*(1+[-1;1]*sqrt(1/3))+h*(0:n2-1);
        xall=t(:);
        vxallc=cell(3,2);
        for k=1:3
            sz=size(v1{4},k);
            vxallc{k,1}=interp1(0:h:D,[zeros(1,sz);v1{k};zeros(1,sz)],xall);
            sz=size(v2{4},k);
            vxallc{k,2}=interp1(0:h:D,[zeros(1,sz);v2{k};zeros(1,sz)],xall);
        end
        
        t=tucker3product(v1{4},vxallc{1,1},vxallc{2,1},vxallc{3,1});
        t2=tucker3product(v2{4},vxallc{1,2},vxallc{2,2},vxallc{3,2});
        t=t.*t2;
        loc1=1:n2-1;
        loc2=2:n2;
        t=(t(2*loc1-1,:,:)+t(2*loc2,:,:)).*(1-sqrt(1/3))/2+(t(2*loc1,:,:)+t(2*loc2-1,:,:)).*(1+sqrt(1/3))/2;
        t=(t(:,2*loc1-1,:)+t(:,2*loc2,:)).*(1-sqrt(1/3))/2+(t(:,2*loc1,:)+t(:,2*loc2-1,:)).*(1+sqrt(1/3))/2;
        t=(t(:,:,2*loc1-1)+t(:,:,2*loc2)).*(1-sqrt(1/3))/2+(t(:,:,2*loc1)+t(:,:,2*loc2-1)).*(1+sqrt(1/3))/2;
        outt=tensordecompose(7,t,tol,2);
        if ~isequal(outt,0)
            idsets=outt{5};
            out=cell(4,1);
            nxall=length(xall);
            for k=1:3
                dk=[k:3 1:k-1];
                
                s2=size(idsets{k,2},1);
                m=cell(1,s2);
                for k2=1:s2
                    tI=2*idsets{k,2}(k2,1)+(-1:2);
                    c=tencontract(vxallc{dk(2),1}(tI,:),2,2,permute(v1{4},dk),3,2);                    
                    tII=2*idsets{k,2}(k2,2)+(-1:2);
                    m{k2}=ipermute(tencontract(vxallc{dk(3),1}(tII,:),2,2,c,3,3),[3 2 1]);
                end
                t=tencontract(vxallc{dk(1),1},2,2,cell2mat(m),3,1);
                m=cell(1,s2);
                for k2=1:s2
                    tI=2*idsets{k,2}(k2,1)+(-1:2);
                    c=tencontract(vxallc{dk(2),2}(tI,:),2,2,permute(v2{4},dk),3,2);
                    tII=2*idsets{k,2}(k2,2)+(-1:2);
                    m{k2}=ipermute(tencontract(vxallc{dk(3),2}(tII,:),2,2,c,3,3),[3 2 1]);
                end
                t2=tencontract(vxallc{dk(1),2},2,2,cell2mat(m),3,1);
                t=t.*t2;
                
                t=(t(1:2:nxall-2,:,:)+t(4:2:nxall,:,:)).*(1-sqrt(1/3))/2+(t(2:2:nxall-2,:,:)+t(3:2:nxall,:,:)).*(1+sqrt(1/3))/2;
                t=(t(:,1:4:4*s2,:)+t(:,4:4:4*s2,:)).*(1-sqrt(1/3))/2+(t(:,2:4:4*s2,:)+t(:,3:4:4*s2,:)).*(1+sqrt(1/3))/2;
                t=(t(:,:,1)+t(:,:,4)).*(1-sqrt(1/3))/2+(t(:,:,2)+t(:,:,3)).*(1+sqrt(1/3))/2;
                out{k}=t/t(idsets{k,1},:);
            end
            out{4}=outt{4}.*(h/2)^3;
        end
        
end
end