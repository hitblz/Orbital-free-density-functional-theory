function out=ISEten(task,ten,idsets,scanlist,k,tol)
% An ad-hoc program for tensor train decomposition
% 'task' obeys from 'tensordecompose.m'

switch task%1 3
    case 1% of a fourth-order tensor
        sz=size(ten);
        if scanlist(k)==1
            for kk=1
                nIk1=size(idsets{2,1},1);
                nIk=size(idsets{1,1},1);
                f1=reshape(cell2mat(arrayfun(@(c) ten(:,:,idsets{2,2}(c,1),idsets{2,2}(c,2)),1:nIk1,'UniformOutput',false)),[sz([1 2]) nIk1]);
                M1=cell2mat(arrayfun(@(c) ten(:,idsets{1,2}(c,1),idsets{1,2}(c,2),idsets{1,2}(c,3)),1:nIk,'UniformOutput',false));
                Amid=M1(idsets{1,1},:);
                M1=M1/Amid;
                M2=f1(idsets{1,1},:,:);
                f2=tencontract(M1,2,2,M2,3,1);
                valdoetemp=f1-f2;
                [errmax,id]=max(abs(valdoetemp(:)));
                errmax=errmax/max(abs(f1(:)));
                if errmax<=tol
                    fprintf('Dimension (%i, %i) converged at rank %i.\n',scanlist(k),scanlist(k)+1,size(idsets{scanlist(k),1},1));
                    break
                end
                [id1,id2,id3]=ind2sub([sz(1),sz(2),nIk1],id);
                idsetsL=union(idsets{1,1},id1,'rows');
                idsetsR=union(idsets{1,2},[id2,idsets{2,2}(id3,:)],'rows');
                if size(idsetsL,1)~=size(idsetsR,1)
                    flag=1;
                    break
                end
                idsets{1,1}=[idsets{1,1};id1];
                idsets{1,2}=[idsets{1,2};[id2,idsets{2,2}(id3,:)]];
            end
        else%scanlist(k)==2
            for kk=1
                nIk_1=size(idsets{1,1},1);
                nIk=size(idsets{2,1},1);
                f1=ten(idsets{1,1},:,:,:);
                M1=reshape(cell2mat(arrayfun(@(c) f1(:,:,idsets{2,2}(c,1),idsets{2,2}(c,2)),1:nIk,'UniformOutput',false)),[nIk_1 sz(2) nIk]);
                ss=[kron(ones(nIk,1),idsets{2,1}),kron(idsets{2,2},ones(nIk,1))];
                id=sub2ind(sz,ss(:,1),ss(:,2),ss(:,3),ss(:,4));
                Amid=reshape(ten(id),[nIk,nIk]);
                M1=tencontract(M1,3,3,Amid,2,1,'inv');
                M2=cell2mat(arrayfun(@(r) permute(ten(idsets{2,1}(r,1),idsets{2,1}(r,2),:,:),[1 3 4 2]),(1:nIk)','UniformOutput',false));
                f2=tencontract(M1,3,3,M2,3,1);
                valdoetemp=f1-f2;
                [errmax,id]=max(abs(valdoetemp(:)));
                errmax=errmax/max(abs(f1(:)));
                if errmax<=tol
                    fprintf('Dimension (%i, %i) converged at rank %i.\n',scanlist(k),scanlist(k)+1,size(idsets{scanlist(k),1},1));
                    break
                end
                [id1,id2,id3,id4]=ind2sub([nIk_1 sz([2 3 4])],id);
                idsetsL=union(idsets{2,1},[idsets{1,1}(id1,:),id2],'rows');
                idsetsR=union(idsets{2,2},[id3,id4],'rows');
                if size(idsetsL,1)~=size(idsetsR,1)
                    flag=1;
                    break
                end
                idsets{2,1}=[idsets{2,1};[idsets{1,1}(id1,:),id2]];
                idsets{2,2}=[idsets{2,2};[id3,id4]];
            end
        end
        
    case 3%of a third-order tensor
        sz=size(ten);
        if scanlist(k)==1
            for kk=1
                nIk1=size(idsets{2,1},1);
                nIk=size(idsets{1,1},1);
                f1=reshape(cell2mat(arrayfun(@(c) ten(:,:,idsets{2,2}(c,1)),1:nIk1,'UniformOutput',false)),[sz([1 2]) nIk1]);
                M1=cell2mat(arrayfun(@(c) ten(:,idsets{1,2}(c,1),idsets{1,2}(c,2)),1:nIk,'UniformOutput',false));
                Amid=M1(idsets{1,1},:);
                M1=M1/Amid;
                M2=f1(idsets{1,1},:,:);
                f2=tencontract(M1,2,2,M2,3,1);
                valdoetemp=f1-f2;
                [errmax,id]=max(abs(valdoetemp(:)));
                errmax=errmax/max(abs(f1(:)));
                if errmax<=tol
                    fprintf('Dimension (%i, %i) converged at rank %i.\n',scanlist(k),scanlist(k)+1,size(idsets{scanlist(k),1},1));
                    break
                end
                [id1,id2,id3]=ind2sub([sz(1),sz(2),nIk1],id);
                idsetsL=union(idsets{1,1},id1,'rows');
                idsetsR=union(idsets{1,2},[id2,idsets{2,2}(id3,:)],'rows');
                if size(idsetsL,1)~=size(idsetsR,1)
                    flag=1;
                    break
                end
                idsets{1,1}=[idsets{1,1};id1];
                idsets{1,2}=[idsets{1,2};[id2,idsets{2,2}(id3,:)]];
            end
        else%scanlist(k)==2
            for kk=1
                nIk_1=size(idsets{1,1},1);
                nIk=size(idsets{2,1},1);
                f1=ten(idsets{1,1},:,:);
                M1=reshape(cell2mat(arrayfun(@(c) f1(:,:,idsets{2,2}(c,1)),1:nIk,'UniformOutput',false)),[nIk_1 sz(2) nIk]);
                M2=cell2mat(arrayfun(@(r) permute(ten(idsets{2,1}(r,1),idsets{2,1}(r,2),:),[1 3 2]),(1:nIk)','UniformOutput',false));
                Amid=M2(:,idsets{2,2});
                M1=tencontract(M1,3,3,Amid,2,1,'inv');
                f2=tencontract(M1,3,3,M2,2,1);
                valdoetemp=f1-f2;
                [errmax,id]=max(abs(valdoetemp(:)));
                errmax=errmax/max(abs(f1(:)));
                if errmax<=tol
                    fprintf('Dimension (%i, %i) converged at rank %i.\n',scanlist(k),scanlist(k)+1,size(idsets{scanlist(k),1},1));
                    break
                end
                [id1,id2,id3]=ind2sub([nIk_1 sz([2 3])],id);
                idsetsL=union(idsets{2,1},[idsets{1,1}(id1,:),id2],'rows');
                idsetsR=union(idsets{2,2},id3,'rows');
                if size(idsetsL,1)~=size(idsetsR,1)
                    flag=1;
                    break
                end
                idsets{2,1}=[idsets{2,1};[idsets{1,1}(id1,:),id2]];
                idsets{2,2}=[idsets{2,2};id3];
            end
        end
        
    case 7
        pm=[scanlist(k):3 1:scanlist(k)-1];
        ten=permute(ten,pm);
        sz=[size(ten,1) size(ten,2) size(ten,3)];
        for kk=1
            I1=setdiff(1:sz(1),idsets{scanlist(k),1});
            I2=setdiff(1:sz(2)*sz(3),sub2indv2(sz(2:3),idsets{scanlist(k),2}));
            Ik_=idsets{scanlist(k),1};
            Ik=sub2indv2(sz(2:3),idsets{scanlist(k),2});
            ten1=reshape(ten,[sz(1) prod(sz(2:3))]);
            M1=ten1(:,Ik);
            Amid=M1(Ik_,:);
            M1=M1(I1,:)/Amid;
            M2=ten1(Ik_,I2);
            valdoetemp=ten1(I1,I2)-M1*M2;
            [errmax,id]=max(abs(valdoetemp(:)));
            errmax=errmax/max(abs(ten(:)));
            if isempty(errmax)
                errmax=0;
            end
            if errmax<=tol
                fprintf('Dimension (%i, (%i,%i)) converged at rank %i.\n',pm(1),pm(2),pm(3),size(idsets{scanlist(k),1},1));
                break
            end
            [id1,idII]=ind2sub([length(I1),length(I2)],id);
            [id2,id3]=ind2sub(sz(2:3),I2(idII));
            idsets{scanlist(k),1}=[idsets{scanlist(k),1};I1(id1)];
            idsets{scanlist(k),2}=[idsets{scanlist(k),2};[id2,id3]];
        end
        
end
out={idsets errmax};
end