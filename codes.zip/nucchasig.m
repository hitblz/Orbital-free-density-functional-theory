function out=nucchasig(task,br,n2,h,tol,a)
%a>=1
f=@(x) a^3*br(a*x);
switch task
    case 1
        I1=(((0:n2/2-1)+0.5).*h).^2;
        t=f(sqrt(I1'+I1+permute(I1,[1 3 2])));
        t=tensordecompose(15,t,tol,2);
        t1=[t{1}(end:-1:1,:);t{1}];
        L=length(t1);
        t1=t1(1:L-1,:)+t1(2:L,:);
        out={t1;t1;t1;t{2}.*(h/2)^3};
    case 2
        I1=((0:n2/2-1).*h).^2;
        t=f(sqrt(I1'+I1+permute(I1,[1 3 2])));
        t=tensordecompose(15,t,tol,2);
        t1=[t{1}(end:-1:2,:);t{1}];
        out={t1;t1;t1;t{2}};
end
end