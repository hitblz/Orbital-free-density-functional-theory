%from main2, higher-order finite difference method
clear
tic;
add=[pwd '\singleatom3\'];
fl='r6h5ep2n3o.mat';
%% V-multigrid
epsilon=5e-4;
t=load([add fl],'Ra','nele','h','Vsig','uL0','bm','N','Va');
Ra=t.Ra;
Va=t.Va;
nelea=t.nele;
h=t.h;
Vsig=t.Vsig;
uL0sig=normalize(t.uL0,nelea,h);
bmsig=t.bm;bmsig=bmsig{1};
Nsig=t.N;
% F=[0,0.2,0;0,0,0;0,0,0];  
a0=8;
ncell=[1 1 1]*1;
r0list=r0cgen(ncell)*a0;
r0=r0list';
% r0=[1/2,1/2,1/2;-1/2,1/2,1/2;-1/2,-1/2,1/2;1/2,-1/2,1/2;1/2,1/2,-1/2;-1/2,1/2,-1/2;-1/2,-1/2,-1/2;1/2,-1/2,-1/2;...
%     0,0,1/2;0,0,-1/2;1/2,0,0;-1/2,0,0;0,1/2,0;0,-1/2,0]'*a0;
% r0=[0,0,0;1/2,0,1/2;1/2,0,-1/2;-1/2,0,1/2;-1/2,0,-1/2;1/2,1/2,0;1/2,-1/2,0;-1/2,1/2,0;-1/2,-1/2,0;0,1/2,1/2;0,-1/2,1/2;0,1/2,-1/2;0,-1/2,-1/2]'*a0;
%r=(eye(3)+F)*r0;
r=r0;

%%
Na=size(r0list,1);%number of atoms
nele=Na*nelea;

n=3;
wp=zeros(1,n+1);
for p=0:n
    if p==0
        wp(p+1)=2*sum((1:n).^(-2));
    else
        wp(p+1)=2*(-1)^p/p^2*factorial(n)^2/(factorial(n-p)*factorial(n+p));
    end
end
% wp=[34 -16 -1]./20;
% n=2;
xwp=[wp(n+1:-1:2) wp];
wp2=[1 0];
xwp2=[wp2(2) wp2];
xwp2=xwp2./sum(xwp2);

As1=zeros(Nsig+3+2*n,Nsig+3+2*n,2);
for k=1:Nsig+3+2*n
    a1=n+2-min(k,n+1);
    b1=max(1,k-n);
    lb=Nsig+3+2*n-(b1-1);
    la=2*n+1-(a1-1);
    ly=min(la,lb);
    a2=a1-1+ly;
    b2=b1-1+ly;
    As1(k,b1:b2,1)=xwp(a1:a2);
    
    c1=1+2-min(k,1+1);
    d1=max(1,k-1);
    ld=Nsig+3+2*n-(d1-1);
    lc=2*1+1-(c1-1);
    lz=min(lc,ld);
    c2=c1-1+lz;
    d2=d1-1+lz;
    As1(k,d1:d2,2)=xwp2(c1:c2);
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat1={As1;As1;As1;c.*h};

rhoi=assem5(1,uL0sig.^2,r,h,Ra);
uL0i=sqrt(rhoi);
uL0=uL0i;
% bL0=assem5(0,bmsig,r,h,Ra);
bL0=assemb(Va,n,r,h,Ra,Amat1);


szu=size(uL0);
%pre-computing prolongation and restriction operator
P=cell(4,2);%prolongation
R=cell(4,2);%restriction
for i=1:2
    szut=(szu+1)/2^i-1;
    for k=1:3
        P{k,i}=zeros(2*szut(k)+1,szut(k));
        for k2=1:szut(k)
            P{k,i}(2*k2-1:2*k2+1,k2)=[0.5;1;0.5];
        end
        R{k,i}=P{k,i}'./2;
    end
    P{4,i}=1;
    R{4,i}=1;
end

Amat=cell(3,4);
M=cell(3,4);
Vs=cell(3,3);
lambdas=cell(3,3);
for level=1:3
    for i=1:3%dimension
        N=(size(uL0,i)+1)/2^(level-1)-1;
        As=zeros(N,N,2);
        for k=1:N
            a1=n+2-min(k,n+1);
            b1=max(1,k-n);
            lb=N-(b1-1);
            la=2*n+1-(a1-1);
            ly=min(la,lb);
            a2=a1-1+ly;
            b2=b1-1+ly;
            As(k,b1:b2,1)=xwp(a1:a2);
            
            c1=1+2-min(k,1+1);
            d1=max(1,k-1);
            ld=N-(d1-1);
            lc=2*1+1-(c1-1);
            lz=min(lc,ld);
            c2=c1-1+lz;
            d2=d1-1+lz;
            As(k,d1:d2,2)=xwp2(c1:c2);
        end
        Amat{level,i}=As;
        M{level,i}=As(:,:,2);
        [V,lambdaN]=eig(As(:,:,1),As(:,:,2));lambdaN=diag(lambdaN);
        Vs{level,i}=V;lambdas{level,i}=lambdaN;
    end
    c=zeros(2,2,2);
    c(1,2,2)=1;
    c(2,1,2)=1;
    c(2,2,1)=1;
    Amat{level,4}=c.*(2^(level-1)*h);
    M{level,4}=(2^(level-1)*h)^3;
end
%[EuL0i,guL0i,phiL0i]=EcgEc(1,uL0i,nele,h,Amat,bL0,LmuN,imuN,M,0,0,0);%对后续计算没有实际用途，仅作为参照。
flg=[0 0 0];
for it=1:50
    for level=0:2
        switch level
            case 0
                [uL0,EuL0,guL0,phiL0,flag,flg(1),nit,epsa]=VM5(it,epsilon,uL0,nele,h,Amat(1,:),M(1,:),Vs(1,:),lambdas(1,:),bL0,P,R,0,0);
                if flag==1
                    break
                end
            case 1
                uL1i=Tucker3matvec2(R(:,1)',uL0);
                bL1=Tucker3matvec2({P{1,1}',P{2,1}',P{3,1}',1},bL0);
                [uL1,EuL1,guL1,phiL1,flag,flg(2),v1]=VM5(it,epsilon,uL1i,nele,h,Amat(2,:),M(2,:),Vs(2,:),lambdas(2,:),bL1,P,R,guL0,0);
            case 2
                uL2i=Tucker3matvec2(R(:,2)',uL1);
                bL2=Tucker3matvec2({P{1,2}',P{2,2}',P{3,2}',1},bL1);
                [uL2,EuL2,guL2,phiL2,flag,flg(3)]=VM5(it,epsilon,uL2i,nele,h,Amat(3,:),M(3,:),Vs(3,:),lambdas(3,:),bL2,P,R,guL0,guL1,v1);
        end
    end
    if flag==1
        break
    end
    e=Tucker3matvec2(P(:,2)',uL2-uL2i);
    [uL1,EuL1,guL1,phiL1,flg1]=bisection2(uL1,e,EuL1,guL1,phiL1,nele,h,Amat(2,:),bL1,Vs(2,:),lambdas(2,:),M(2,:),P,v1,0);
    e=Tucker3matvec2(P(:,1)',uL1-uL1i);
    [uL0,EuL0,guL0,phiL0,flg0]=bisection2(uL0,e,EuL0,guL0,phiL0,nele,h,Amat(1,:),bL0,Vs(1,:),lambdas(1,:),M(1,:),P,0,0);
end
close all
% uL0=normalize(uL0,nele,h);
% rho=uL0.^2;
% [rhoa,itv]=assem2(uL0sig.^2,r,h);
% wa=rhoa./rhoi;
% rhoext=wa.*rho;
% rhoext=rhoext(itv(1,1):itv(1,2),itv(2,1):itv(2,2),itv(3,1):itv(3,2));
% rhore=assem1(rhoext,r,h);
% uL0re=sqrt(rhore);
% uL0re=normalize(uL0re,nele,h);
% [EuL0re,guL0re,phiL0re]=EcgEc(1,uL0re,nele,h,Amat,bL0,LmuN,imuN,M,0,0,0);

Mu=Tucker3matvec2(M(1,:),uL0);
inprodu=uL0(:)'*Mu(:);
a=sqrt(nele/inprodu);
uL0=uL0.*a;
%%
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat(1,:),uL0);
E1=lam/2.*uL0(:)'*t(:);
%second part of kinematic energy + Exc
fu=kxc(uL0);
u2=uL0.^2;
E2=sum(fu,'all')*h^3;
%E-I interaction energy
t=Tucker3matvec2(M(1,:),u2)+bL0;
E3=1/2*t(:)'*phiL0(:);
% E4=-1/2*Na*bmsig(:)'*Vsig{1}(:);
% E0=E1+E2+E3+E4;
% E0ev=E0/Na*27.2114;
Ass=zeros(Nsig+1,Nsig+1,2);
for k=1:Nsig+1
    a1=n+2-min(k,n+1);
    b1=max(1,k-n);
    lb=Nsig+1-(b1-1);
    la=2*n+1-(a1-1);
    ly=min(la,lb);
    a2=a1-1+ly;
    b2=b1-1+ly;
    Ass(k,b1:b2,1)=xwp(a1:a2);
end
for k=1:Nsig+1
    Ass(k,k,2)=1;
end
[V0,lambda0]=eig(Ass(:,:,1),Ass(:,:,2),'vector');
[Ecn,bvs]=Eco(Va,n,r,h,Ra,V0,lambda0,Amat1);
Eac=(E1+E2+E3-1/2*bvs(2)+Ecn)/Na*27.2114;

tim=toc;
add2=[pwd '\atomcluster4\'];
save([add2, 'n1a8r6h5ep2n3o.mat'],'-v7.3');