function out=r0cgen(ncell)
%FCC
[i1,i2,i3]=ind2sub(ncell+1,(1:prod(ncell+1))');
out=[i1,i2,i3]-1;
[j1,j2,j3]=ind2sub([ncell(1) ncell(2) ncell(3)+1],(1:prod([ncell(1) ncell(2) ncell(3)+1]))');
out=[out;[j1-1/2,j2-1/2,j3-1]];
[j1,j2,j3]=ind2sub([ncell(1) ncell(2)+1 ncell(3)],(1:prod([ncell(1) ncell(2)+1 ncell(3)]))');
out=[out;[j1-1/2,j2-1,j3-1/2]];
[j1,j2,j3]=ind2sub([ncell(1)+1 ncell(2) ncell(3)],(1:prod([ncell(1)+1 ncell(2) ncell(3)]))');
out=[out;[j1-1,j2-1/2,j3-1/2]];
end