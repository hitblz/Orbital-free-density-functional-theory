function t=cutedge(a,n)
if isnumeric(a)
    a=a((n+1)+1:end-(n+1),(n+1)+1:end-(n+1),(n+1)+1:end-(n+1));
else%cell
    for k=1:3
        a{k}=a{k}((n+1)+1:end-(n+1),(n+1)+1:end-(n+1),(n+1)+1:end-(n+1));
    end
end
t=a;
end