function gEcu=gEc2(u,nele,h,Amat,bm,V,lambdaN,M,P,v1)
% an analogue of gEc
%h, Amat, bm, LmuN, imuN are quantities at the finest level (level 0)
% u is defined at the finest level (level 0)
if isequal(P,0)
    %step 1
    Mu=Tucker3matvec2(M,u);
    inprodu=u(:)'*Mu(:);
    un=u;
    a=sqrt(nele/inprodu);
    un=un.*a;
    %step 2
    un2bm=Tucker3matvec2(M,un.^2)+bm;
    phi=invIvec2(1/(4*pi),h,V,lambdaN,un2bm);
    %step 3
    gEun=gE(un,Amat,phi,M);
    lambda=-un(:)'*gEun(:)/nele;
    cMJun=lambda.*Mu.*a;
    gEcu=(gEun+cMJun).*a;% a vector
    
elseif isequal(v1,0)
    gEcu=gEc2(u,nele,h,Amat,bm,V,lambdaN,M,0,0);

else
%     f=(size(P{1,2},1)/size(P{1,2},2))*(size(P{2,2},1)/size(P{2,2},2))*(size(P{3,2},1)/size(P{3,2},2));
    v12=Tucker3matvec2({P{1,2}',P{2,2}',P{3,2}',1},v1);
    gEcu=gEc2(u,nele,h,Amat,bm,V,lambdaN,M,0,0)-v12;
    
end
end
function out=gE(u,Amat,phi,M)
%gradient of total energy with fixed phik
%first update
lam=2/10;
out=Tucker3matvec2(Amat,u).*lam;
%second update
fgkxc=@(v) gkxc(v);
pfu=funv3(fgkxc,u,M);
out=out+pfu;
%third update
uphi=2*u.*phi;
out=out+Tucker3matvec2(M,uphi);
end