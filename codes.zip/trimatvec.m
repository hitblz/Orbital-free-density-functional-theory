function out=trimatvec(mat,vec)
%tridiagonal matrix-vector product
N=size(vec,1);
alpha=size(mat,2);
beta=size(vec,2);
vec=permute(vec,[1 3 2]);%size(vec,2)=1
out=[zeros(1,alpha,beta);mat(N+1:2*N-1,:).*vec(1:N-1,:,:)]+mat(1:N,:).*vec+[mat(2*N:3*N-2,:).*vec(2:N,:,:);zeros(1,alpha,beta)];
end