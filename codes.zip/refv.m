function [out1,varargout]=refv(v,a,h,ncell,tol)
%v is a full array
%FCC
vt=tensordecompose(15,v,tol,2);
n=round(a/h);
n=n+mod(n,2);
aa=n*h;%actual lattice constant
s=size(vt{1});
vs1=zeros(ncell*n+s(1),s(2));
i1=zeros(2,ncell+1);
for i=0:ncell
    %     vs1=vs1+[interp1([0;i*n+1],[zeros(1,s(2));vt{1}(1,:)],(1:i*n)');vt{1};interp1([i*n+s(1);ncell*n+s(1)+1]',[vt{1}(end,:);zeros(1,s(2))],(i*n+s(1)+1:ncell*n+s(1))')];
    %     vs1=vs1+[interp1([0;i*n+1],[vt{1}(1,:);vt{1}(1,:)],(1:i*n)');vt{1};interp1([i*n+s(1);ncell*n+s(1)+1]',[vt{1}(end,:);vt{1}(end,:)],(i*n+s(1)+1:ncell*n+s(1))')];
    vs1(i*n+1:i*n+s(1),:)=vs1(i*n+1:i*n+s(1),:)+vt{1};
    i1(:,i+1)=[0;s(1)+1]+i*n;
end
vs2=zeros(ncell*n+s(1),s(2));
i2=zeros(2,ncell);
for i=1:ncell
    %     vs2=vs2+[interp1([0;(i-1/2)*n+1]',[vt{1}(1,:);vt{1}(1,:)],(1:(i-1/2)*n)');vt{1};interp1([(i-1/2)*n+s(1);ncell*n+s(1)+1]',[vt{1}(end,:);vt{1}(end,:)],((i-1/2)*n+s(1)+1:ncell*n+s(1))')];
    vs2((i-1/2)*n+1:(i-1/2)*n+s(1),:)=vs2((i-1/2)*n+1:(i-1/2)*n+s(1),:)+vt{1};
    i2(:,i)=[0;s(1)+1]+(i-1/2)*n;
end
vs=[vs1 vs2];
c=cell(2,2,2);
c{1,1,1}=vt{2};
c{1,2,2}=vt{2};
c{2,1,2}=vt{2};
c{2,2,1}=vt{2};
s=[size(vt{2},1) size(vt{2},2) size(vt{2},3)];
c{1,1,2}=zeros(s(1),s(2),s(3));
c{1,2,1}=zeros(s(1),s(2),s(3));
c{2,1,1}=zeros(s(1),s(2),s(3));
c{2,2,2}=zeros(s(1),s(2),s(3));
tol2=1e-10;
vs=tensordecompose(6,vs,tol2,2);
c=tucker3product(cell2mat(c),vs{2},vs{2},vs{2});
tt=tensordecompose(15,c,tol,2);
vs{1}=vs{1}*tt{1};
out1={vs{1};vs{1};vs{1};tt{2}};
if nargout>1
    varargout{1}=aa;
    I=sort(unique([i1(:);i2(:)]));
    I(1)=[];
    I(end)=[];
    varargout{2}=I;
end
end