t=load([pwd '\atomcluster2\a6h0ep2n1.mat'],'E0ev');
E0evref=t.E0ev;
%%
Eevm=zeros(5,3);
Ras=zeros(5,1);
for nh=1:5
    t=load([pwd '\atomcluster2\a6h' num2str(nh) 'ep2n2ao2.mat'],'E0ev','h');
    Eevm(nh,1)=t.E0ev;
    Ras(nh)=t.h;
    t=load([pwd '\atomcluster2\a6h' num2str(nh) 'ep2n2ao2sim.mat'],'E0ev');
    Eevm(nh,2)=t.E0ev;
    t=load([pwd '\atomcluster2\a6h' num2str(nh) 'ep2n2ao2simsg.mat'],'E0ev');
    Eevm(nh,3)=t.E0ev;
end
figure;
plot(Ras,(E0evref-Eevm(:,1))./E0evref,'-x');hold on
plot(Ras,(E0evref-Eevm(:,2))./E0evref,'-o');hold on
plot(Ras,(E0evref-Eevm(:,3))./E0evref,'-*');hold on
xlabel('\it h_{\rm [0]}/\rm Bohr');
ylabel('\it \epsilon_{\rm E,r}');
legend('MG','sMG','sSG','Location','southwest');
set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
set(gcf,'color','w');
set(gcf,'Units','centimeters');
set(gcf,'Position',[1.5 1.5 12 10]);
set(gcf,'PaperUnits','centimeters');
saveas(gcf,'2_ex6.fig');
export_fig(gcf, [pwd '\2_ex6.pdf'], '-r2000', '-transparent');
%%
nitm=zeros(5,3);
Ras=zeros(5,1);
for nh=1:5
    t=load([pwd '\atomcluster2\a6h' num2str(nh) 'ep2n2ao2sim.mat'],'h','it','nit','tim');
    Ras(nh)=t.h;
    nitm(nh,1)=t.nit;
    nitm(nh,2)=t.it;
    nitm(nh,3)=t.tim;
end
% figure;
% plot(Ras,nitm(:,1),'-o');hold on
% plot(Ras,nitm(:,2),'-x');hold on
% plot(Ras,nitm(:,3),'-*');hold on
% xlabel('\it h_{\rm [0]}/\rm Bohr');
% ylabel('\it n_{\rm it}');
% legend('\it n_{\rm 2,0}','\it n_{\rm 2,t}', '\it n_{\rm 0}','Location','northeast');
% set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
% set(gcf,'color','w');
% set(gcf,'Units','centimeters');
% set(gcf,'Position',[1.5 1.5 12 10]);
% set(gcf,'PaperUnits','centimeters');
% saveas(gcf,'2_ex6.fig');
% export_fig(gcf, [pwd '\2_ex6.pdf'], '-r2000', '-transparent');
%%
timm=zeros(5,2);
Ras=zeros(5,1);
for nh=1:5
    t=load([pwd '\atomcluster2\a6h' num2str(nh) 'ep2n2ao2simsg.mat'],'h','nit','tim');
    Ras(nh)=t.h;
    timm(nh,1)=t.nit;
    timm(nh,2)=t.tim;
end
% figure;
% plot(Ras,timm(:,1),'-o');hold on
% plot(Ras,timm(:,2),'-x');hold on
% xlabel('\it h_{\rm [0]}/\rm Bohr');
% ylabel('\it t/s');
% % set(gca,'YScale','log');
% legend('MG','SG','Location','northeast');
% set(gca,'FontName', 'Times New Roman', 'Fontsize', 14,'SortMethod','childorder');
% set(gcf,'color','w');
% set(gcf,'Units','centimeters');
% set(gcf,'Position',[1.5 1.5 12 10]);
% set(gcf,'PaperUnits','centimeters');
% saveas(gcf,'2_ex7.fig');
% export_fig(gcf, [pwd '\2_ex7.pdf'], '-r2000', '-transparent');