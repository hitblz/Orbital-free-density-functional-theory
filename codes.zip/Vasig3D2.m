function out=Vasig3D2(Va,n,h,Ra,coor)
na=floor(Ra/h);
grid1=-coor(1)-(na+n)*h:h:h-coor(1)+(na+n)*h;
grid2=-coor(2)-(na+n)*h:h:h-coor(2)+(na+n)*h;
grid3=-coor(3)-(na+n)*h:h:h-coor(3)+(na+n)*h;
grid1=grid1';
grid3=permute(grid3,[1 3 2]);
out=Va(sqrt(grid1.^2+grid2.^2+grid3.^2));
% out=out((n+1)+1:end-(n+1),(n+1)+1:end-(n+1),(n+1)+1:end-(n+1));
end