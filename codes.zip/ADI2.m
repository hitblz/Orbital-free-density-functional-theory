function out=ADI2(lambda,f,tol,eADI,varargin)
% Alternating Direction Implicit method
%an updated version of ADI.m
maxit=1000;
mu=0.3312;
nu=1.778;
lambda1=min(cell2mat(lambda(:)));
lambdaN=max(cell2mat(lambda(:)));
N=[length(lambda{1}) length(lambda{2}) length(lambda{3})];
Ni=ceil(1+log(lambdaN/lambda1)/log(nu/mu));
if isempty(varargin)
    uk=f;
else
    uk=varargin{1};%prescribed initial value
end
normf=sqrt(Tucker3inprod(1,uk,uk));
T=cell(4,1);
T{4}=zeros(2,2,2);
T{4}(1,1,1)=6;
T{4}(2,2,2)=1;
T{4}(1,1,2)=-2;
T{4}(1,2,1)=-2;
T{4}(2,1,1)=-2;
T_=T{4};
T_(2,2,2)=0;
R=cell(1,3);
for k=0:maxit
    j=mod(k,Ni);
    sigk=1./mu*(nu/mu)^j*lambda1;
    for k2=1:3
        R{k2}=(lambda{k2}./sigk+ones(N(k2),1)).^(-1);
        T{k2}=[R{k2},ones(N(k2),1)];
    end
    uk1=Tucker3vecHadamard({T{1};T{2};T{3};T{4}},uk,tol);
    ek=Tucker3vecHadamard({T{1};T{2};T{3};T_},uk,tol);
    Bkf=f;
    Bkf{1}=R{1}.*Bkf{1};
    Bkf{2}=R{2}.*Bkf{2};
    Bkf{3}=R{3}.*Bkf{3};
    Bkf{4}=2/sigk.*Bkf{4};
    uk1=Tucker3vecplus(uk1,Bkf,tol);
    ek=Tucker3vecplus(ek,Bkf,tol);
    rnormek=sqrt(Tucker3inprod(1,ek,ek))/normf;
    if rnormek<eADI
        s=[size(uk1{1},2),size(uk1{2},2),size(uk1{3},2)];
        fprintf('ADI iteration converged at iteration %i with rank (%i, %i, %i) and relative residual %10.4e.\n',k,s(1),s(2),s(3),rnormek)
        break
    end
    uk=uk1;
end
out=uk1;
end