function phi=invIvecsig2(alpha,h,LmuN,imuN,f)
%direct solution
%linear equation corresponding to 1/2*alpha*\int \nabla v .*\nabla v dx
methodDST=1;
%discrete sine transform
phi=fDST2(f,methodDST);
phi=phi.*(imuN.*imuN'.*permute(imuN,[2 3 1]));
phi=phi./(alpha*h);
%step2
I=LmuN;
I(:)=1;
t=LmuN.*I'.*permute(I,[2 3 1]);
phi=((t+permute(t,[2 1 3])+permute(t,[3 2 1])).^(-1)).*phi;
%discrete inverse sine transform
phi=fDST2(phi,methodDST);
end