function [bisig,varargout]=bisig3D(n,h,Ra,coor,varargin)
na=floor(Ra/h);
grid1=-coor(1)-(na+n)*h:h:h-coor(1)+(na+n)*h;
grid2=-coor(2)-(na+n)*h:h:h-coor(2)+(na+n)*h;
grid3=-coor(3)-(na+n)*h:h:h-coor(3)+(na+n)*h;
n1=length(grid1);
n2=length(grid2);
n3=length(grid3);
bisig=zeros(n1,n2,n3);
m1=na+n+1;
m2=m1+1;
bisig(m1,m1,m1)=(1-coor(1)/h)*(1-coor(2)/h)*(1-coor(3)/h);
bisig(m1,m1,m2)=(1-coor(1)/h)*(1-coor(2)/h)*(coor(3)/h);
bisig(m1,m2,m1)=(1-coor(1)/h)*(coor(2)/h)*(1-coor(3)/h);
bisig(m1,m2,m2)=(1-coor(1)/h)*(coor(2)/h)*(coor(3)/h);
bisig(m2,m1,m1)=(coor(1)/h)*(1-coor(2)/h)*(1-coor(3)/h);
bisig(m2,m2,m1)=(coor(1)/h)*(coor(2)/h)*(1-coor(3)/h);
bisig(m2,m1,m2)=(coor(1)/h)*(1-coor(2)/h)*(coor(3)/h);
bisig(m2,m2,m2)=(coor(1)/h)*(coor(2)/h)*(coor(3)/h);
bisig=-3*bisig;
if nargout>1
    g=cell(3,1);
    Amat2=varargin{1};
    for k=1:3
        g{k}=Tucker3matvec2(Amat2(k,:),bisig);
    end
    g=cutedge(g,n);
    varargout{1}=g;
end
bisig=cutedge(bisig,n);
end