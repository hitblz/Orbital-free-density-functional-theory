function phi=assemphi(vL0,Va,n,r,h,Ra,V0,lambda0,Amat1)

r=r';
votexm=min(r,[],1)-Ra;
votexM=max(r,[],1)+Ra;
ndiv=ceil((votexM-votexm)./h)+1;
ndiv=ndiv+(mod(ndiv,4)>0).*(4-mod(ndiv,4));
dis=r-votexm;
ns=floor(dis./h);
coors=dis-ns*h;
coors(coors<0)=0;
n1=floor((dis-Ra)/h);
M=size(r,1);
phi=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
for k=1:M
    bmsig=bsig3D(Va,n,h,Ra,coors(k,:),Amat1);
    if k==1
        szv=size(vL0);
        v2=zeros(szv+2);
        t=normalize(2,v,3,h);
        v2(2:end-1,2:end-1,2:end-1)=t.^2;
        x=0:h:(szv(1)+1)*h;
    end
    xp={(1:szv(1)+1)'*h-coors(k,1);(1:szv(2)+1)*h-coors(k,2);(1:szv(3)+1)'*h-coors(k,3)};
    t=interp3(x,x,x,v2,xp{1},xp{2},xp{3});
    tbmsig=t+bmsig;
    Vcsig=invIvecsig3(1/(4*pi),h,V0,lambda0,tbmsig);
    phi(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))=phi(n1(k,1)+1:n1(k,1)+szv(1),n1(k,2)+1:n1(k,2)+szv(2),n1(k,3)+1:n1(k,3)+szv(3))+Vcsig;
end
end