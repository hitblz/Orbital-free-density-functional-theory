function out=ADI(lambda,f,tol,eADI,varargin)
% Alternating Direction Implicit method
maxit=1000;
mu=0.3312;
nu=1.778;
N=length(lambda);
Ni=ceil(1+log(lambda(N)/lambda(1))/log(nu/mu));
if isempty(varargin)
    uk=f;
else
    uk=varargin{1};%prescribed initial value
end
normf=sqrt(Tucker3inprod(1,uk,uk));
T=cell(2,1);
T{2}=zeros(2,2,2);
T{2}(1,1,1)=6;
T{2}(2,2,2)=1;
T{2}(1,1,2)=-2;
T{2}(1,2,1)=-2;
T{2}(2,1,1)=-2;
T_=T{2};
T_(2,2,2)=0;
for k=0:maxit
    j=mod(k,Ni);
    sigk=1./mu*(nu/mu)^j*lambda(1);
    R=(lambda./sigk+ones(N,1)).^(-1);
    T{1}=[R,ones(N,1)];
    uk1=Tucker3vecHadamard({T{1};T{1};T{1};T{2}},uk,tol);
    ek=Tucker3vecHadamard({T{1};T{1};T{1};T_},uk,tol);
    Bkf=f;
    Bkf{1}=R.*Bkf{1};
    Bkf{2}=R.*Bkf{2};
    Bkf{3}=R.*Bkf{3};
    Bkf{4}=2/sigk.*Bkf{4};
    uk1=Tucker3vecplus(uk1,Bkf,tol);
    ek=Tucker3vecplus(ek,Bkf,tol);
    rnormek=sqrt(Tucker3inprod(1,ek,ek))/normf;
    if rnormek<eADI
        s=[size(uk1{1},2),size(uk1{2},2),size(uk1{3},2)];
        fprintf('ADI iteration converged at iteration %i with rank (%i, %i, %i) and relative residual %10.4e.\n',k,s(1),s(2),s(3),rnormek)
        break
    end
    uk=uk1;
end
out=uk1;
end