function out=funv1(f,v,tol,varargin)
% general nonlinear function of a vector in (3,0) format
% f is a function handle or a subroutine
%To serve for OFDFT, for simplicity, it is assumed that the length of
%size(v{1},1)=size(v{2},1)=size(v{3},1);
if nargin<4% for integration of energy function
    out=tensordecompose(7,f(tucker3product(v)),tol,2);
    out(5)=[];    
    
else% for the gradient of energy function
    out=funv1(f,v,tol);
    Ns=[size(out{1},1) size(out{2},1) size(out{3},1)];
    M=cell(4,1);
    for k=1:3
        M{k}=[2/3*ones(Ns(k),1);1/6*ones(Ns(k)-1,1);1/6*ones(Ns(k)-1,1)];
    end
    h=varargin{1};
    M{4}=prod(h);
    out=Tucker3matvec(M,out,tol);
    
end
end