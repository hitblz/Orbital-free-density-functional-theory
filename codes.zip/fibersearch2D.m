function [val2,id]=fibersearch2D(A)

maxn=10;
L1=size(A,1);
L2=size(A,2);
i1=randi(L1);
i2=randi(L2);
val=A(i1,i2);
k=0;
while k<maxn
    k=k+1;
    [val2,i1]=max(abs(A(:,i2)));
    if abs(val2-val)<1e-8
        fprintf('maximum found at iteration %i',k);
        break
    end
    val=val2;
    k=k+1;
    [val2,i2]=max(abs(A(i1,:)));
    if abs(val2-val)<1e-8
        fprintf('maximum found at iteration %i',k);
        break
    end
    val=val2;
end
id=[i1,i2];
end