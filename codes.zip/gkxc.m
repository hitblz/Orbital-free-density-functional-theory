function out=gkxc(u)
%An element-wise function
%gradient of kinemetic and exchange-correlation energy
CF=3/10*(3*pi^2)^(2/3);
% gam=-0.1471;
% beta1=1.1581;
% beta2=0.3446;
gam=-0.1423;
beta1=1.0529;
beta2=0.3334;
A=0.0311;
B=-0.048;
% C=0.0014;
% D=-0.0108;
C=0.002;
D=-0.0116;
u2=u.*u;
exu2=-3/4*(3/pi)^(1/3)*u2.^(1/3);
rsu2=(3./(4*pi*u2)).^(1/3);
ecu2=gam./(1+beta1*sqrt(rsu2)+beta2*rsu2).*(rsu2>=1)+(A*log(rsu2)+B+C*rsu2.*log(rsu2)+D*rsu2).*(rsu2<1);
% pex_u= -1/2*(3/pi)^(1/3)*u.^(-1/3);
pex_u= -1/2*(3/pi)^(1/3)*nthroot(u.^(-1),3);
prs_u= (3/(4*pi))^(1/3)*(-2/3)*nthroot(u.^(-5),3);
pec_u= -gam.*(beta1./(2*sqrt(rsu2))+beta2).*prs_u./(1+beta1*sqrt(rsu2)+beta2*rsu2).^2.*(rsu2>=1)+...
    (A./rsu2+C+C*log(rsu2)+D).*prs_u.*(rsu2<1);
out=CF*(10/3)*nthroot(u.^7,3)+(pex_u+pec_u).*u2+(exu2+ecu2).*(2*u);
end