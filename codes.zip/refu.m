function [u,rho,phi,bm,aa]=refu(bmsig,phisig,a,h,ncell)
%a is the lattice constant
tol=1e-10;
[phi,aa,I]=refv(phisig,a,h,ncell,tol);
bm=refv(bmsig,a,h,ncell,tol);
N=size(phi{1},1);
s1=[2*ones(N,1);-1*ones(N-1,1);-1*ones(N-1,1)];
s2=[2/3*ones(N,1);1/6*ones(N-1,1);1/6*ones(N-1,1)];
mu=@(k) 2/3+1/3*cos(k*pi/(N+1));%decreasing
muN=mu((1:N)');
imuN=muN.^(-1);
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
A={[s1,s2];[s1,s2];[s1,s2];c.*h};
phi=Tucker3matvec(A,phi,tol);
phi{4}=phi{4}./(4*pi);
bm_=bm;
bm_{4}=-bm{4};
u2m=Tucker3vecplus(phi,bm_,tol);
%a correction step is needed
nI=length(I);
for k=1:3
    for k2=1:nI
        u2m{k}(I(k2),:)=mean(u2m{k}([I(k2)-1 I(k2)+1],:));
    end
end
%correction end
for k=1:3
    u2m{k}=fDST(u2m{k},1);
    u2m{k}=imuN.*u2m{k};
end
u2m{4}=u2m{4}./(h^3);
for k=1:3
    u2m{k}=fDST(u2m{k},1);
end
rho=u2m;
tol2=1e-5;
u=funv2(@(v) sqrt(abs(v)),rho,tol2);
end