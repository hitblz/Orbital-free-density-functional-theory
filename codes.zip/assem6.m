function [out, varargout]=assem6(protect,v,r,h,Ra)

r=r';
votexm=min(r)-Ra;
votexM=max(r)+Ra;
ndiv=ceil((votexM-votexm)./h)+1;
ndiv=ndiv+(mod(ndiv,4)>0).*(4-mod(ndiv,4));
dis=r-votexm;
ns=round(dis./h);
% coors=dis-ns*h;
M=size(r,1);
switch protect
    case 0
        out=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
    case 1
        out=ones(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1)*1e-6;
end
nh=(size(v)-1)./2;
for k=1:M
    out(ns(k,1)-nh(1):ns(k,1)+nh(1),ns(k,2)-nh(2):ns(k,2)+nh(2),ns(k,3)-nh(3):ns(k,3)+nh(3))=out(ns(k,1)-nh(1):ns(k,1)+nh(1),ns(k,2)-nh(2):ns(k,2)+nh(2),ns(k,3)-nh(3):ns(k,3)+nh(3))+v;
end
if nargout>1
    varargout{1}=ns-nh-1;%(0,0,0) grid
end
end