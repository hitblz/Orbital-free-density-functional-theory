function out=Tucker3vecHadamard(v1,v2,tol)
%Hadamard product of two third-order Tucker vectors
out=cell(4,1);
sd=cell(1,3);
for k=1:3
    t=tensordecompose(5,v1{k}.*permute(v2{k},[1 3 2]),tol,2);
    out{k}=t{1};
    sd{k}=t{2};
end
if max([size(sd{1},1)*size(sd{1},2);size(sd{2},1)*size(sd{2},2);size(sd{3},1)*size(sd{3},2)])<500
    for k=1:3
        if k==1
            t=tencontract(sd{k},3,3,v2{4},3,1);
        elseif k==2
            t=tencontract(sd{k},3,3,t,4,3);
        else
            t=tencontract(sd{k},3,3,t,5,5);
        end
    end
    t=tencontract(permute(t,[5 3 1 6 4 2]),6,[4 5 6],v1{4},3,[1 2 3]);
else
    t=0;
    for i=1:size(sd{1},2)
        for j=1:size(sd{2},2)
            for k=1:size(sd{3},2)
                t=t+tucker3product(v2{4}.*v1{4}(i,j,k),permute(sd{1}(:,i,:),[1 3 2]),permute(sd{2}(:,j,:),[1 3 2]),permute(sd{3}(:,k,:),[1 3 2]));
            end
        end
    end
end
C=tensordecompose(7,t,tol,2);
out{4}=C{4};
for j=1:3
    out{j}=out{j}*C{j};
end
end