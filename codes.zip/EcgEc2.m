function [Ecu,gEcu,phi]=EcgEc2(u,nele,h,Amat,bm,V,lambdaN,M,P,v1,v2)
% an analogue of EcgEcsig2
%h, Amat, bm, LmuN, imuN are quantities at the finest level (level 0)
if isequal(v1,0)%level 0
    %step 1
    Mu=Tucker3matvec2(M,u);
    inprodu=u(:)'*Mu(:);
    a=sqrt(nele/inprodu);
    un=u.*a;
    %step 2
    un2bm=Tucker3matvec2(M,un.^2)+bm;
    phi=invIvec2(1/(4*pi),h,V,lambdaN,un2bm);
    Ecu=E(un,Amat,h,phi,M,bm);% a scalar
    %step 3
    gEun=gE(un,Amat,phi,M);
    lambda=-un(:)'*gEun(:)./nele;
    cMJun=lambda.*Mu.*a;
    gEcu=(gEun+cMJun).*a;
    
elseif isequal(v2,0)%level 1
    [Ecu,gEcu,phi]=EcgEc2(u,nele,h,Amat,bm,V,lambdaN,M,P,0,0);
    if size(u,1)==size(v1,1)
        Ecu=Ecu-v1(:)'*u(:);
        gEcu=gEcu-v1;
    else
%         f=(size(P{1,2},1)/size(P{1,2},2))*(size(P{2,2},1)/size(P{2,2},2))*(size(P{3,2},1)/size(P{3,2},2));
        v12=Tucker3matvec2({P{1,2}',P{2,2}',P{3,2}',1},v1);
        Ecu=Ecu-v12(:)'*u(:);
        gEcu=gEcu-v12;
    end
    
else% level 2
    [Ecu,gEcu,phi]=EcgEc2(u,nele,h,Amat,bm,V,lambdaN,M,P,v1,0);
    Ecu=Ecu-v2(:)'*u(:);
    gEcu=gEcu-v2;
    
end
end
function out=E(u,Amat,h,phi,M,bm)
%first part of kinematic energy
lam=2/10;
t=Tucker3matvec2(Amat,u);
out=lam/2.*(u(:)'*t(:));
%second part of kinematic energy + Exc
fkxc=@(v) kxc(v);
fu=funv3(fkxc,u);
u2=u.^2;
out=out+sum(fu,'all')*h^3;
%E-I interaction energy
t=Tucker3matvec2(M,u2)+bm;
out=out+1/2*(t(:)'*phi(:));
end
function out=gE(u,Amat,phi,M)
%gradient of total energy with fixed phik
%first update
lam=2/10;
out=Tucker3matvec2(Amat,u).*lam;
%second update
fgkxc=@(v) gkxc(v);
pfu=funv3(fgkxc,u,M);
out=out+pfu;
%third update
uphi=2*u.*phi;
out=out+Tucker3matvec2(M,uphi);
end