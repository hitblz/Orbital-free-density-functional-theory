bimsig=bmsig;
bimsig(:,:,:)=0;
sz=size(bimsig);
bimsig((sz(1)+1)/2,(sz(2)+1)/2,(sz(3)+1)/2)=-3;

As1=zeros(Nsig+3+2*n,Nsig+3+2*n,2);
for k=1:Nsig+3+2*n
    a1=n+2-min(k,n+1);
    b1=max(1,k-n);
    lb=Nsig+3+2*n-(b1-1);
    la=2*n+1-(a1-1);
    ly=min(la,lb);
    a2=a1-1+ly;
    b2=b1-1+ly;
    As1(k,b1:b2,1)=xwp(a1:a2);
    
    c1=1+2-min(k,1+1);
    d1=max(1,k-1);
    ld=Nsig+3+2*n-(d1-1);
    lc=2*1+1-(c1-1);
    lz=min(lc,ld);
    c2=c1-1+lz;
    d2=d1-1+lz;
    As1(k,d1:d2,2)=xwp2(c1:c2);
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat1={As1;As1;As1;c.*h};

As=zeros(Nsig+1,Nsig+1,2);
for k=1:Nsig+1
    a1=n+2-min(k,n+1);
    b1=max(1,k-n);
    lb=Nsig+1-(b1-1);
    la=2*n+1-(a1-1);
    ly=min(la,lb);
    a2=a1-1+ly;
    b2=b1-1+ly;
    As(k,b1:b2,1)=xwp(a1:a2);
end
for k=1:Nsig+1
    As(k,k,2)=1;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Asig={As;As;As;c.*h};
[V0,lambda0]=eig(As(:,:,1),As(:,:,2),'vector');

% biL0=assemb1(n,r,h,Ra);
% bb2=biL0+bL0;
% b_b2=biL0-bL0;
% bbmsig=bimsig+bmsig;
% b_bmsig=bimsig-bmsig;
% Vc1=invIvec2(1/(4*pi),h,Vs,lambdas,b_b2);
% Vc2=assemVc(Va,n,r,h,Ra,V0,lambda0,Amat1);
% Vcsig=invIvecsig3(1/(4*pi),h,V0,lambda0,b_bmsig);
% Visig=Vcsig+Vsig{1};
% Vc=assem5(0,Vcsig,r,h,Ra);
% bb=assem5(0,bbmsig,r,h,Ra);
% Ec=1/2*(bb(:)'*Vc(:)-Na*bimsig(:)'*Visig(:)+Na*bmsig(:)'*Vsig{1}(:));
% Eac=(E0+Ec)/Na*27.2114;
% Ec1=1/2*(bb2(:)'*Vc1(:)-Na*bimsig(:)'*Visig(:)+Na*bmsig(:)'*Vsig{1}(:));
% Eac1=(E0+Ec1)/Na*27.2114;
% Ec2=1/2*(bb2(:)'*Vc2(:)-Na*bimsig(:)'*Visig(:)+Na*bmsig(:)'*Vsig{1}(:));
% Eac2=(E0+Ec2)/Na*27.2114;
% Ec3=1/2*(bb2(:)'*Vc(:)-Na*bimsig(:)'*Visig(:)+Na*bmsig(:)'*Vsig{1}(:));
% Eac3=(E0+Ec3)/Na*27.2114;
% Ec4=1/2*(bb(:)'*Vc1(:)-Na*bimsig(:)'*Visig(:)+Na*bmsig(:)'*Vsig{1}(:));
% Eac4=(E0+Ec4)/Na*27.2114;
% Ec5=1/2*(bb(:)'*Vc2(:)-Na*bimsig(:)'*Visig(:)+Na*bmsig(:)'*Vsig{1}(:));
% Eac5=(E0+Ec5)/Na*27.2114;

[Ecn,bvs]=Eco(Va,n,r,h,Ra,V0,lambda0,Amat1);
Eacn=(E1+E2+E3-1/2*bvs(2)+Ecn)/Na*27.2114;
% [Ecn2,bvs2]=Eco2(r,h,Ra,V0,lambda0,bmsig,bimsig,Vsig{1},Visig);
% Eacn2=(E1+E2+E3-1/2*bvs2(2)+Ecn2)/Na*27.2114;