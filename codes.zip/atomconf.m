%PROFESS 3.0
a0=8;
n=10;
ncell=[1 1 1]*n;
r0list=r0cgen(ncell);
na=size(r0list,1);
fid=fopen('mytest.ion','w');
lan=a0*0.52917721067;
r0list=r0list*lan+3.1751;
L=lan*n+3.1751*2;
fprintf(fid,'%%BLOCK LATTICE_CART\n');
fprintf(fid,'%4.2f 0 0\n',L);
fprintf(fid,'0 %4.2f 0\n',L);
fprintf(fid,'0 0 %4.2f\n',L);
fprintf(fid,'%%END BLOCK LATTICE_CART\n');
fprintf(fid,'%%BLOCK POSITIONS_CART\n');
for k=1:na
    fprintf(fid,'Al %4.2f %4.2f %4.2f\n',r0list(k,1),r0list(k,2),r0list(k,3));
end
fprintf(fid,'%%END BLOCK POSITIONS_CART\n');
fprintf(fid,'%%BLOCK SPECIES_POT\n');
fprintf(fid,'Al al.lda.recpot\n');
fprintf(fid,'%%END BLOCK SPECIES_POT\n');
fclose(fid);