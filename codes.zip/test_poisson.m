clear
op=1;
Ra=6;
n2v=[60 48 36 24 12];
n2h=n2v./4;
hf=Ra./n2v;
n=3;
wp=zeros(1,n+1);
for p=0:n
    if p==0
        wp(p+1)=2*sum((1:n).^(-2));
    else
        wp(p+1)=2*(-1)^p/p^2*factorial(n)^2/(factorial(n-p)*factorial(n+p));
    end
end
% wp=[30 -16 1]./12;
% n=2;
xwp=[wp(n+1:-1:2) wp];
br=pseudobx(Ra);
tol=1e-10;
h=hf(op);
n2=n2h(op)*2^3;%number of elements for each atom, EVEN
%Ra=h*n2/2;%diameter of an atom
N=n2-1;
As=zeros(N,N,2);
for k=1:N
    a1=n+2-min(k,n+1);
    b1=max(1,k-n);
    lb=N-(b1-1);
    la=2*n+1-(a1-1);
    ly=min(la,lb);
    a2=a1-1+ly;
    b2=b1-1+ly;
    As(k,b1:b2,1)=xwp(a1:a2);
end
for k=1:N
    As(k,k,2)=2/3;
end
for k=1:N-1
    As(k+1,k,2)=1/6;
    As(k,k+1,2)=1/6;
end
c=zeros(2,2,2);
c(1,2,2)=1;
c(2,1,2)=1;
c(2,2,1)=1;
Amat={As;As;As;c.*h};
M={As(:,:,2);As(:,:,2);As(:,:,2);h^3};
[V,lambdaN]=eig(As(:,:,1),As(:,:,2));lambdaN=diag(lambdaN);

bm=nucchasig(1,br,n2,h,tol,1);
bm=tucker3product(bm);

u=metadensitysig2(Ra,n2,M,3);
Mu=Tucker3matvec2(M,u);
inprodu=u(:)'*Mu(:);
a=sqrt(3/inprodu);
un=u.*a;
%step 2
un2bm=Tucker3matvec2(M,un.^2)+bm;
phi=invIvecsig3(1/(4*pi),h,V,lambdaN,un2bm);
nmid=(N+1)/2;
figure;surf(phi(:,:,nmid)');
