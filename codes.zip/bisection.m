function [ukadk,Eukadk,gukadk,phiukadk,flag]=bisection(uk,dk,Euk,guk,phik,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2)
%an analogue of bisectionsig2
% bisection line search algorithm with strong Wolfe condition
flag=1;
gkTdk=guk(:)'*dk(:);
%searching for a 'crossing interval'
alpha_=0;%fixed
alpha=1;
epsilon=1e-4;
fpa_=gkTdk;
if fpa_>0
    ukadk=uk;
    Eukadk=Euk;
    gukadk=guk;
    phiukadk=phik;
    return
end
[fpa,ukadk,Eukadk,gukadk,phiukadk]=fp(alpha,uk,dk,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2);
wcheckh=@(alpha,Eukadk,gukadk) Wolfecheck(dk,alpha,Eukadk,gukadk,Euk,gkTdk);
if wcheckh(alpha,Eukadk,gukadk)
    return
end
jmax=30;
flag=0;
for j=1:jmax
    if fpa>0
        flag=1;
        break
    else
        alpha_=alpha;
        alpha=2*alpha;
        fpa_=fpa;
        [fpa,ukadk,Eukadk,gukadk,phiukadk]=fp(alpha,uk,dk,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2);
        if wcheckh(alpha,Eukadk,gukadk)
            flag=1;
            return
        end
    end
end
lref=alpha-alpha_;
a=alpha_;
b=alpha;
fa=fpa_;
fb=fpa;
%secant search begin
if flag==1
    itmax=30;
    for j=1:itmax
        if (b-a)/lref<epsilon
            break
        end
        x=(a+b)/2;
        [fx,ukadk,Eukadk,gukadk,phiukadk]=fp(x,uk,dk,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2);
        if wcheckh(x,Eukadk,gukadk)
            return
        end
        if fx>0
            x0=a-(a-x)*fa/(fa-fx);
            [fx0,ukadk,Eukadk,gukadk,phiukadk]=fp(x0,uk,dk,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2);
            if wcheckh(x0,Eukadk,gukadk)
                return
            end
            if fx0>0
                b=x0;
                fb=fx0;
            else
                a=x0;
                b=x;
                fa=fx0;
                fb=fx;
            end
        else
            x0=b-(b-x)*fb/(fb-fx);
            [fx0,ukadk,Eukadk,gukadk,phiukadk]=fp(x0,uk,dk,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2);
            if wcheckh(x0,Eukadk,gukadk)
                return
            end
            if fx0>0
                a=x;
                b=x0;
                fa=fx;
                fb=fx0;
            else
                a=x0;
                fa=fx0;
            end
        end
    end
    x=(a+b)/2;
    [~,ukadk,Eukadk,gukadk,phiukadk]=fp(x,uk,dk,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2);
% else
%     error('failed to find a crossing interval in %i iterations\n',jmax);
end
end
function [val,varargout]=fp(a,uk,dk,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2)
ukadk=uk+a*dk;
[Eukadk,gukadk,phiukadk]=EcgEc(1,ukadk,nele,h,Amat,bm,LmuN,imuN,M,P,v1,v2);
val=dk(:)'*gukadk(:);
varargout{1}=ukadk;
varargout{2}=Eukadk;
varargout{3}=gukadk;
varargout{4}=phiukadk;
end
function out=Wolfecheck(dk,alpha,Eukadk,gukadk,Euk,gkTdk)
sig1=0.01;
sig2=0.1;
gukadkTdk=gukadk(:)'*dk(:);
out=(Eukadk<=Euk+sig1*alpha*gkTdk) && (abs(gukadkTdk)<=sig2*abs(gkTdk));
end