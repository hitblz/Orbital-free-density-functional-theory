function [out, varargout]=assem4(protect,option,f,r,h,Ra)

r=r';
votexm=min(r)-Ra;
votexM=max(r)+Ra;
ndiv=ceil((votexM-votexm)./h);
ndiv=ndiv+(mod(ndiv,4)>0).*(4-mod(ndiv,4));
dis=r-votexm;
ns=floor(dis./h);
coors=dis-ns*h;
M=size(r,1);
switch protect
    case 0
        out=zeros(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1);
    case 1
        out=ones(ndiv(1)-1,ndiv(2)-1,ndiv(3)-1)*1e-6;
end
nsig=floor(Ra/h);
if option<3
    for k=1:M        
        out(ns(k,1)-nsig+1:ns(k,1)+nsig-1,ns(k,2)-nsig+1:ns(k,2)+nsig-1,ns(k,3)-nsig+1:ns(k,3)+nsig-1)=out(ns(k,1)-nsig+1:ns(k,1)+nsig-1,ns(k,2)-nsig+1:ns(k,2)+nsig-1,ns(k,3)-nsig+1:ns(k,3)+nsig-1)+sig3D(option,f,Ra,h,coors(k,:));
    end
else
    for k=1:M
        out(ns(k,1)-nsig+1:ns(k,1)+nsig-1,ns(k,2)-nsig+1:ns(k,2)+nsig-1,ns(k,3)-nsig+1:ns(k,3)+nsig-1)=out(ns(k,1)-nsig+1:ns(k,1)+nsig-1,ns(k,2)-nsig+1:ns(k,2)+nsig-1,ns(k,3)-nsig+1:ns(k,3)+nsig-1)+f;
    end
end
if nargout>1
    varargout{1}=ns-nsig;%(0,0,0) grid
end
end